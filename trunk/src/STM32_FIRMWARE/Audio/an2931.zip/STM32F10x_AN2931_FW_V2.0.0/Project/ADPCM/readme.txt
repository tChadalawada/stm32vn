/**
  @page ADPCM AN2931 ADPCM Readme file
  	
  @verbatim
  ******************** (C) COPYRIGHT 2009 STMicroelectronics *******************
  * @file ADPCM/readme.txt 
  * @author   MCD Application Team
  * @version  V2.0.0
  * @date     04/27/2009
  * @brief    Description of the AN2931: Implementing the ADPCM algorihtm 
  *           in high-density STM32F103xx microcontrollers.
  ******************************************************************************
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  ******************************************************************************
   @endverbatim

@par Description

This firmware has been developped on the STM3210E-EVAL board. It gives an ADPCM 
playback demonstration.

@par Directory contents 

  - inc: containing the user header files  
    - ADPCM/inc/stm32f10x_conf.h  Library Configuration files
    - ADPCM/inc/stm32f10x_it.h    Interrupt handlers header files
    - ADPCM/inc/main.h            main header file
    - ADPCM/inc/adpcm.h           ADPCM algorithe header file
    - ADPCM/inc/fsmc_nor.h        STM3210E-EVAL board NOR Flash memory driver header file           
    - ADPCM/inc/i2s_codec.h       STM3210E-EVAL board audio codec driver header file
    - ADPCM/inc/lcd.h             STM3210E-EVAL board LCD driver header file
    - ADPCM/inc/fonts.h           LCD fontsize definition
                                             
  - src: containing the user source files  
    - ADPCM/src/adpcm.c           ADPCM algorithm source file 
    - ADPCM/src/stm32f10x_it.c    Interrupt handlers
    - ADPCM/src/main.c            main program
    - ADPCM/src/fsmc_nor.c        STM3210E-EVAL board NOR Flash memory driver           
    - ADPCM/src/i2s_codec.c       STM3210E-EVAL board audio codec driver            
    - ADPCM/src/lcd.c             STM3210E-EVAL board LCD driver


@par Hardware and Software environment  

  - This example runs on STM32F10x High-Density.
  
  - This example has been tested with STMicroelectronics STM3210E-EVAL (STM32F10x 
    High-Density) evaluation board and can be easily tailored to any other supported 
	  device and development board.
       
  - STM3210E-EVAL Set-up 
     - A headphone should be connected to the audio jack of the STM3210E-EVAL board.
     - A PC and an USB cable to load the ADPCM file into the NOR Flash.

@note
  - When using High-density devices, it is mandatory to reset the target
    before loading the project into  target.
  - It is recommended to run the reset script (click on TR button in the
    toolbar menu) after loading the project into target.
      
@par How to use it?

In order to load the ADPCM code, you have do the following:

 - EWARM: 
    - Open the ADPCM.eww workspace
    - In the workspace toolbar select the project config:
        - STM3210E-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all
    - Load project image: Project->Debug
    - Run program: Debug->Go(F5)

 - RIDE 
    - Open the ADPCM.rprj project
    - In the configuration toolbar(Project->properties) select the project config:
        - STM3210E-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->build project
    - Load project image: Debug->start(ctrl+D)
    - Run program: Debug->Run(ctrl+F9)

 - RVMDK 
    - Open the ADPCM.Uv2 project
    - In the build toolbar select the project config:  
        - STM3210E-EVAL: to configure the project for STM32 High-density devices
    - Rebuild all files: Project->Rebuild all target files
    - Load project image: Debug->Start/Stop Debug Session
    - Run program: Debug->Run (F5)
       
@note
 - High-density devices are STM32F101xx and STM32F103xx microcontrollers where
   the Flash memory density ranges between 256 and 512 Kbytes. 

 * <h2><center>&copy; COPYRIGHT 2009 STMicroelectronics</center></h2>
 */
