/**
  ******************************************************************************
  * @file    app.c
  * @author  MCD Application Team
  * @version V1.0.0
  * @date    22-July-2011
  * @brief   This file provides all the Application firmware functions.
  ******************************************************************************
  * @attention
  *
  * THE PRESENT FIRMWARE WHICH IS FOR GUIDANCE ONLY AIMS AT PROVIDING CUSTOMERS
  * WITH CODING INFORMATION REGARDING THEIR PRODUCTS IN ORDER FOR THEM TO SAVE
  * TIME. AS A RESULT, STMICROELECTRONICS SHALL NOT BE HELD LIABLE FOR ANY
  * DIRECT, INDIRECT OR CONSEQUENTIAL DAMAGES WITH RESPECT TO ANY CLAIMS ARISING
  * FROM THE CONTENT OF SUCH FIRMWARE AND/OR THE USE MADE BY CUSTOMERS OF THE
  * CODING INFORMATION CONTAINED HEREIN IN CONNECTION WITH THEIR PRODUCTS.
  *
  * <h2><center>&copy; COPYRIGHT 2011 STMicroelectronics</center></h2>
  ******************************************************************************
  */ 

/* Includes ------------------------------------------------------------------*/ 
#include  "stm32_eval.h"
#include  "lcd_log.h"

/** @addtogroup STM32_USB_OTG_DEVICE_LIBRARY
  * @{
  */


/** @defgroup APP_DFU 
  * @brief Mass storage application module
  * @{
  */ 

/** @defgroup APP_DFU_Private_TypesDefinitions
  * @{
  */ 

/**
  * @}
  */ 


/** @defgroup APP_DFU_Private_Defines
  * @{
  */ 

/**
  * @}
  */ 


/** @defgroup APP_DFU_Private_Macros
  * @{
  */ 
/**
  * @}
  */ 


/** @defgroup APP_DFU_Private_Variables
  * @{
  */ 
static __IO uint32_t TimingDelay;

/**
  * @}
  */ 


/** @defgroup APP_DFU_Private_FunctionPrototypes
  * @{
  */ 
void Delay(__IO uint32_t nTime);
/**
  * @}
  */ 


/** @defgroup APP_DFU_Private_Functions
  * @{
  */ 

/**
  * @brief  Program entry point
  * @param  None
  * @retval None
*/
int main(void)
{
  /*!< At this stage the microcontroller clock setting is already configured, 
  this is done through SystemInit() function which is called from startup
  file (startup_stm32fxxx_xx.s) before to branch to application main.
  To reconfigure the default setting of SystemInit() function, refer to
  system_stm32fxxx.c file
  */  

  /* Initialize the LCD */
#ifdef USE_STM3210C_EVAL
  STM3210C_LCD_Init();  
#else
  STM322xG_LCD_Init();
#endif
  LCD_LOG_Init();
  
  LCD_LOG_SetHeader(" Binary image template ");
  LCD_UsrLog("> Systick template example started.\n"); 
  LCD_LOG_SetFooter ("     Binary image template " ); 
  
  /* Configure the LEDs */
  STM_EVAL_LEDInit(LED1);
  STM_EVAL_LEDInit(LED2);
  STM_EVAL_LEDInit(LED3);
  STM_EVAL_LEDInit(LED4);  

   /* Set the Vector Table base location at the application start address
      (this is already done in system_stm32f10x.c and system_stm32f2xx.c files */   
//#ifdef STM32F2XX
//  /* Set the Vector Table base location at 0xC000 */ 
//  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0xC000);
//#elif defined(STM32F10X_CL)
//  /* Set the Vector Table base location at 0x8000 */ 
//  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x8000);
//#endif /* STM32F2XX */
  
  /* Setup SysTick Timer for 1 msec interrupts  */
  if (SysTick_Config(SystemCoreClock / 1000))
  { 
    /* Capture error */ 
    while (1);
  }
  
  while (1)
  {
    /* Toggle all leds */
    STM_EVAL_LEDToggle(LED1);
    STM_EVAL_LEDToggle(LED2);
    STM_EVAL_LEDToggle(LED3);
    STM_EVAL_LEDToggle(LED4);
    
    /* Insert 200 ms delay */
    Delay(200);
    
    /* Toggle all leds */
    STM_EVAL_LEDToggle(LED1);
    STM_EVAL_LEDToggle(LED2);
    STM_EVAL_LEDToggle(LED3);
    STM_EVAL_LEDToggle(LED4);
    
    /* Insert 200 ms delay */
    Delay(200);
  }
} 

/**
  * @brief  Inserts a delay time.
  * @param  nTime: specifies the delay time length, in milliseconds.
  * @retval None
*/
void Delay(uint32_t nTime)
{
  TimingDelay = nTime;

  while(TimingDelay != 0);
}

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  nTime: specifies the delay time length, in milliseconds.
  * @retval None
*/
void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  { 
    TimingDelay--;
  }
}

#ifdef USE_FULL_ASSERT
/**
* @brief  assert_failed
*         Reports the name of the source file and the source line number
*         where the assert_param error has occurred.
* @param  File: pointer to the source file name
* @param  Line: assert_param error line source number
* @retval None
*/
void assert_failed(uint8_t* file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
  ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  
  /* Infinite loop */
  while (1)
  {}
}
#endif

/**
  * @}
  */ 


/**
  * @}
  */ 


/**
  * @}
  */ 

/******************* (C) COPYRIGHT 2011 STMicroelectronics *****END OF FILE****/
