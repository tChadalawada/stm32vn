/***************************************************************************
 * @file	fat.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it
 *
 * Interface between ChaN FatFS and Milos
 *

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/
#ifndef __FAT_H__
#define __FAT_H__

#include <core/system.h>
#include <core/device.h>
#include "fatfs/src/ff.h"
#include "fatfs/src/diskio.h"

#if __CONFIG_COMPILE_FAT

/** @addtogroup FAT
  * @{
  */

/*
 * Own types based on FatFS types
 */
typedef DSTATUS		__FATFS_STATUS;
typedef DRESULT		__FATFS_RES;
typedef FRESULT		__FILE_RES;
typedef FATFS		__FAT_FATFS;
typedef FATFS*		__PFAT_FATFS;
typedef FIL 		__FILE;
typedef FIL*		__PFILE;
typedef DIR			__DIR;
typedef DIR*		__PDIR;
typedef FILINFO		__FILEINFO;
typedef FILINFO*	__PFILEINFO;

#define	__FILE_READ 			FA_READ
#define	__FILE_OPEN_EXISTING	FA_OPEN_EXISTING

#if !_FS_READONLY
#define	__FILE_WRITE			FA_WRITE
#define	__FILE_CREATE_NEW		FA_CREATE_NEW
#define	__FILE_CREATE_ALWAYS	FA_CREATE_ALWAYS
#define __FILE_OPEN_ALWAYS		FA_OPEN_ALWAYS
#endif


/*!
 * @brief Volume description.
 *
 * Used to keep track of opened __FAT_FATFS
 * objects and underlying device.
 */
typedef struct __fatvolumeTag {
	u32						num;		/*!< @brief Volume number */
	__PDEVICE 				dv;			/*!< @brief Device driver */
	__PFAT_FATFS			fat;		/*!< @brief __PFAT_FATFS object */
	__PLOCK					lock;		/*!< @brief Volume lock */
	struct __fatvolumeTag* 	next;		/*!< @brief Next structure in linked list */
} __FAT_VOLUME, *__PFAT_VOLUME;

/*
 * FAT functions.
 */
__PFAT_VOLUME 	__fatMount(u8 num, __PDEVICE dv);
__VOID 			__fatUnmount(__PFAT_VOLUME vol);
u32				__fatGetFreeClusters(__CONST __PSTRING part, __PFAT_VOLUME* vol);

/*
 * File functions.
 */
__PFILE		__fileOpen(__CONST __PSTRING file, u8 mode);
u32 		__fileRead(__PFILE file, __PVOID buf, u32 qty);
__FILE_RES	__fileSeek(__PFILE file, u32 offs);
__FILE_RES	__fileClose(__PFILE file);
__FILE_RES	__fileGetStatus(__CONST __PSTRING file, __PFILEINFO fi);
u32			__fileWriteLine(__PFILE file, __PSTRING str);
u32			__fileWrite(__PFILE file, __PVOID buf, u32 qty);
__FILE_RES	__fileFlush(__PFILE file);
__FILE_RES	__fileTruncate(__PFILE file);
__FILE_RES 	__fileSync(__PFILE file);
__FILE_RES	__fileDelete(__CONST __PSTRING file);
__FILE_RES	__fileChmod(__CONST __PSTRING file, u8 value, u8 mask);
__FILE_RES	__fileChangeTime(__CONST __PSTRING file, __CONST __PFILEINFO fi);
__FILE_RES	__fileRename(__CONST __PSTRING name1, __CONST __PSTRING name2);

/*
 * Directory functions
 */
__FILE_RES	__dirCreate(__CONST __PSTRING name);
__FILE_RES	__dirOpen(__PDIR dir, __CONST __PSTRING name);
__FILE_RES	__dirRead(__PDIR dir, __PFILEINFO fi);

/*
 * Misc Functions
 */
__VOID __fatDirCmd(__VOID);


/**
  * @}
  */

#endif // __CONFIG_COMPILE_FAT

#endif // __FAT_H__
