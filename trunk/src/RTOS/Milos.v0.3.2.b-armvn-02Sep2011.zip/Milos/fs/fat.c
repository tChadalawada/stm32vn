/***************************************************************************
 * @file	fat.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it
 *
 *
 * Interface between ChaN's FatFs and Milos (EXPERIMENTAL) *
 *
 * FatFS Copyright (C) 2010, ChaN, all right reserved.
 * http://elm-chan.org/fsw/ff/00index_e.html
 *

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

 *
 * The function names and some types names are the same as previous versions
 * of Milos (to keep compatibility).
 * This file intends to "glue" the Milos implementation with the FatFS file
 * system. Some types (mostly error codes)are the same from FatFS, so expect
 * naming differences (by default all Milos names start with a double underscore
 * character to differentiate them from user (app) functions and avoid renaming).
 * Let's say this file will suffer modifications: one issue is the mentioned
 * above. The other is that someday we will (hopefully) implement diverse
 * file systems, and the __fileXXXXX functions should be the same for different
 * file system types.
 *
***************************************************************************/

#include "fat.h"
#include <core/heap.h>
#include <core/device.h>
#include <drivers/sd/sd.h>
#include <common/mem.h>
#include <common/string.h>
#include <core/terminal.h>

#if __CONFIG_COMPILE_FAT

/** @addtogroup Milos
  * @{
  */

/** @defgroup FileSystem File System
  * File system functions.
  * @{
  */

/** @defgroup FAT Fat
  * @{
  */

/** @defgroup FAT_PrivateVariables Private variables
  * @{
  */

__PFAT_VOLUME 	__fatVolumes;		/*!< @brief List of (dynamically) allocated volumes. */

/**
  * @}
  */

/** @defgroup FAT_PrivateFunctions Private functions
  * Fat functions.
  * @{
  */
/*
__STATIC __PFAT_VOLUME __fatGetVolumeFromFatFS(__PFAT_FATFS fs)
{
	__PFAT_VOLUME vol = __fatVolumes;
	while (vol)
	{
		if (vol->fat == fs) return vol;
		vol = vol->next;
	}

	return __NULL;
}
*/
/*!
 * @brief Retrieves a device pointer from the \c drv index.
 *
 * Internal function.
 *
 * @param drv	Index of the device.
 * @return 		A pointer to the device on success, otherwise __NULL.
 *
 */
__STATIC __PDEVICE __fatGetDevice(u8 drv)
{
	__PFAT_VOLUME vol = __fatVolumes;
	while (vol)
	{
		if (vol->num == drv) return vol->dv;
		vol = vol->next;
	}

	return __NULL;
}

/*!
 * @brief Creates a new volume.
 *
 * The allocated volume structure must be freed with the __fatFreeVolume()
 * function.
 * Internal function.
 *
 * @param num		Volume number.
 * @param fat		Pointer to a __FAT_FATFS structure. The function will only copy
 * 					the pointer, so destroy it (if it was dynamically created) after
 * 					calling __fatFreeVolume().
 * @param dv		Pointer to the device that manages the volume.
 *
 * @return A pointer to the newly created volume
 */
__STATIC __PFAT_VOLUME __fatCreateVolume(u8 num, __PFAT_FATFS fat, __PDEVICE dv)
{
	__PFAT_VOLUME ptr = __fatVolumes;
	__PFAT_VOLUME last = ptr;

	__systemStop();

	/* Find a position */
	while (ptr)
	{
		last = ptr;
		ptr = ptr->next;
	}

	ptr = (__PFAT_VOLUME) __heapAllocZero(sizeof(__FAT_VOLUME));
	if (!ptr) return __NULL;

	ptr->num = num;
	ptr->fat = fat;
	ptr->dv = dv;
	ptr->next = __NULL;

	if (!last)
	{
		__fatVolumes = ptr;
	} else
	{
		last->next = ptr;
	}

	__systemStart();

	return ptr;
}

/*!
 * @brief Deallocates a volume structure.
 *
 * Deallocates a volume structure previously created with the __fatAllocVolume()
 * function.
 *
 * @param	vol		Pointer to a __FAT_VOLUME structure previously created with
 * 					__fatCreateVolume().
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __fatFreeVolume(__PFAT_VOLUME vol)
{
	__PFAT_VOLUME ptr = __fatVolumes;
	__PFAT_VOLUME last = ptr;

	__systemStop();

	/* Find the position */
	while (ptr) {
		if (ptr == vol)
		{
			if (vol == __fatVolumes)
			{
				__fatVolumes = __fatVolumes->next;
			} else
			{
				last->next = ptr->next;
			}

			__heapFree(vol);
		}
		last = ptr;
		ptr = ptr->next;
	}
}

/**
  * @}
  */

/** @defgroup FAT_FatFunctions FAT functions
  * Fat drives functions.
  * @{
  */

/*!
 * @brief Mounts a volume
 *
 * Mounts a volume. The returned pointer is allocated dynamically. Call __fatUnmount()
 * to destroy it.
 *
 * @param num	Volume number.
 * @param dv	Pointer to the underlying device.
 *
 * @return		A pointer to the newly created volume structure. __NULL on failure.
 */
__PFAT_VOLUME __fatMount(u8 num, __PDEVICE dv)
{
	__PFAT_VOLUME ptr = __fatVolumes;
	__PFAT_FATFS fat;

	/* Check if num is already mounted */
	while (ptr)
	{
		if (ptr->num == num) return ptr;
		ptr = ptr->next;
	}

	/* Create a new __PFAT_FATFS, the object that FatFS uses to store
	 * FAT information.
	 */
	fat = (__PFAT_FATFS) __heapAllocZero(sizeof(__FAT_FATFS));
	if (!fat) return __NULL;

	/* Call FatFS f_mount */
	if (f_mount(num, fat) != FR_OK)
	{
		__heapFree(fat);
		return __NULL;
	}

	/* Create and store a new volume */
	ptr = __fatCreateVolume(num, fat, dv);

	/* Return valid pointer on success, otherwise __FALSE */
	return ptr;
}

/*!
 * @brief Dismounts a volume
 *
 * @param vol	A pointer returned from a call to __fatMount().
 *
 * @return		Nothing.
 */
__VOID __fatDismount(__PFAT_VOLUME vol)
{
	/* Save fat pointer*/
	__PFAT_FATFS fat = vol->fat;

	/* Call f_mount */
	f_mount(vol->num, __NULL);

	__fatFreeVolume(vol);
	__heapFree(fat);
}

/* TODO */
u32	__fatGetFreeClusters(__CONST __PSTRING part, __PFAT_VOLUME* vol);

/**
  * @}
  */

/** @defgroup FAT_DirectoryFunctions Directory functions
  * Directory functions
  * @{
  */

/*!
 * @brief Creates a new directory.
 *
 * @param name	Name of the directory (string, null-terminated).
 *
 * @return	Any of the following values.
 * @arg	FR_OK (0) The function succeeded.
 * @arg	FR_NO_PATH Could not find the path.
 * @arg	FR_INVALID_NAME The path name is invalid.
 * @arg FR_INVALID_DRIVE The drive number is invalid.
 * @arg FR_DENIED The directory cannot be created due to directory table or disk is full.
 * @arg FR_EXIST A file or directory that has same name is already existing.
 * @arg FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg FR_WRITE_PROTECTED The medium is write protected.
 * @arg FR_DISK_ERR The function failed due to an error in the disk function.
 * @arg FR_INT_ERR The function failed due to a wrong FAT structure or an internal error.
 * @arg FR_NOT_ENABLED The logical drive has no work area.
 * @arg FR_NO_FILESYSTEM There is no valid FAT volume on the drive.
 */
__FILE_RES __dirCreate(__CONST __PSTRING name)
{
	return f_mkdir(name);
}

/*!
 * @brief Opens an existing directory.
 *
 * From FatFS documentation:
 * The f_opendir function opens an exsisting directory and creates the directory object for
 * subsequent calls. The directory object structure can be discarded at any time without any
 * procedure.
 *
 * @param dir	Pointer to the blank directory object to be opened.
 * @param name	Pointer to the null-terminated string that specifies the directory name to be opened.
 *
 * @return Any of the following values.
 * @arg FR_OK (0) 	The function succeeded and the directory object is created. It is used for subsequent
 * 					calls to read the directory entries.
 * @arg FR_NO_PATH	Could not find the path.
 * @arg FR_INVALID_NAME The path name is invalid.
 * @arg FR_INVALID_DRIVE The drive number is invalid.
 * @arg FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg FR_DISK_ERR The function failed due to an error in the disk function.
 * @arg FR_INT_ERR The function failed due to a wrong FAT structure or an internal error.
 * @arg FR_NOT_ENABLED The logical drive has no work area.
 * @arg FR_NO_FILESYSTEM There is no valid FAT volume on the drive.
 *
 */
__FILE_RES __dirOpen(__PDIR dir, __CONST __PSTRING name)
{
	return f_opendir(dir, name);
}

/*!
 * @brief Reads a directory entry.
 *
 * From FatFS documentation:
 * The f_readdir function reads directory entries in sequence. All items in the directory can be read by
 * calling f_readdir function repeatedly. When all directory entries have been read and no item to read,
 * the function returns a null string into f_name[] member without any error. When a null pointer is given
 * to the FileInfo, the read index of the directory object will be rewinded.
 * When LFN feature is enabled, lfname and lfsize in the file information structure must be initialized with
 * valid value prior to use the f_readdir function. The lfname is a pointer to the string buffer to return
 * the long file name. The lfsize is the size of the string buffer in unit of character. If either the size
 * of read buffer or LFN working buffer is insufficient for the LFN or the object has no LFN, a null string
 * will be returned to the LFN read buffer. If the LFN contains any charactrer that cannot be converted to
 * OEM code, a null string will be returned but this is not the case on Unicode API configuration. When lfname
 * is a NULL, nothing of the LFN is returned. When the object has no LFN, any small capitals can be contained
 * in the SFN.
 * When relative path feature is enabled (_FS_RPATH == 1), "." and ".." entries are not filtered out and it will
 * appear in the read entries.
 *
 * @param dir		Pointer to the open directory (__dirOpen() function).
 * @param fi			Pointer to an __FILEINFO structure to receive the file/directory info.
 *
 * @return Any of the following values:
 * @arg FR_OK (0)	The function succeeded.
 * @arg FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg FR_DISK_ERR The function failed due to an error in the disk function.
 * @arg FR_INT_ERR The function failed due to a wrong FAT structure or an internal error.
 * @arg FR_INVALID_OBJECT The directory object is invalid.
 *
 */
__FILE_RES __dirRead(__PDIR dir, __PFILEINFO fi)
{
	return f_readdir(dir, fi);
}

/**
  * @}
  */

/** @defgroup FAT_MiscFunctions Misc functions
  * Miscellaneous functions.
  * @{
  */

/*!
 * @brief "DIR" command from @ref Terminal.
 *
 * List the files from the root directory of a mounted volume.
 *
 * @return Nothing.
 *
 */
__VOID __fatDirCmd(__VOID)
{
	__DIR dir;
	__FILEINFO fi;
	__PSTRING str;
	u32 count = 0;
	u32 bytes = 0;

	/* String buffer */
	str = __heapAllocZero(__CONFIG_TERM_LINE_LEN);
	if (!str) return;

	/* Clean */
	__memSet(&dir, 0, sizeof(dir));
	__memSet(&fi, 0, sizeof(fi));

	/* Call root __dirOpen() */
	if (__dirOpen(&dir, "") == FR_OK)
	{
		DBGMSG(__TRUE,("\r\nFiles in FAT:\r\n"));
		DBGMSG(__TRUE,("Name           Size"));
		DBGMSG(__TRUE,("-------------------------"));

		/* First call to __dirRead() with __NULL fi */
		__dirRead(&dir, __NULL);

		/* While files in dir */
		while (__dirRead(&dir, &fi) == FR_OK && dir.sect > 0)
		{
			count++;
			bytes += fi.fsize;
			__strFmt(str, "%12s   %lu bytes", fi.fname, (u32) fi.fsize);
			DBGMSG(__TRUE,(str));
		}

		DBGMSG(__TRUE,("\r\n%lu file(s) %lu bytes\r\n", count, bytes));
	} else
	{
		DBGMSG(__TRUE,("Error calling __dirOpen()"));
	}

	__heapFree(str);
}

/**
  * @}
  */

/** @defgroup FAT_FileFunctions File functions
  * File/Directory functions.
  * @{
  */

/*!
 * @brief Opens a file.
 *
 * The pointer returned is dynamically allocated, and it will
 * be destroyed in __fileClose().
 *
 * @param	file	File name.
 * @param	mode	Open mode.
 * @arg 	__FILE_READ				Specifies read access to the object. Data can be read
 * 									from the file. Combine with __FILE WRITE for read-write access.
 * @arg 	__FILE_OPEN_EXISTING	Opens the file. The function fails if the file is not existing.
 * @arg		__FILE_WRITE			Specifies write access to the object. Data can be written to
 * 									the file. Combine with FA_READ for read-write access.
 * @arg		__FILE_CREATE_NEW		Creates a new file. If the file is existing, it is truncated
 * 									and overwritten.
 * @arg		__FILE_CREATE_ALWAYS	Creates a new file. The function fails with FR_EXIST if the file
 * 									exists.
 * @arg		__FILE_OPEN_ALWAYS		Opens the file if it exists. If not, a new file is created.
 *									To append data to the file, use __fileSeek() after file open.
 *									in this method.
 * @return	A pointer to the file, to be used in consequent calls to the file system functions.
 * 			Returns __NULL on failure.
 */
__PFILE __fileOpen(__CONST __PSTRING file, u8 mode)
{
	__PFILE ptr;

	ptr = (__PFILE) __heapAllocZero(sizeof(__FILE));
	if (!ptr) return __NULL;

	if (f_open(ptr, file, mode) != FR_OK)
	{
		__heapFree(ptr);
		return __NULL;
	}

	return ptr;
}

/*!
 * @brief Reads file content.
 *
 * @param	file	File opened with __fileOpen().
 * @param	buf		Buffer to receive the read data.
 * @param	qty		Quantity of bytes to read.
 *
 * @return	The quantity of bytes reads. The read operation is successfully completed when the
 * 			returned value equals \c qty.
 */
u32 __fileRead(__PFILE file, __PVOID buf, u32 qty)
{
	UINT ret = 0;

	f_read(file, buf, qty, &ret);
	return ret;
}

/*!
 * @brief Seeks to an absolute offset.
 *
 * From FatFS documentation:
 * The f_lseek function moves the file read/write pointer of an open file. The offset can be
 * specified in only origin from top of the file. When an offset above the file size is specified
 * in write mode, the file size is increased and the data in the expanded area is undefined.
 * This is suitable to create a large file quickly, for fast write operation. After the f_lseek
 * function succeeded, member fptr in the file object should be checked in order to make sure the
 * read/write pointer has been moved correctly. In case of fptr is not the expected value, either
 * of followings has been occurred.
 * End of file. The specified Offset was clipped at the file size because the file has been opened
 * in read-only mode.
 * Disk full. There is insufficient free space on the volume to expand the file size.
 *
 * When _USE_FASTSEEK is set to 1 and cltbl member in the file object is not NULL, the fast seek
 * feature is enabled. This feature enables fast backward/long seek operations without FAT access by
 * cluster link information stored on the user defined table. The cluster link information must be
 * created prior to do the fast seek. The required size of the table is (number of fragments + 1) * 2 items.
 * For example, when the file is fragmented in 5, 12 items will be required to store the cluster link
 * information. The file size cannot be expanded when the fast seek feature is enabled.
 *
 * @param	file	File opened with __fileOpen().
 * @param	offs	Offset
 *
 * @return	One of the following codes:
 * @arg 	FR_OK (0)		The function succeeded.
 * @arg		FR_DISK_ERR		The function failed due to an error in the disk function.
 * @arg		FR_INT_ERR		The function failed due to a wrong FAT structure or an internal error.
 * @arg		FR_NOT_READY	The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg		FR_INVALID_OBJECT The file object is invalid.
 * @arg		FR_NOT_ENOUGH_CORE Insufficient size of link map table for the file.
 *
 */
__FILE_RES	__fileSeek(__PFILE file, u32 offs)
{
	return f_lseek(file, offs);
}

/*!
 * Closes a opened file.
 *
 * From FatFS documentation:
 * The f_close function closes an open file object. If any data has been written to the file, the cached
 * information of the file is written back to the disk. After the function succeeded, the file object is
 * no longer valid and it can be discarded.
 *
 * @param file	Pointer to a file created with __fileOpen().
 * @return One of the following codes:
 * @arg FR_OK (0)	The file object has been closed successfuly.
 * @arg FR_DISK_ERR	The function failed due to an error in the disk function.
 * @arg FR_INT_ERR	The function failed due to a wrong FAT structure or an internal error.
 * @arg	FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg FR_INVALID_OBJECT The file object is invalid.
 *
 */
__FILE_RES	__fileClose(__PFILE file)
{
	__FILE_RES ret;
	ret = f_close(file);
	if (ret == FR_OK) {
		__heapFree(file);
	}

	return ret;
}

/*!
 * @brief Get the file status.
 *
 * From FatFS documentation:
 * The f_stat gets the information of a file or directory. For details of the information,
 * refer to the FILINFO structure and f_readdir function. This function is not supported in
 * minimization level of >= 1.
 *
 * @param file	File name.
 * @param fi	Pointer to a __FILEINFO structure to receive the file information.
 *
 * @return One of the following values:
 * @arg FR_OK (0)	The function succeeded.
 * @arg FR_NO_FILE	Could not find the file or directory.
 * @arg FR_NO_PATH	Could not find the path.
 * @arg FR_INVALID_NAME	The file name is invalid.
 * @arg FR_INVALID_DRIVE The drive number is invalid.
 * @arg FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg FR_DISK_ERR The function failed due to an error in the disk function.
 * @arg FR_INT_ERR The function failed due to a wrong FAT structure or an internal error.
 * @arg FR_NOT_ENABLED The logical drive has no work area.
 * @arg FR_NO_FILESYSTEM There is no valid FAT volume on the drive.
 *
 */
__FILE_RES	__fileGetStatus(__CONST __PSTRING file, __PFILEINFO fi)
{
	return f_stat(file, fi);
}

/*!
 * @brief Writes data to a file.
 *
 * From FatFS documentation:
 * The read/write pointer in the file object is increased in number of bytes written. After the
 * function succeeded, *ByteWritten should be checked to detect the disk full. In case of
 * *ByteWritten < ByteToWrite, it means the volume got full during the write operation. The function
 * can take a time when the volume is full or close to full.
 *
 * @param file		Pointer to a opened file.
 * @param buf		Pointer to the buffer to write.
 * @param qty		Quantity to write, in bytes.
 *
 * @return			The quantity of bytes written.
 *
 */
u32	__fileWrite(__PFILE file, __PVOID buf, u32 qty)
{
	UINT ret;
	f_write(file, buf, qty, &ret);
	return ret;
}

/*!
 * @brief Flushes unwritten data.
 *
 * From FatFS documentation:
 * The __fileFlush (f_sync) function performs the same process as __fileClose (f_close) function but the file
 * is left opened and can continue read/write/seek operations to the file. This is suitable for the applications
 * that open files for a long time in write mode, such as data logger. Performing f_sync of periodic or
 * immediately after __fileFlush (f_write) can minimize the risk of data loss due to a sudden blackout or an
 * unintentional disk removal. However f_sync immediately before f_close has no advantage because f_close
 * performs f_sync in it. In other words, the difference between those functions is that the file object is
 * invalidated or not.
 *
 * @param	file Pointer to opened file.
 * @return 	Any of the following values:
 * @arg 	FR_OK (0)	The function succeeded.
 * @arg		FR_DISK_ERR	The function failed due to an error in the disk function.
 * @arg		FR_INT_ERR	The function failed due to a wrong FAT structure or an internal error.
 * @arg		FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg		FR_INVALID_OBJECT The file object is invalid.
 *
 */
__FILE_RES __fileFlush(__PFILE file)
{
	return f_sync(file);
}

/*!
 * @brief Truncates the file size.
 *
 * From FatFS documentation
 * The f_truncate function truncates the file size to the current file read/write point. This function has
 * no effect if the file read/write pointer is already pointing end of the file.
 *
 * @param	file	Pointer to an opened file.
 * @return	Any of the following values:
 * @arg 	FR_OK (0)	The function succeeded.
 * @arg		FR_DENIED	The file has been opened in read-only mode.
 * @arg		FR_DISK_ERR	The function failed due to an error in the disk function.
 * @arg		FR_INT_ERR	The function failed due to a wrong FAT structure or an internal error.
 * @arg		FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg		FR_INVALID_OBJECT The file object is invalid.
 *
 */
__FILE_RES	__fileTruncate(__PFILE file)
{
	return f_truncate(file);
}

/*!
 * @brief Deletes a file
 *
 * From FatFS documentation:
 * The f_unlink function removes an object. Do not remove open objects.
 *
 * @param file	Pointer to a null-terminated string containing the file name.
 * @return Any of the following values:
 * @arg FR_OK (0)	The function succeeded.
 * @arg	FR_NO_FILE	Could not find the file or directory.
 * @arg	FR_NO_PATH	Could not find the path.
 * @arg	FR_INVALID_NAME The path name is invalid.
 * @arg	FR_INVALID_DRIVE The drive number is invalid.
 * @arg	FR_DENIED The function was denied due to either of following reasons:
					* The object has read-only attribute
					* Not empty directory
					* Current directory
 * @arg	FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg FR_WRITE_PROTECTED The medium is write protected.
 * @arg	FR_DISK_ERR The function failed due to an error in the disk function.
 * @arg FR_INT_ERR The function failed due to a wrong FAT structure or an internal error.
 * @arg FR_NOT_ENABLED The logical drive has no work area.
 * @arg FR_NO_FILESYSTEM There is no valid FAT volume on the drive.
 * @arg FR_LOCKED The function was rejected due to file sharing policy (_FS_SHARE)
 *
 */
__FILE_RES	__fileDelete(__CONST __PSTRING file)
{
	return f_unlink(file);
}

/*!
 * @brief Changes the attributes of a file or directory
 *
 * @param file 	Pointer to a null-terminated string containing the file name.
 * @param value A combination of the following flags:
 * @arg AM_RDO	Read only
 * @arg AM_ARC	Archive
 * @arg AM_SYS	System
 * @arg AM_HID	Hidden
 * @param mask	Attribute mask that specifies which attribute is changed. The specified attributes are
 * 				set or cleared.
 *
 * @return	Ant of the following values
 * @arg	FR_OK (0)	The function succeeded.
 * @arg	FR_NO_FILE	Could not find the file.
 * @arg FR_NO_PATH	Could not find the path.
 * @arg	FR_INVALID_NAME	The file name is invalid.
 * @arg FR_INVALID_DRIVE The drive number is invalid.
 * @arg FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg	FR_WRITE_PROTECTED The medium is write protected.
 * @arg FR_DISK_ERR The function failed due to an error in the disk function.
 * @arg FR_INT_ERR The function failed due to a wrong FAT structure or an internal error.
 * @arg FR_NOT_ENABLED The logical drive has no work area.
 * @arg FR_NO_FILESYSTEM There is no valid FAT volume on the drive.
 *
 */
__FILE_RES	__fileChmod(__CONST __PSTRING file, u8 value, u8 mask)
{
	return f_chmod(file, value, mask);
}

/*!
 * @brief Changes the timestamp of a file or directory.
 *
 * @param file	Pointer to a null-terminated string containing the file name.
 * @param fi	Pointer to the file information structure that has a timestamp to be set in member fdate
 * 				and ftime. Other members will be ignored.
 *
 * @return 	Any of the following values:
 * @arg FR_OK (0)	The function succeeded.
 * @arg	FR_NO_FILE	Could not find the file.
 * @arg	FR_NO_PATH	Could not find the path.
 * @arg	FR_INVALID_NAME The file name is invalid.
 * @arg	FR_INVALID_DRIVE The drive number is invalid.
 * @arg FR_NOT_READY The disk drive cannot work due to no medium in the drive or any other reason.
 * @arg	FR_WRITE_PROTECTED The medium is write protected.
 * @arg	FR_DISK_ERR The function failed due to an error in the disk function.
 * @arg FR_INT_ERR The function failed due to a wrong FAT structure or an internal error.
 * @arg FR_NOT_ENABLED The logical drive has no work area.
 * @arg FR_NO_FILESYSTEM There is no valid FAT volume on the drive.
 *
 */
__FILE_RES	__fileChangeTime(__CONST __PSTRING file, __CONST __PFILEINFO fi)
{
	return f_utime(file, fi);
}

/*!
 * @brief Renames a file or directory
 *
 * @param name1	Pointer to a null-terminated string containing the new file name.
 * @param name2	Pointer to a null-terminated string containing the old file name.
 *
 * @return Any of the following values:
 * @arg FR_OK (0)	The function succeeded.
 * @arg FR_NO_FILE	Could not find the old name.
 * @arg FR_NO_PATH Could not find the path.
 * @arg FR_INVALID_NAME	The file name is invalid.
 * @arg FR_INVALID_DRIVE The drive number is invalid.
 * @arg	FR_NOT_READY The disk drive cannot work due to no medium in the drive or any
 * 					 other reason.
 * @arg FR_EXIST The new name is colliding with an existing name.
 * @arg FR_DENIED The new name could not be created due to any reason.
 * @arg FR_WRITE_PROTECTED The medium is write protected.
 * @arg FR_DISK_ERR The function failed due to an error in the disk function.
 * @arg FR_INT_ERR The function failed due to a wrong FAT structure or an internal error.
 * @arg FR_NOT_ENABLED The logical drive has no work area.
 * @arg FR_NO_FILESYSTEM There is no valid FAT volume on the drive.
 * @arg FR_LOCKEDThe function was rejected due to file shareing policy (_FS_SHARE).
 *
 */
__FILE_RES	__fileRename(__CONST __PSTRING name1, __CONST __PSTRING name2);

/**
  * @}
  */

/** @defgroup FATFS_Functions FatFS functions
  * Fat functions.
  * @{
  */

/*!
 * @brief Initializes the disk drive.
 *
 * Description from FatFs documentation:
 *
 * The disk_initialize() function initializes a physical drive and put it ready to read/write.
 * When the function succeeded, STA_NOINIT flag in the return value is cleared.
 * Application program should not call this function, or FAT structure on the volume can be
 * collapsed. To re-initialize the file system, use f_mount() function.This function is called
 * on volume mount process in the FatFs module to manage the media change.
 *
 * @param drv	    Specifies the physical drive number to initialize.
 * @return			This function returns a disk status as the result. For details of the disk
 * 					status, refer to the disk_status function.
 */
__FATFS_STATUS disk_initialize (u8 drv)
{
	/* Get the device */
	__PDEVICE dv = __fatGetDevice(drv);
	if (!dv) return RES_NOTRDY;

	/* Call __deviceOpen. The device should return 0 on success.
	 * The device should be already registered with __deviceRegister().
	 */
	if (__deviceOpen(dv, 0) == 0) return RES_OK;
	return RES_ERROR;
}

/*!
 * @brief Returns the current disk status.
 *
 * Description from FatFs documentation:
 *
 * The disk status is returned in combination of following flags. FatFs refers only
 * STA_NOINIT and STA_PROTECTED.
 *
 * @param drv	   		Specifies the physical drive number to be confirmed.
 * @return				The disk status is returned in combination of following flags.
 * 						FatFs refers only STA_NOINIT and STA_PROTECTED.
 * @arg STA_NOINIT		Indicates that the disk drive has not been initialized. This flag is
 * 						set on: system reset, disk removal and disk_initialize function failed,
 * 						and cleared on: disk_initialize function succeeded.
 * @arg STA_NODISK		Indicates that no medium in the drive. This is always cleared on fixed
 * 						disk drive.
 * @arg STA_PROTECTED	Indicates that the medium is write protected. This is always cleared on
 * 						the drive that does not support write protect notch. Not valid when
 * 						STA_NODISK is set.
 */
__FATFS_STATUS disk_status (BYTE drv)
{
	__FATFS_STATUS ret = 0;
	__PDEVICE dv;

	/* Get the device */
	dv = __fatGetDevice(drv);
	if (!dv) return ret;

	switch (dv->dv_type)
	{
		/* SD/CF? */
		case __DEV_CFSD:
			if (__deviceIOCtl(dv, __IOCTL_WRITE_PROTECTED, 0, __NULL, 0))
			{
				ret |= STA_PROTECT;
			}

			if (!__deviceIOCtl(dv, __IOCTL_MEDIA_AVAILABLE, 0, __NULL, 0))
			{
				ret |= STA_NODISK;
			}
			break;
		default:
			/* TODO */
			ret = STA_NOINIT;
			break;
	}

	if (!dv->dv_rgcnt || !dv->dv_opcnt)
	{
		ret |= STA_NOINIT;
	}
	return ret;
}

/*!
 * @brief Controls device specified features and miscellaneous functions other than disk read/write.
 *
 * From FatFS documentation: The FatFs module uses only device independent commands described below.
 * Any device dependent function is not used.
 *
 * @param drv		Specifies the drive number (0-9).
 * @param ctrl		Specifies the command code.
 * @arg	CTRL_SYNC	Make sure that the disk drive has finished pending write process. When the disk
 * 					I/O module has a write back cache, flush the dirty sector immediately. This command
 * 					is not used in read-only configuration.
 * @arg GET_SECTOR_SIZE Returns sector size of the drive into the WORD variable pointed by Buffer. This
 * 					command is not used in fixed sector size configuration, _MAX_SS is 512.
 * @arg GET_SECTOR_COUNT Returns number of available sectors on the drive into the DWORD variable pointed
 * 					by Buffer. This command is used by only f_mkfs function to determine the volume size to
 * 					be created.
 * @arg GET_BLOCK_SIZE Returns erase block size of the flash memory in unit of sector into the DWORD variable
 * 					pointed by Buffer. The allowable value is 1 to 32768 in power of 2. Return 1 if the erase
 * 					block size is unknown or disk devices. This command is used by only f_mkfs function and it
 * 					attempts to align data area to the erase block boundary.
 * @arg CTRL_ERASE_SECTOR Erases a part of the flash memory specified by a DWORD array {start sector, end sector}
 * 					pointed by Buffer. When this feature is not supported or not a flash memory media, this command
 * 					has no effect. The FatFs does not check the result code and the file function is not affected
 * 					even if the sectors are not erased well. This command is called on removing a cluster chain when
 * 					_USE_ERASE is 1.
 * @param buff		Pointer to the parameter buffer depends on the command code. When it is not used,
 * 					specify a NULL pointer.
 *
 */
__FATFS_RES disk_ioctl (u8 drv, u8 ctrl, __PVOID buff)
{
	__FATFS_RES res = RES_ERROR;
	u8* ptr = (u8*) buff;
	__PDEVICE dv;

	/* Get the device */
	dv = __fatGetDevice(drv);
	if (!dv) return res;

	/* SC/CF? */
	if (dv->dv_type == __DEV_CFSD)
	{
		/* Power control code */
		if (ctrl == CTRL_POWER)
		{
			switch (*ptr) {
				/* Power off */
				case 0:
					if (__deviceIOCtl(dv, __IOCTL_GET_POWER_STATUS, 0, __NULL, 0)) {
						__deviceIOCtl(dv, __IOCTL_SET_POWER_STATUS, 0, __NULL, 0);
					}
					res = RES_OK;
					break;

				/* Power on */
				case 1:
					__deviceIOCtl(dv, __IOCTL_SET_POWER_STATUS, 1, __NULL, 0);
					res = RES_OK;
					break;

				/* Get power status */
				case 2:
					*(ptr+1) = (u8) __deviceIOCtl(dv, __IOCTL_GET_POWER_STATUS, 0, __NULL, 0);
					res = RES_OK;
					break;

				default:
					res = RES_PARERR;
			}
		} else
		{
			/* The next control codes need the device in ready state */
			if (disk_status(drv) & STA_NOINIT) return RES_NOTRDY;

			switch (ctrl)
			{
				/* Make sure that the disk drive has finished pending write process.
				 * When the disk I/O module has a write back cache, flush the dirty
				 * sector immediately. This command is not used in read-only configuration.
				 */
				case CTRL_SYNC:
					/* TODO flush cache */
					res = RES_OK;
					break;

				/* Returns number of available sectors on the drive into the DWORD variable
				 * pointed by Buffer. This command is used by only f_mkfs function to determine
				 * the volume size to be created.
				 */
				case GET_SECTOR_COUNT:
					*(u32*) buff = __deviceIOCtl(dv, __IOCTL_GET_SECTOR_COUNT, 0, __NULL, 0);
					res = RES_OK;
					break;

				/* Returns sector size of the drive into the WORD variable pointed by Buffer.
				 * This command is not used in fixed sector size configuration, _MAX_SS is 512.
				 */
				case GET_SECTOR_SIZE:
					*(u16*) buff = 512;
					res = RES_OK;
					break;

				/* Returns erase block size of the flash memory in unit of sector into the
				 * DWORD variable pointed by Buffer. The allowable value is 1 to 32768 in power
				 * of 2. Return 1 if the erase block size is unknown or disk devices. This command
				 * is used by only f_mkfs function and it attempts to align data area to the erase
				 * block boundary.
				 */
				case GET_BLOCK_SIZE:
					*(u32*) buff = __deviceIOCtl(dv, __IOCTL_GET_BLOCK_SIZE, 0, __NULL, 0);
					res = RES_OK;
					break;

				/* Get card type */
				case MMC_GET_TYPE:
					*ptr = (u8) __deviceIOCtl(dv, __IOCTL_GET_CARD_TYPE, 0, __NULL, 0);
					res = RES_OK;
					break;

				case MMC_GET_CSD:
					 __deviceIOCtl(dv, __IOCTL_GET_CSD, 0, __NULL, 0);
					res = RES_OK;
					break;

				case MMC_GET_CID:
					__deviceIOCtl(dv, __IOCTL_GET_CID, 0, __NULL, 0);
					res = RES_OK;
					break;

				case MMC_GET_OCR:
					__deviceIOCtl(dv, __IOCTL_GET_OCR, 0, __NULL, 0);
					res = RES_OK;
					break;

				case MMC_GET_SDSTAT:
					__deviceIOCtl(dv, __IOCTL_GET_SDSTAT, 0, __NULL, 0);
					res = RES_OK;
					break;

				default:
					res = RES_PARERR;
			}
		}
	}

	return res;
}

/*!
 * @brief Reads sector(s) from the disk drive.
 *
 * @param drv		Specifies the physical drive number.
 * @param buff		Pointer to the byte array to store the read data. The
 * 					buffer size of number of bytes to be read, sector
 * 					size * sector count, is required. Note that the specified
 * 					memory address is not that always aligned to word boundary.
 * 					If the hardware does not support misaligned data transfer,
 * 					it must be solved in this function.
 * @param sector	Specifies the start sector number in logical block address (LBA).
 * @param count		Specifies number of sectors to read. The value can be 1 to 128.
 * 					Generally, a multiple sector transfer request must not be split
 * 					into single sector transactions to the device, or you may not
 * 					get good read performance (TODO).
 * @return
 * @arg RES_OK (0)	The function succeeded.
 * @arg RES_ERROR   Any hard error occured during the read operation and could not recover it.
 * @arg RES_PARERR	Invalid parameter.
 * @arg RES_NOTRDY	The disk drive has not been initialized.
 *
 * @return	__TRUE on success, otherwise __FALSE.
 *
 */
__FATFS_RES disk_read (u8 drv, u8 *buff, u32 sector, u8 count)
{
	__PDEVICE dv;

	/* Get the device */
	dv = __fatGetDevice(drv);
	if (!dv) return RES_PARERR;

	/* Set the sector to read */
	if (dv->dv_type == __DEV_CFSD) __deviceIOCtl(dv, __IOCTL_SET_SECTOR, sector, __NULL, 0);
	if (__deviceRead(dv, buff, count) == 0) return RES_OK;

	return RES_ERROR;
}

/*!
 * @brief Writes sector(s) to the disk.
 *
 * @param drv		Specifies the physical drive number.
 * @param buff		Pointer to the byte array to be written. Note that the specified
 * 					memory address is not that always aligned to word boundary. If the
 * 					hardware does not support misaligned data transfer, it must be solved
 * 					in this function.
 * @param sector	Specifies the start sector number in logical block address (LBA).
 * @param count		Specifies the number of sectors to write. The value can be 1 to 128.
 * 					Generally, a multiple sector transfer request must not be split into
 * 					single sector transactions to the device, or you will never get good
 * 					write performance (TODO).
 * @return
 * @arg RES_OK (0)	The function succeeded.
 * @arg RES_ERROR   Any hard error occured during the read operation and could not recover it.
 * @arg RES_PARERR	Invalid parameter.
 * @arg RES_NOTRDY	The disk drive has not been initialized.
 *
 * @return
 * @arg RES_OK (0)	The function succeeded.
 * @arg RES_ERROR	Any hard error occured during the write operation and could not recover it.
 * @arg RES_WRPRT	The medium is write protected.
 * @arg RES_PARERR	Invalid parameter.
 * @arg RES_NOTRDY	The disk drive has not been initialized.
 */
__FATFS_RES disk_write (BYTE drv, __CONST u8 *buff,	u32 sector,	u8 count)
{
	__PDEVICE dv;

	/* Get the device */
	dv = __fatGetDevice(drv);
	if (!dv) return RES_PARERR;

	if (dv->dv_type == __DEV_CFSD)
	{
		if (__deviceIOCtl(dv, __IOCTL_WRITE_PROTECTED, 0, __NULL, 0))
		{
			return RES_WRPRT;
		}
	}

	/* Set the sector to write */
	if (dv->dv_type == __DEV_CFSD)
	{
		__deviceIOCtl(dv, __IOCTL_SET_SECTOR, sector, __NULL, 0);
	}

	/* Write */
	if (__deviceWrite(dv, buff, count) == 0) return RES_OK;

	return RES_ERROR;
}

/*!
 * @brief Gets current time.
 *
 * The get_fattime function must return any valid time even if the system
 * does not support a real time clock. If a zero is returned, the file will not
 * have a valid time. This function is not required in read only configuration.
 *
 * @return	Current time is returned with packed into a
 * 			DWORD value. The bit field is as follows:
 * 			bit31:25
 *				Year from 1980 (0..127)
 *			bit24:21
 *				Month (1..12)
 *			bit20:16
 *				Day in month(1..31)
 *			bit15:11
 *				Hour (0..23)
 *			bit10:5
 *				Minute (0..59)
 *			bit4:0
 *				Second / 2 (0..29)
 */
u32 get_fattime (__VOID)
{
	/* TODO */
	return (30 << 25 | 12 << 21 | 30 << 16 | 19 << 11 | 2 << 5 | 50);
}

#if _FS_REENTRANT
/*!
 * @brief FatFS synchronization object creation.
 *
 * From FatFS description: this function is called in f_mount function to
 * create a new synchronization object, such as semaphore and mutex. When
 * a FALSE is returned, the f_mount function fails with FR_INT_ERR.
 *
 * @param vol		Corresponding logical drive being processed.
 * @param _SYNC_t	Pointer to return the created sync object.
 *
 * @return	__TRUE on success, otherwise __FALSE.
 *
 */
__BOOL ff_cre_syncobj (u8 vol, _SYNC_t *sobj)
{
	__BOOL ret = __FALSE;

	*sobj = __lockCreate();
	ret = (*sobj != __NULL) ? __TRUE : __FALSE;

	return ret;
}


/*!
 * @brief FatFS deletes a synchronization object.
 *
 * From FatFS description: This function is called in f_mount function
 * to delete a synchronization object that created with ff_cre_syncobj
 * function. When a FALSE is returned, the f_mount function fails with FR_INT_ERR.
 *
 * @param _SYNC_t	Sync object tied to the logical drive to be deleted.
 *
 * @return	__TRUE on success, otherwise __FALSE.
 *
 */
BOOL ff_del_syncobj (_SYNC_t sobj) {
	__lockDestroy(sobj);
	return __TRUE;
}

/*!
 * @brief FatFS requests grant to access the volume.
 *
 * From FatFS description: This function is called on entering
 * file functions to lock the volume. When a FALSE is returned,
 * the file function fails with FR_TIMEOUT.
 *
 * @param _SYNC_t	Sync object to wait.
 *
 * @return	__TRUE on success, otherwise __FALSE.
 *
 */
BOOL ff_req_grant(_SYNC_t sobj) {
__BOOL ret;

	ret = __lockOwn(sobj, _FS_TIMEOUT);
	return ret;
}

/*!
 * @brief FatFS releases grant to access the volume.
 *
 * From FatFS description: This function is called on leaving
 * file functions to unlock the volume.
 *
 * @param _SYNC_t	Sync object to be signaled.
 *
 * @return	Nothing.
 *
 */
__VOID ff_rel_grant (_SYNC_t sobj)
{
	__lockRelease(sobj);
}

#endif


#if _USE_LFN == 3	/* LFN with a working buffer on the heap */

/*!
 * @brief FatFS allocates a memory block.
 *
 * From FatFS description: If a NULL is returned, the file function fails
 * with FR_NOT_ENOUGH_CORE.
 *
 * @param size	Requested block size, in bytes.
 *
 * @return	A pointer to a newly allocated memory block. __NULL on failure.
 *
 */
__PVOID ff_memalloc (UINT size)
{
	return __heapAlloc(size);
}

/*!
 * @brief FatFS frees a memory block.
 *
 * @param __PVOID mblock	Pointer to a memory block previously allocated
 * 							with ff_memalloc().
 *
 * @return	Nothing.
 *
 */
__VOID ff_memfree(__PVOID mblock)
{
	__heapFree(mblock);
}

#endif // _USE_LFN

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif // __CONFIG_COMPILE_FAT
