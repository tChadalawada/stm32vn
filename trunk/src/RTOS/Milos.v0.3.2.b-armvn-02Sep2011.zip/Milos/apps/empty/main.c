#include <core/system.h>
#include <core/thread.h>

/*
 * Thread 1
 */
__VOID threadTest1(__VOID)
{
	GPIO_InitTypeDef  GPIO_InitStructure;
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12 ;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_10MHz;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB , ENABLE);	

	GPIO_Init(GPIOB, &GPIO_InitStructure);
	for (;;)
	{
	/* Infinite loop */
  	
		GPIO_WriteBit(GPIOB, GPIO_Pin_8, Bit_SET);
		GPIO_WriteBit(GPIOB, GPIO_Pin_9, Bit_SET);
		GPIO_WriteBit(GPIOB, GPIO_Pin_10, Bit_SET);
		GPIO_WriteBit(GPIOB, GPIO_Pin_11, Bit_SET);
		GPIO_WriteBit(GPIOB, GPIO_Pin_12, Bit_SET);
		__threadSleep(1000);
		GPIO_WriteBit(GPIOB, GPIO_Pin_8, Bit_RESET);
		GPIO_WriteBit(GPIOB, GPIO_Pin_9, Bit_RESET);
		GPIO_WriteBit(GPIOB, GPIO_Pin_10, Bit_RESET);
		GPIO_WriteBit(GPIOB, GPIO_Pin_11, Bit_RESET);
		GPIO_WriteBit(GPIOB, GPIO_Pin_12, Bit_RESET);
		
		__threadSleep(1000);
	
	}
}

/*
 * Thread 2
 */
__VOID threadTest2(__VOID)
{
	for (;;)
	{
		__threadSleep(1);
	}
}

/*!
 * @brief Application entry point.
 */
__VOID appEntry(__VOID)
{
	__threadCreate("test1", threadTest1, 80, 512, 1, __NULL);
	__threadCreate("test2", threadTest2, 81, 512, 1, __NULL);
}

/*!
 * @brief Program entry point.
 */
int main(void)
{
	__systemInit(appEntry);
	return 0;
}
