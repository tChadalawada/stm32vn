#include <core/system.h>
#include <core/thread.h>
#include <common/mem.h>
#include <common/string.h>
#include <drivers/gps/gps.h>
#include <drivers/charlcd/charlcd.h>

/* Keep GPS data locally in this structure */
__GPS_DATA appGpsData;

/*
 * Thread 1
 */
__VOID threadTest1(__VOID)
{
	/* LCD String */
	__STRING buf[17];

	/* Give the terminal time to start */
	__threadSleep(1000);

	/* Register and open GPS driver */
	__deviceRegister(__GPS, 0, 0, 0);
	__deviceOpen(__GPS, 0);

	/* Register and open Character LCD driver */
	__deviceRegister(__CHARLCD, 16, 2, 0);
	__deviceOpen(__CHARLCD, __CHARLCD_MODE_4_BITS);

	for (;;)
	{
		/* Read from GPS driver into our appGpsData structure */
		__deviceRead(__GPS, &appGpsData, sizeof(appGpsData));

		/* Tell the char lcd we're writing from the beginning */
		__deviceIOCtl(__CHARLCD, __IOCTL_SET_LINE, 1, __NULL, 0);
		__deviceIOCtl(__CHARLCD, __IOCTL_SET_COLUMN, 1, __NULL, 0);

		/* The formatting below needs conversion (we're displaying values
		 * in thousands-of-minutes format!).
		 */

		/* Format latitude and write to display */
		__strFmt(buf, "Lat: %li\r\n", (i32) appGpsData.rmc.lat);
		__deviceWrite(__CHARLCD, buf, __strLen(buf));

		/* Format longitude and write to display */
		__strFmt(buf, "Lon: %li", (i32) appGpsData.rmc.lon);
		__deviceWrite(__CHARLCD, buf, __strLen(buf));

		/* Do the above each 1000 ms */
		__threadSleep(1000);
	}
}

/*!
 * @brief Application entry point.
 */
__VOID appEntry(__VOID)
{
	/* Create a thread to read from GPS and show values on the display */
	__threadCreate("test1", threadTest1, 250, 512, 1, __NULL);
}

/*!
 * @brief Program entry point.
 */
int main(void)
{
	/* Call OS initialization */
	__systemInit(appEntry);
	return 0;
}
