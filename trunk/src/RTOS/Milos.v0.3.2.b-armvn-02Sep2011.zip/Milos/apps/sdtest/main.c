#include <core/system.h>
#include <core/terminal.h>
#include <core/heap.h>
#include <common/mem.h>
#include <common/string.h>
#include <drivers/sd/sd.h>
#include <fs/fat.h>

/* How many threads/files */
#define APP_THREADS 		4

/* File array */
__PFILE files[APP_THREADS];

/* Buffer to write */
__PSTRING buffer;

/* Resulting buffer size */
u32 buffer_size;

/*
 * Creates and fills array of bytes repeating the 'repeat' parameter
 * until buffer's 'size'.
 */
__BOOL CreateBuffer(u32 size, __PSTRING repeat)
{
	u32 offs = 0;
	u32 str_len = __strLen(repeat);

	buffer = __heapAlloc(size);
	if (!buffer) return __FALSE;

	while (offs < size)
	{
		if ((size - offs) < str_len)
		{
			__memCpy(buffer+offs, repeat, (size - offs));
			offs = size;
		} else {
			__memCpy(buffer+offs, repeat, str_len);
			offs += str_len;
		}
	}

	buffer_size = offs;
	return __TRUE;
}

/*
 * Thread that writes to the file passed as the thread parameter.
 */
__VOID fileThread(__VOID)
{
	/* Get the file passed as the thread parameter in the __threadCreate() call */
	__PFILE file = (__PFILE) __threadGetParameter();
	u32 cnt;

	while (1)
	{
		/* Write */
		cnt = __fileWrite(file, buffer, buffer_size);

		/* Check return size */
		if (cnt != buffer_size)
		{
			/* Show some error */
			DBGMSG(TRUE, ("%s: write count error (cnt = %lu len = %lu)",__threadGetCurrent()->th_name,
																		(u32) cnt,
																		(u32) buffer_size));
		}

		/* Pass the control to the next thread */
		__threadYield();

		/* Flush the file */
		if (__fileFlush(file) != FR_OK)
		{
			DBGMSG(TRUE, ("%s: flush error", __threadGetCurrent()->th_name));
		}

		/* Pass the control to the next thread */
		__threadYield();
	}


	for (;;)
	{
		__threadSleep(1);
	}
}

/*
 * Opens the SD driver, mounts the FS, creates the files and the threads, then
 * goes to sleep.
 */
__VOID appThread(__VOID)
{
	u8 i = 0;
	__STRING thname[16];
	__STRING filename[13];

	__threadSleep(1000);
	__deviceRegister(__SD_1, 0, 0, 0);

	if (CreateBuffer(1024, "0123456789\r\n"))
	{
		if (__fatMount(0, __SD_1) == __NULL)
		{
			DBGMSG(TRUE, ("Unable mount __SD_1"));
		} else
		{
			for (i = 0; i < APP_THREADS; i++)
			{
				__strFmt(filename, "file%lu.txt", (u32) i+1);
				files[i] = __fileOpen(filename, __FILE_WRITE | __FILE_CREATE_ALWAYS);

				if (!files[i])
				{
					DBGMSG(TRUE, ("Error creating %s file", filename));
				} else {
					DBGMSG(TRUE, ("File %s created", filename));
					__strFmt(thname, "thread%lu", (u32) i+1);
					__threadCreate(thname, fileThread, __CONFIG_PRIO_TERMTHREAD+1, 768, 1, files[i]);
				}
			}
		}
	} else {
		DBGMSG(TRUE, ("Error creating buffer"));
	}

	for (;;)
	{
		__threadSleep(1000);
	}
}


__VOID appMain(__VOID)
{
	__threadCreate("appth", appThread, __CONFIG_PRIO_TERMTHREAD, 1024, 1000, __NULL);
}

i32 main(__VOID)
{
	__systemInit(appMain);
	for(;;);
}
