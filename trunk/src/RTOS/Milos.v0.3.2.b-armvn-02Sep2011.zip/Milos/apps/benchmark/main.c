#include <common/common.h>
#include <core/system.h>
#include <core/lock.h>
#include <core/thread.h>
#include <core/terminal.h>
#include <core/timer.h>
#include <drivers/serial/serial.h>


#define LOCK_TEST 10
__PLOCK locks[LOCK_TEST];
__EVENT ev;
__PTHREAD pNst;
__PTHREAD thread1;
__PTHREAD thread2;

__VOID threadDestroyTest(__VOID)
{
	u32 count = 0;
	__STRING name[16];

	for (;;)
	{
		count++;
		if (count > 1000)
		{
			if (__threadFindName("destroy1"))
			{
				__strCpy(name, "destroy2");
			} else {
				__strCpy(name, "destroy1");
			}

			__threadCreate(name, threadDestroyTest, 100, 256, 1, __NULL);
			__threadDestroy(__threadGetCurrent());
		}

		__threadSleep(1);
	}
}

__VOID threadTest(__VOID)
{
	u8 idx = 0;

	for (;;)
	{
		if (__lockOwn(locks[idx], 100))
		{
			__threadSleep(500);
			__lockRelease(locks[idx]);				
		}
		
		idx++;
		if (idx == LOCK_TEST) idx = 0;
	}
}

__VOID appTimer1(__PVOID param)
{

}

__VOID appTimer2(__PVOID param)
{

}

__VOID appNonSleepingThread(__VOID)
{

	for (;;)
	{

	}
}

__VOID threadTest1(__VOID)
{

	for (;;)
	{
		__eventReset(&ev);
		__eventWait(&ev, 0);
		__pinSet(GPIOB, GPIO_Pin_11, __FALSE);
	}
}

		
__VOID threadTest2(__VOID)
{

	for (;;)
	{
		__threadSleep(100);
		__pinSet(GPIOB, GPIO_Pin_11, __TRUE);
		__pinSet(GPIOB, GPIO_Pin_11, __FALSE);

		__pinSet(GPIOB, GPIO_Pin_11, __TRUE);

		__eventSet(&ev);
	}
}

__VOID appEntry(__VOID)
{

	u8 i = 0;
	__STRING name[4];

	__timerCreate(__TM_NORMAL, 100, appTimer1, __NULL);
	__timerCreate(__TM_NORMAL, 500, appTimer2, __NULL);

	for (i = 0; i < LOCK_TEST; i++)
	{
		locks[i] = __lockCreate();
	}

	for (i = 0; i < LOCK_TEST+5; i++)
	{
		name[0] = 'T';
		name[1] = '_';
		name[2] = 0x41 + i;
		name[3] = 0;
						
		__threadCreate(name, threadTest, 101, 512, i, __NULL);
	}

	thread1 = __threadCreate("test1", threadTest1, 1, 512, 1, __NULL);
	thread2 = __threadCreate("test2", threadTest2, 2, 512, 1, __NULL);
	pNst = __threadCreate("nst", appNonSleepingThread, 255, 256, 100, __NULL);

}

int main(void)
{
	__systemInit(appEntry);

	return 0;
}
