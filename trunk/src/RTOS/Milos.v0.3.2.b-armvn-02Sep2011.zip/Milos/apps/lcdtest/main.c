#include <core/system.h>
#include <core/thread.h>
#include <core/terminal.h>
#include <drivers/charlcd/charlcd.h>
#include <common/string.h>
#include <common/mem.h>

/*
 * This function will be called by the terminal thread to give the application
 * the possibility to parse some commands. In this case we will be parsing the "lcd" command.
 *
 * By writing "lcd " + a string, it will be output to the char lcd display.
 * If the string following "lcd " is null, then the display screen is cleared.
 * If the string is "crlf" then a "\r\n" will be sent to the display, to go to the next line
 * or to scroll the screen if __CHARLCD_MODE_SCROLL is enabled.
 */
__STATIC __BOOL appTerminalCmd(__PSTRING cmd)
{
	if (__strnCmpNoCase(cmd, "lcd ", 4) == 0)
	{
		if (__strLen(cmd + 4))
		{
			if (__strnCmpNoCase(cmd + 4, "crlf", 2) == 0)
			{
				__deviceWrite(__CHARLCD, "\r\n", 2);
			} else {
				__deviceWrite(__CHARLCD, cmd + 4, __strLen(cmd + 4));
			}
		} else {
			__deviceWrite(__CHARLCD, __NULL, 0);
		}

		return __TRUE;
	}

	return __FALSE;
}


/*
 * Thread 1
 */
__VOID threadTest1(__VOID)
{
	/* Wait for terminal */
	__threadSleep(1000);

	/* Register the Character LCD driver and open it */
	__deviceRegister(__CHARLCD, 16, 2, 0);
	__deviceOpen(__CHARLCD, __CHARLCD_MODE_4_BITS | __CHARLCD_MODE_SCROLL | __CHARLCD_MODE_CURSOR);

	/* Tell the terminal that the appTerminalCmd() function should be called
	 * when a command is written.
	 */
	__terminalSubscribe(appTerminalCmd);

	for (;;)
	{
		/* Do nothing */
		__threadSleep(1);
	}
}


/*!
 * @brief Application entry point.
 */
__VOID appEntry(__VOID)
{
	/* Create our thread */
	__threadCreate("test1", threadTest1, 80, 512, 1, __NULL);
}

/*!
 * @brief Program entry point.
 */
int main(void)
{
	__systemInit(appEntry);
	return 0;
}
