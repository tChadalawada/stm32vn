#include <core/system.h>
#include <core/thread.h>
#include <core/queue.h>
#include <core/terminal.h>
#include <core/heap.h>
#include <common/string.h>

__QUEUE queue1;

__VOID threadTest1(__VOID)
{
u8 i;
__STRING buf[32];

	__threadSleep(1000);

	__queueCreate(__QUEUE_ALLOC, &queue1, 0, 0, __NULL, 0);

	for (;;)
	{
		if (__queueWaitForEmpty(&queue1, 1000))
		{
			for (i = 0; i < 50; i++)
			{
				__strFmt(buf, "%lu %lu", (u32) __systemGetTickCount(), __heapAvailable());
				__queueAdd(&queue1, buf, __strLen(buf));
			}
		}
	}
}

__VOID threadTest2(__VOID)
{
	u32 size = 0;
	u8 data[32];

	for (;;)
	{
		while (!__queueIsReady(&queue1)) __threadSleep(1);

		while (__queueWaitForData(&queue1, 1000))
		{
			if (__queueGet(&queue1, __NULL, &size) && size)
			{
				if (__queueGet(&queue1, &data, &size))
				{
					DBGMSG(1, ("Dequeued: %s", data));
				}
			}
		}
	}
}


__VOID appEntry(__VOID)
{
	__threadCreate("test1", threadTest1, 80, 512, 1, __NULL);
	__threadCreate("test2", threadTest2, 81, 512, 1, __NULL);
}

int main(void)
{
	__systemInit(appEntry);
	return 0;
}
