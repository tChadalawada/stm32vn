/***************************************************************************
 * @file	terminal.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef __TERMINAL_H__
#define __TERMINAL_H__

#include <plat_cpu.h>

#if __CONFIG_TERMINAL_ENABLED

/** @addtogroup Terminal
  * @{
  */

/** @defgroup Terminal_FunctionPrototypes Prototypes
  * @{
  */

typedef __BOOL (__TERMINALFUNC)(__PSTRING str);

/**
  * @}
  */

/** @defgroup Terminal_Macros Macros
  * @{
  */

/*! @brief Terminal output with CR/LF */
#define DBGMSG(cond, exp) ((cond)?(__terminalWriteLine exp), __TRUE : __FALSE)
/*! @brief Terminal output without CR/LF */
#define DBGOUT(cond, exp) ((cond)?(__terminalWrite exp), __TRUE : __FALSE)

/**
  * @}
  */


__VOID __terminalInit(u8 enable_echo);
__VOID __terminalWrite(__CONST __PSTRING str, ...);
__VOID __terminalWriteLine(__CONST __PSTRING str, ...);
__VOID __terminalWriteChar(u8 c);
__BOOL __terminalSubscribe(__TERMINALFUNC* func);
__VOID __terminalUnSubscribe(__VOID);

/**
  * @}
  */

#else
/* define terminal macros */
#define DBGMSG(cond, exp)
#define DBGOUT(cond, exp)

#endif // __CONFIG_TERMINAL_ENABLED

#endif // __TERMINAL_H__
