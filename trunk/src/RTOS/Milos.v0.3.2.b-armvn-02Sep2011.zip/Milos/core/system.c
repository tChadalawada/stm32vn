/***************************************************************************
 * system.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "system.h"
#include "systerminal.h"
#include "heap.h"
#include "thread.h"
#include "timer.h"
#include "device.h"
#if __CONFIG_TERMINAL_ENABLED
#include "terminal.h"
#endif // __CONFIG_TERMINAL_ENABLED

/** @defgroup Milos Milos
  * @{
  */

/** @defgroup Driver Device drivers
  * @{
  */

/**
  * @}
  */

/** @defgroup Platform Platform
  * Platform-dependent code.
  * @{
  */

/**
  * @}
  */

/** @defgroup Core Core
  * @{
  */

/** @defgroup System System
  * @brief System functions.
  * @{
  */

/** @defgroup System_PrivateVariables Private variables
  * @{
  */

__BOOL 			__systemReset = __FALSE;		/*!< @brief Global flag, stops watchdog */
__APP_ENTRY* 	__systemAppEntry = __NULL;		/*!< @brief Application entry point */
__VOLATILE u32	__systemIrqCount;				/*!< @brief Keeps track of disabled IRQ */
__VOLATILE u32	__systemTickCount = 0;			/*!< @brief System ticks counter */
__VOLATILE u32	__systemContextSwCount = 0;		/*!< @brief Keeps track of disabled context switching */
__VOLATILE u32	__systemNestingISR = 0;			/*!< @brief Keeps track of ISR calls */
__PTHREAD		__systemThreadPtr;
__VOLATILE u8	__systemContextSwRequest;		/*!< @brief Context switch requested */
/**
  * @}
  */

/** @defgroup System_Functions Functions
  * @{
  */


/*!
 * @brief System thread.
 *
 * Internal thread, created after system initialization (__systemCreateThread() function).
 * Calls the application's entry point and \c should perform maintenance tasks.
 * @return Nothing.
 * @todo Add maintenance tasks.
 * @todo Add __heapDefrag() as user option.
 */
__VOID __systemThread(__VOID)
{

	/* Start thread for software timers */
	__timerInit(__CONFIG_STACK_TIMTHREAD);

	/* Initialize Terminal if enabled */
#if __CONFIG_TERMINAL_ENABLED
	__terminalInit(__TRUE);
#endif // __CONFIG_TERMINAL_ENABLED

	if (__systemAppEntry)
	{
		(__systemAppEntry)();
	}
	
	for(;;)
	{
	
		if (!__systemReset)
		{
			__cpuResetWatchdog();
		}
		
		__cpuHeartBeat();
		__threadSleep(__CONFIG_SYSTHREAD_SLEEP_TIME);
	}
}

/*!
 * @brief Creates the system threads.
 *
 * Internal use. Called from __systemInit() function.
 * @return Nothing.
 */
__STATIC __VOID __systemInitThread(__VOID)
{

	/* Create system thread */
	__systemThreadPtr = __threadCreate(	"system",						/* name 		*/
										__systemThread,					/* function 	*/
										__CONFIG_PRIO_SYSTHREAD,		/* priority 	*/
										256,							/* stack 		*/
										1,								/* time to live */
										__NULL);						/* parameter 	*/

	/* Call platform custom initialization before activating
	 * the scheduler
	 */
	__cpuCustomCreateSystemThread();
}

/*!
 * @brief System initialization.
 *
 * Call this function to start the OS. Provide an __APP_ENTRY() function pointer that will be called
 * from the System thread upon initialization. This function is intended to never return, the application
 * will take control of the system from the __APP_ENTRY() function.
 * @return Nothing.
 */
__VOID __systemInit(__APP_ENTRY* entry)
{
	/* Avoid interrupts we are not handling yet */
	__systemStop();
	
	__systemAppEntry = entry;
	
	/* Init CPU hardware */
	__cpuInitHardware();
	
	/* MMU */
	__cpuStartMMU();

	/* Init Interrupts */
	__cpuInitInterrupts();

	/* Init Heap */
	__heapInit(&__CPU_HEAP_BASE, (u32) &__CPU_HEAP_SIZE);

	/* Init Watchdog */
	__cpuStartWatchdog();
	
	/* Create System Threads */
	__systemInitThread();

	/* Init Scheduler timer after creating the first thread */
	__cpuInitSchedulerTimer();

	__systemScheduleThreadChange();

	/* Enable interrupts */
	__systemStart();

	/* If everything is OK, we should be running the OS by now.
	 * This function will never return. __systemThread() will now enter execution under
	 * the context of the OS.
	 */
	for (;;)
	{
	}
}

#if __CONFIG_TERMINAL_ENABLED
/*!
 * @brief System terminal callback.
 *
 * Internal use. This function will parse the command input from the terminal before
 * any other parser, to detect and execute system related commands (like the "heap" command).
 * @return __TRUE if the command was recognized by the __stTerminalIn() function, otherwise __FALSE.
 */
__BOOL __systemTerminalIn(__PSTRING str)
{
	return __stTerminalIn(str);
}
#endif // __CONFIG_TERMINAL_ENABLED

/*!
 * @brief Manages the system tick timer.
 *
 * Called from platform implementation of the system tick timer.
 * @return Nothing.
 */
__VOID __systemProcessTick(__VOID)
{
	/* Software system ticks */
	__systemTickCount++;
	__threadProcessTick();
}

/*!
 * @brief Disables interrupts.
 *
 * @return Nothing.
 */
__VOID __systemStop(__VOID)
{
	if (!__systemIrqCount)
	{
		__cpuDisableInterrupts();
	}
	__systemIrqCount++;
}

/*!
 * @brief Enables interrupts.
 *
 * @return Nothing.
 */
__VOID __systemStart(__VOID)
{
	if (__systemIrqCount && --__systemIrqCount) {
		return;
	}

	/* enable interrupts */
	__cpuEnableInterrupts();
}


/*!
 * @brief Enables scheduler.
 *
 * Enables context switching.
 * This function will check if a previous request from a context change was made, while the scheduler
 * was disabled. If so, and the first thread in the ready list has a higher priority than the current one,
 * a context switch will take place.
 *
 * @return Nothing.
 */
__VOID __systemEnableScheduler(__VOID)
{
	__systemStop();
	if (__systemContextSwCount)
	{
		__systemContextSwCount--;

		/* Check for pending thread change request */
		if (!__systemContextSwCount && __systemContextSwRequest)
		{
			__systemContextSwRequest = 0;

			/* Check if there is a ready thread with higher priority
			 * than the current one.
			 */
			if (__threadGetCurrent()) {
				if (__threadGetCurrent()->th_priority > __threadGetReady()->th_priority)
				{
					__threadAddToReadyList(__threadGetCurrent());
					__threadSetCurrent(__NULL);
					__systemScheduleThreadChange();
				}
			}
		}
	}
	__systemStart();
}

/*!
 * @brief Disables scheduler.
 *
 * Disables context switching.
 * @return Nothing.
 */
__VOID __systemDisableScheduler(__VOID)
{
	__systemStop();
	__systemContextSwCount++;
	if (__cpuThreadChangeScheduled())
		__cpuClearPendingThreadChange();
	__systemStart();
}

/*!
 * @brief Schedules a context change.
 *
 * @return Nothing.
 */
__VOID __systemScheduleThreadChange(__VOID)
{
	if (!__systemContextSwCount)
	{
		__cpuScheduleThreadChange();
	} else
	{
		__systemContextSwRequest = 1;
	}
}

/*!
 * @brief Enter ISR
 *
 * @return Nothing.
 */
__VOID __systemEnterISR(__VOID)
{
	__systemNestingISR++;
}

/*!
 * @brief Leave ISR
 *
 * @return Nothing.
 */

__VOID __systemLeaveISR(__VOID)
{
	__systemNestingISR--;
}


u32 __systemGetTickCount(__VOID)
{
	return __systemTickCount;
}

u32 __systemGetIrqCount(__VOID)
{
	return __systemIrqCount;
}

__BOOL __systemSchedulerDisabled(__VOID)
{
	if (__systemContextSwCount) return __TRUE;
	return __FALSE;
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */


