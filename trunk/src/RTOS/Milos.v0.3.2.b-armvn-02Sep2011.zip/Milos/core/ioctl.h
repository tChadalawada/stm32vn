/***************************************************************************
 * @file	ioctl.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

/*
 * Main file for IOCTL codes definitions.
 * New IOCTL codes should be appended at the end.
 * IOCTL code from __deviceIOCtl() function is a 32-bit value
 * so there are 0xFFFFFFFF values left to declare.
 * In many cases a single ioctl code should be reused in different
 * drivers.
 */

#define	__IOCTL_SETBAUD				0				/*!< @brief Set baud rate */
#define	__IOCTL_GETBAUD				1				/*!< @brief Get baud rate */
#define	__IOCTL_SETBITS				2				/*!< @brief Set bits */
#define	__IOCTL_GETBITS				3				/*!< @brief Get bits */
#define	__IOCTL_SETPARITY			4				/*!< @brief Set parity */
#define	__IOCTL_GETPARITY			5				/*!< @brief Get parity */
#define	__IOCTL_SETSTOP				6				/*!< @brief Set stop bit */
#define	__IOCTL_GETSTOP				7				/*!< @brief Get stop bit */
#define	__IOCTL_SETRXTIMEOUT		8				/*!< @brief Set RX timeout */
#define	__IOCTL_GETRXTIMEOUT		9				/*!< @brief Get RX timeout */
#define	__IOCTL_SETTXTIMEOUT		10				/*!< @brief Set TX timeout */
#define	__IOCTL_GETTXTIMEOUT		11				/*!< @brief Get TX timeout */
#define __IOCTL_ECHO_ONOFF			12				/*!< @brief ECHO enable/disable */
#define __IOCTL_ECHO				13				/*!< @brief Get ECHO */
#define	__IOCTL_SETRTS				14				/*!< @brief Set RTS */
#define	__IOCTL_SETDTR				15				/*!< @brief Set DTR */
#define __IOCTL_ASSERT_CS			16				/*!< @brief Enable Chip Select generation */
#define __IOCTL_SET_CS				17				/*!< @brief Set Chip Select */
#define __IOCTL_MEDIA_AVAILABLE		18				/*!< @brief MMC/SD available */
#define __IOCTL_WRITE_PROTECTED		19				/*!< @brief Media is write protected */
#define __IOCTL_SET_SECTOR			20				/*!< @brief Set sector */
#define __IOCTL_GET_SECTOR			21				/*!< @brief Get sector */
#define __IOCTL_GET_POWER_STATUS	22			 	/*!< @brief Get device's power status */
#define __IOCTL_SET_POWER_STATUS	23			 	/*!< @brief Set device's power status */
#define __IOCTL_GET_SECTOR_COUNT	24 				/*!< @brief Retrieve sector count */
#define __IOCTL_GET_BLOCK_SIZE		25				/*!< @brief Get Block size */
#define __IOCTL_GET_CARD_TYPE		26				/*!< @brief Get Card type */
#define __IOCTL_GET_CSD				27				/*!< @brief Get Card Specific Data */
#define __IOCTL_GET_CID				28 				/*!< @brief Get CID */
#define __IOCTL_GET_OCR				29 				/*!< @brief Get OCR */
#define __IOCTL_GET_SDSTAT			30 				/*!< @brief Get SD status */
#define __IOCTL_GET_FIX_FLAG		31				/*!< @brief For GPS, returns the FIX flag */
#define __IOCTL_TERMINAL_OUTPUT		32				/*!< @brief Enables/disables terminal output */
#define __IOCTL_SET_LINE			33				/*!< @brief Sets the cursor at a given line (display) */
#define __IOCTL_SET_COLUMN			34				/*!< @brief Sets the cursor at a given column (display) */
#define __IOCTL_CLEAR_LINE			35				/*!< @brief Clears a line (display) */
#define __IOCTL_CLEAR_SCREEN		36				/*!< @brief Clears the screen (display) */
