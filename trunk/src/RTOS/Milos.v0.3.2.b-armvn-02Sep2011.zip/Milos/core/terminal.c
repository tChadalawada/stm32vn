/***************************************************************************
 * @file	terminal.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "terminal.h"
#include "lock.h"
#include "heap.h"
#include <common/string.h>
#include <common/mem.h>

#if (__CONFIG_TERMINAL_ENABLED && __CONFIG_COMPILE_STRING)

/* @if 0 */
#include __CONFIG_TERMINAL_INCLUDES
/* @endif */

/** @addtogroup Core
  * @{
  */

/** @defgroup Terminal Terminal
  * Terminal functions.
  * @{
  */

/** @defgroup Terminal_PrivateConstants Private constants
  * @{
  */

#define __SK_BASE			0x1000
#define __SK_UNKNOWN		0xFFFF
#define __SK_ESCAPE			__SK_BASE
#define __SK_UPARROW		__SK_BASE + 1
#define __SK_DOWNARROW		__SK_BASE + 2
#define __SK_RIGHTARROW		__SK_BASE + 3
#define __SK_LEFTARROW		__SK_BASE + 4
#define __SK_BREAK			__SK_BASE + 5
#define __SK_INS			__SK_BASE + 6
#define __SK_HOME			__SK_BASE + 7
#define __SK_PGUP			__SK_BASE + 8
#define __SK_DEL			__SK_BASE + 9
#define __SK_END			__SK_BASE + 10
#define __SK_PGDN			__SK_BASE + 11
#define __SK_F1				__SK_BASE + 12
#define __SK_F2				__SK_BASE + 13
#define __SK_F3				__SK_BASE + 14
#define __SK_F4				__SK_BASE + 15
#define __SK_F5				__SK_BASE + 16
#define __SK_F6				__SK_BASE + 17
#define __SK_F7				__SK_BASE + 18
#define __SK_F8				__SK_BASE + 19
#define __SK_F9				__SK_BASE + 20
#define __SK_F10			__SK_BASE + 21
#define __SK_F11			__SK_BASE + 22
#define __SK_F12			__SK_BASE + 23
#define	__TERMINAL_PROMPT	"milos> "

/**
  * @}
  */

extern __BOOL __systemTerminalIn(__PSTRING str);


/** @defgroup Terminal_PrivateTypeDefs Private typedefs
  * @{
  */

typedef struct __terminalSubsTag {

	__BOOL 				active;
	__TERMINALFUNC*		func;
	__PTHREAD			thread;	

} __SUBS, *__PSUBS;					/*!< @brief Terminal subscribers. */

/**
  * @}
  */

/** @defgroup Terminal_PrivateVariables Private variables
  * @{
  */

__PDEVICE	__terminalDevice;									/*!< @brief Terminal device pointer. */
__SUBS		__terminalSubs[__CONFIG_TERM_MAX_SUBSCRIBERS];		/*!< @brief Terminal subscribers array. */
__BOOL		__terminalStarted = __FALSE;						/*!< @brief Terminal started flag. */
__PLOCK		__terminalLock;										/*!< @brief Terminal lock pointer. */

__PSTRING	__terminalTxLine;						/*!< @brief Terminal current tx line. */
__PSTRING	__terminalRxLine;						/*!< @brief Terminal current rx line. */
u16			__terminalRxOffs = 0;					/*!< @brief Terminal current rx line offset. */
u16			__terminalCursor = 0;					/*!< @brief Cursor position. */
__PTHREAD	__terminalThreadPtr;					/*!< @brief Terminal thread pointer. */

__CONST __STRING __terminalESC[] 	= {0x1b, 0x5b};
__CONST __STRING __terminalBackspace[] 	= {0x1b, 0x5b, '1', 'D', 0x1b, 0x5b, '0', 'K', 0x00};
__CONST __STRING __terminalClearScreen[] = {0x1b, 0x5b, '2', 'J', 0x00};
__CONST __STRING __terminalShowCursor[]  = {0x1b, 0x5b, '?', '2', '5', 'h', 0x00};
__CONST __STRING __terminalHideCursor[]  = {0x1b, 0x5b, '?', '2', '5', 'l', 0x00};

u8 __terminalEcho = 0;								/*!< @brief Character echo enabled flag. */

/**
  * @}
  */


/** @defgroup Terminal_Functions Functions
  * @{
  */

/*!
 * @brief Sends the cursor backwards
 *
 *	@param	qty			Quantity of spaces.
 *	@return				Nothing.
 *
 */
__VOID __terminalBack(u8 qty)
{
	__STRING num[4];
	__STRING buf[sizeof(num) + 5];
	u8 len;

	__strFmt(num, "%u", qty);
	len = __strLen(num);
	
	buf[0] = __terminalESC[0];
	buf[1] = __terminalESC[1];
	__memCpy(buf+2, num, len);
	buf[2+len] = 'D';
	buf[3+len] = 0x00;
	
	__terminalWrite(buf);
} 

/*!
 * @brief Sends the cursor forward.
 *
 * @param	qty			Quantity of spaces.
 * @return				Nothing.
 *
 */
__VOID __terminalFoward(u8 qty)
{
	__STRING num[4];
	__STRING buf[sizeof(num) + 5];
	u8 len;

	__strFmt(num, "%u", qty);
	len = __strLen(num);

	buf[0] = __terminalESC[0];
	buf[1] = __terminalESC[1];
	__memCpy(buf+2, num, len);
	buf[2+len] = 'C';
	buf[3+len] = 0x00;
	
	__terminalWrite(buf);
}

/*!
 * @brief Shows prompt
 *
 * To modify the prompt see the __TERMINAL_PROMPT definition.
 * @return				Nothing.
 *
 */
__VOID __terminalShowPrompt(__VOID)
{
	if (__lockOwn(__terminalLock, 1000))
	{
		__deviceWrite(__terminalDevice, __TERMINAL_PROMPT, __strLen(__TERMINAL_PROMPT));
		__deviceFlush(__terminalDevice);
		__lockRelease(__terminalLock);
	}
}

/*!
 * @brief Parses escaped characters.
 *
 * Called after receiving an ESC character will read consecutively
 * until a known escape sequence is found.
 *
 * @return	Known key code value, otherwise __SK_UNKNOWN.
 *
 */
u16	__terminalParseEscaped(__VOID)
{
	u8	a = 0;
	u8	b = 0;
	u8 	c = 0;
	u8	d = 0;

	/* Check for 0x5b */
	if (__deviceRead(__terminalDevice, &a, 1) == 1)
	{
		/* Not 0x5b? Return and save last char received */
		if (a != 0x5b)
		{
			return a;
		}
	} else
	{
		return __SK_ESCAPE;
	}
							
	/* 0x5b received, check for special chars */
	if (__deviceRead(__terminalDevice, &b, 1) == 1)
	{
		switch (b) {
			/* Arrows */
			case 0x41:	
				return __SK_UPARROW;
			case 0x42:	
				return __SK_DOWNARROW;
			case 0x43:	
				return __SK_RIGHTARROW;
			case 0x44:	
				return __SK_LEFTARROW;
									
			/* Break */
			case 0x50:	
				return __SK_BREAK;		
				
												
			/* Four and five char codes */
			case 0x5b:
			case 0x31:
			case 0x32:
			case 0x33:
			case 0x35:
			case 0x36:
			case 0x37:	
				break;				
			default:
				return __SK_UNKNOWN;
		}
		
		if (__deviceRead(__terminalDevice, &c, 1) == 1)
		{
			/* Four characters codes ending with 0x7e*/
			if (c == 0x7e) {
				switch (b) {
					case 0x31:
						return __SK_HOME;
					case 0x32:
						return __SK_INS;
					case 0x33:
						return __SK_DEL;
					case 0x34:
						return __SK_END;
					case 0x35:
						return __SK_PGUP;
					case 0x36:
						return __SK_PGDN;						
					default:
						return __SK_UNKNOWN;
				}
			}
			
			if (b != 0x31 && b != 0x32) return __SK_UNKNOWN;
			
			/* Five characters codes */
			if (__deviceRead(__terminalDevice, &d, 1) == 1)
			{
				if (d != 0x7e) return __SK_UNKNOWN;
				
				switch (b) {
					case 0x31:
						switch (c) {
							case 0x31:
								return __SK_F1;
							case 0x32:
								return __SK_F2;
							case 0x33:
								return __SK_F3;
							case 0x34:
								return __SK_F4;
							case 0x35:
								return __SK_F5;
							case 0x37:
								return __SK_F6;
							case 0x38:
								return __SK_F7;
							case 0x39:
								return __SK_F8;
							default:
								return __SK_UNKNOWN;
						}
						
					case 0x32:
						switch (c) {
							case 0x30:
								return __SK_F9;
							case 0x31:
								return __SK_F10;
							case 0x33:
								return __SK_F11;
							case 0x34:
								return __SK_F12;
							default:
								return __SK_UNKNOWN;
						}
						
					default:
						return __SK_UNKNOWN;
				}
			}
		}
	}
	
	return __SK_UNKNOWN;
}

/*!
 * @brief Process key codes.
 *
 * @return	__TRUE if the key code has to be echoed, otherwise __FALSE.
 *
 */
__BOOL __terminalParseSpecial(u16 code) {

	if (code == __SK_UNKNOWN) return __FALSE;
	
	switch (code)
	{
		case __SK_LEFTARROW:		if (__terminalCursor)
									{
										__terminalBack(1);
										/* back cursor */
										__terminalCursor--;
									}
									break;
									
		case __SK_RIGHTARROW:		if (__strLen(__terminalRxLine) > __terminalCursor)
									{
										__terminalFoward('1');
										
										/* back cursor */
										__terminalCursor++;										
									}
									break;
									
		case __SK_UPARROW:
									break;
									
		case __SK_END:				/* hide cursor */
									__terminalWrite(__terminalHideCursor);
		
									/* move cursor */
									__terminalBack(__terminalCursor);
									
									__terminalCursor = 0;
									
									/* show cursor */
									__terminalWrite(__terminalShowCursor);
									break;
									
		case __SK_HOME:				if (__terminalCursor == __strLen(__terminalRxLine)) break;
									
									/* hide cursor */
									__terminalWrite(__terminalHideCursor);
		
									/* move cursor */
									__terminalFoward(__strLen(__terminalRxLine) - __terminalCursor);
									
									__terminalCursor = __strLen(__terminalRxLine);
									
									/* show cursor */
									__terminalWrite(__terminalShowCursor);
									break;								
	}
	
	return __FALSE;

}

/*!
 * @brief Reads a single line of text.
 *
 * Called after receiving an ESC character will read consecutively
 * until a known escape sequence is found.
 *
 * @return	Known key code value, otherwise __SK_UNKNOWN.
 *
 */
__BOOL	__terminalReadLine(__VOID)
{
	u16	size = 0;
	u8 	c = 0;
	u8 	ret = 0;
	u8 	echo;
	u8 	save;
	u8 	i = 0;
	u8	print = 0;

	for (;;)
	{
		size = __deviceSize(__terminalDevice, __DEV_RXSIZE);
		while (size > 0)
		{
			if (__deviceRead(__terminalDevice, &c, 1) == 1)
			{
				size--;

				echo 	= __FALSE;
				save 	= __TRUE;
				ret		= __FALSE;

				/* Parse received char */
				switch (c) {

					/* ESCAPE */
					case 0x1b:
						save = __FALSE;
						echo = __terminalParseSpecial(__terminalParseEscaped());
						
						/* Refresh size */
						size = __deviceSize(__terminalDevice, __DEV_RXSIZE);						
						break;

					/* TAB */
					case 0x09:
						save = __FALSE;
						echo = __FALSE;
						break;

					/* BACKSPACE */
					case 0x08:
						save = __FALSE;
						echo = __FALSE;

						if (!__terminalRxOffs) break;
						if (!__terminalCursor) break;

						/* Deleting a char between others */
						if (__terminalCursor < __terminalRxOffs)
						{
							for (i = __terminalCursor; i < __terminalRxOffs; i++)
							{
								__terminalRxLine[i-1] = __terminalRxLine[i];
							}
							
							print = __TRUE;
						}
						
						__terminalRxOffs--;
						__terminalCursor--;
						
						__terminalRxLine[__terminalRxOffs] = 0;
						
						if (print)
						{
							/* hide cursor */
							__terminalWrite(__terminalHideCursor);
						
							/* write a left and clear escape sequence */
							__terminalWrite(__terminalBackspace);
						
							/* rewrite the rest of the line */
							__terminalWrite(__terminalRxLine+__terminalCursor);							
							
							/* move cursor back */
							__terminalBack(__terminalRxOffs - __terminalCursor);
							
							/* show cursor */
							__terminalWrite(__terminalShowCursor);
						} else
						{
							/* write a left and clear escape sequence */
							__terminalWrite(__terminalBackspace);
						}
						break;

					/* CR */
					case 0x0D:
						save = __FALSE;
						echo = __FALSE;

						/* Send back a LF */
						__terminalWrite("\r\n");
						ret = __TRUE;
						break;

					/* LF (ignore) */
					case 0x0A:
						save = __FALSE;
						break;

					default:
						echo = __TRUE;
						break;
				}

				/* Buffer received char? */
				if (save) {
					/* Overflow? */
					if (__terminalRxOffs < __CONFIG_TERM_LINE_LEN-1)
					{
						print = __FALSE;
					
						/* inserting char? */
						if (__terminalCursor < __terminalRxOffs)
						{
							for (i = __CONFIG_TERM_LINE_LEN-1; i > __terminalCursor; i--)
							{
								__terminalRxLine[i] = __terminalRxLine[i-1];
							}
							
							print = __TRUE;
						} 
						
						__terminalRxLine[__terminalCursor] = c;
					
						/* advance buffer ptr */
						__terminalRxOffs++;
						
						/* advance cursor */
						__terminalCursor++;

						/* ensure last byte is __NULL */
						__terminalRxLine[__CONFIG_TERM_LINE_LEN-1] = 0;
						
						if (print)
						{
							/* hide cursor */
							__terminalWrite(__terminalHideCursor);
							
							__terminalWrite(__terminalRxLine+__terminalCursor-1);
							
							/* move cursor back */
							__terminalBack(__terminalRxOffs - __terminalCursor);
							
							/* show cursor */
							__terminalWrite(__terminalShowCursor);
							echo = __FALSE;
						}
					} else
					{
						echo = __FALSE;
					}
				}
				
				/* Has to send back ECHO? */
				if (echo && __terminalEcho)
				{
					__terminalWriteChar(c);
				}
				
				/* End of line, return */
				if (ret)
				{
					__terminalRxOffs = 0;
					__terminalCursor = 0;
					return __TRUE;
				}
			}
		}

		__threadSleep(1);
	}
}

/*!
 * @brief Terminal thread.
 *
 * This function will read from the device and call registered threads callback functions.
 * @return	Nothing.
 *
 */
__VOID __terminalThread(__VOID)
{
	u8			i = 0;
	__BOOL		bKnown = __FALSE;

	__deviceRegister(__CONFIG_TERMINAL_DEVICE, 128, 128, __DEV_WR_CRLF);
	__deviceOpen(__CONFIG_TERMINAL_DEVICE, 0);
	__deviceIOCtl(__CONFIG_TERMINAL_DEVICE, __IOCTL_SETBAUD, __CONFIG_TERMINAL_BAUDRATE, __NULL, 0);
	__deviceIOCtl(__CONFIG_TERMINAL_DEVICE, __IOCTL_SETTXTIMEOUT, 20, __NULL, 0);
	__deviceIOCtl(__CONFIG_TERMINAL_DEVICE, __IOCTL_SETRXTIMEOUT, 20, __NULL, 0);

	/* Rx and Tx line buffers */
	__terminalRxLine = __heapAllocZero(__CONFIG_TERM_LINE_LEN);
	__terminalTxLine = __heapAllocZero(__CONFIG_TERM_LINE_LEN);
	
	/* Subscribe the first as the system terminal */
	__terminalSubs[0].active	= __TRUE;
	__terminalSubs[0].func 		= __systemTerminalIn;
	__terminalSubs[0].thread 	= __NULL;

	/* Create Lock object */
	__terminalLock = __lockCreate();	

	__terminalStarted =	__TRUE;
	
	DBGMSG(__TRUE,("\r\n\r\n"));
	
	DBGMSG(__TRUE,("\r\nMilos v3 - Terminal Ready\r\n"));
	__terminalShowPrompt();
	
	for (;;)
	{
		__memSet(__terminalRxLine, 0, __CONFIG_TERM_LINE_LEN);
		if (__terminalReadLine())
		{
			if (__strLen(__terminalRxLine))
			{
				/* call system terminal */
				if (__terminalSubs[0].func)
				{
					bKnown = (__terminalSubs[0].func)(__terminalRxLine);
				}

				if (!bKnown)
				{
					/* 	system terminal does not recognize the command
						call subscribers */
					for (i = 1; i < __CONFIG_TERM_MAX_SUBSCRIBERS; i++)
					{
						if (__terminalSubs[i].active && (__terminalSubs[i].func != __NULL))
						{
							bKnown |= (__terminalSubs[i].func)(__terminalRxLine);
						}
					}
				}
				
				/* Unknown Command? */
				if (bKnown == __FALSE)
				{
					DBGMSG(__TRUE, ("Unknown Command\r\n"));
				}
			}
			
			__terminalShowPrompt();
		}
		
		__threadSleep(1);
	}
}

/*!
 * @brief Terminal initialization.
 *
 * Call this function passing a pointer to a device to active the terminal.
  * @param	enable_echo	Enables character echo.
 * @return	Nothing.
 *
 */
__VOID __terminalInit(u8 enable_echo)
{
	if (__terminalStarted) return;
	
	__terminalDevice = __CONFIG_TERMINAL_DEVICE;
	__terminalEcho = enable_echo;
 	__terminalThreadPtr = __threadCreate("terminal", __terminalThread, __CONFIG_PRIO_TERMTHREAD, 1024, 1, __NULL);
}

/*!
 * @brief Outputs a line of text.
 *
 * This function will automatically add CRLF characters, if the device is configured
 * to do so.
 *
 * @param	str			String of text.
 * @param	...			sprintf()-like format.
 *
 * @return	Nothing.
 *
 */
__VOID __terminalWriteLine(__CONST __PSTRING str, ...)
{
__PSTRING args = ((__PSTRING) &str) + sizeof(__PSTRING);
	
	if (!__terminalStarted) return;
	
	if (__strLen(str) >= __CONFIG_TERM_LINE_LEN) return;

	if (__lockOwn(__terminalLock, 1000))
	{
		__strFmtEx(__terminalTxLine, str, args);
		__deviceWriteLine(__terminalDevice, __terminalTxLine);
		__deviceFlush(__terminalDevice);
		__lockRelease(__terminalLock);
	}
}

/*!
 * @brief Outputs a line of text.
 *
 * This function will output exactly the string passed as argument. __terminalWriteLine()
 * function will add CRLF automatically.
 *
 * @param	str			String of text.
 * @param	...			sprintf()-like format.
 *
 * @return	Nothing.
 *
 */
__VOID __terminalWrite(__CONST __PSTRING str, ...)
{
__PSTRING args = ((__PSTRING) &str) + sizeof(__PSTRING);

	if (!__terminalStarted) return;
	
	if (__strLen(str) >= __CONFIG_TERM_LINE_LEN) return;
	
	if (__lockOwn(__terminalLock, 1000))
	{
		__strFmtEx(__terminalTxLine, str, args);
		__deviceWrite(__terminalDevice, __terminalTxLine, __strLen(__terminalTxLine));
		__deviceFlush(__terminalDevice);
		__lockRelease(__terminalLock);
	}
}

/*!
 * @brief Outputs a character.
 *
 * @param	c			Character to write.
 *
 * @return	Nothing.
 *
 */
__VOID __terminalWriteChar(u8 c)
{
	if (!__terminalStarted) return;
	
	if (__lockOwn(__terminalLock, 1000)) {
		__deviceWrite(__terminalDevice, &c, 1);
		__deviceFlush(__terminalDevice);
		__lockRelease(__terminalLock);
	}
}

/*!
 * @brief Adds the calling thread to the Terminal's subscribers list.
 *
 * Each thread can subscribe to the terminal parser: each time a line of text is read by the
 * terminal, it will cycle through the __TERMINALFUNC() functions listed, until the command is recognized
 * by one of the subscribers.
 *
 * @param	func		Pointer to a __TERMINALFUNC() function.
 *
 * @return	__TRUE on success, otherwise __FALSE.
 *
 */
__BOOL __terminalSubscribe(__TERMINALFUNC* func)
{
u8 i = 0;

	if (!func) return __FALSE;
	
	/* Check if this thread is already registered */
	for (i = 1; i < __CONFIG_TERM_MAX_SUBSCRIBERS; i++)
	{
		if (__terminalSubs[i].thread == __threadGetCurrent()) return __TRUE;
	}	
	
	/* Find a free pos in array */
	__systemStop();
	for (i = 0; i < __CONFIG_TERM_MAX_SUBSCRIBERS; i++)
	{
		if (!__terminalSubs[i].active)
		{
			__terminalSubs[i].active	= __TRUE;
			__terminalSubs[i].func 		= func;
			__terminalSubs[i].thread 	= __threadGetCurrent();
			__systemStart();
			return __TRUE;
		}
	}
	__systemStart();
	
	return __FALSE;
}

/*!
 * @brief Removes the calling thread from the Terminal's subscribers list.
 *
 * @return	Nothing.
 *
 */
__VOID __terminalUnSubscribe(__VOID)
{
u8 i;

	__systemStop();
	for (i = 0; i < __CONFIG_TERM_MAX_SUBSCRIBERS; i++)
	{
		if (__terminalSubs[i].thread == __threadGetCurrent())
		{
			__terminalSubs[i].active 	= __FALSE;
			__terminalSubs[i].func 		= __NULL;
			__terminalSubs[i].thread 	= __NULL;
			__systemStart();
			return;
		}
	}
	__systemStart();
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif // __CONFIG_TERMINAL_ENABLED

