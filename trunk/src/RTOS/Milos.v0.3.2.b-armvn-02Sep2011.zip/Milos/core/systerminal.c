/***************************************************************************
 * systerminal.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "terminal.h"
#include "systerminal.h"
#include "heap.h"
#include "lock.h"
#include <common/common.h>
#if __CONFIG_COMPILE_FAT
#include <fs/fat.h>
#endif

#if __CONFIG_TERMINAL_ENABLED

extern __BOOL __systemReset;

__STATIC u32 __heapCountFree = 0;		/*!< @brief Used to count free heap memory */
__STATIC u32 __heapCountBusy = 0;		/*!< @brief Used to count busy heap memory */

/** @addtogroup Core
  * @{
  */

/** @defgroup SysTerminal System Terminal
  * System terminal parser.
  * @{
  */

/** @defgroup SysTerminal_PrivateVariables Private variables
  * @{
  */

__STRING __stBuf[128];							/*!< @brief Output buffer */
u32	__stAux;									/*!< @brief Auxiliary */
char*		__thstatus[] = 	{
							"READY",
							"RUNNING",
							"SLEEPING",
							"WAITING",
							"DISABLED",
							"FIRSTTIME",
							"DELETE",
							"WFL"
							};		/*!< @brief Strings for thread status */


/**
  * @}
  */

/** @defgroup SysTerminal_Functions Functions
  * @{
  */

/*!
 * @brief Callback for heap walk.
 *
 * Internal use. This function will be called for every memory block found in the heap.
 */
__STATIC __BOOL __stHeapCallBack(__PVOID ptr, u32 size, __BOOL fr, __PTHREAD th, __PVOID arg)
{
	__STRING buf[20];

	__strFmt(__stBuf,"%08lXh ",ptr);
	__strFmt(buf,"%6lu ",size);
	__strCat(__stBuf,buf);
	if (fr == __TRUE)
	{
		__heapCountFree += size;
		__strCat(__stBuf,"free  ");
	} else
	{
		__heapCountBusy += size;
		__strCat(__stBuf,"busy  ");

		if (th != __NULL)
		{
			__strCat(__stBuf, (__PSTRING) th->th_name);
		} else
		{
			__strCat(__stBuf,"not available");
		}
	}
	
	DBGMSG(__TRUE, (__stBuf));
	return(__TRUE);
}

/*!
 * @brief Callback for thread walk.
 *
 * Internal use. This function will be called for thread found.
 */
__BOOL __stThreadCallBack(__PVOID ptr, u32 size, __BOOL fr, __PTHREAD th, __PVOID arg)
{
	if ((__PTHREAD) arg == th && fr == __FALSE) __stAux += size;
	return(__TRUE);
}

/*!
 * @brief Entry point for "threads" terminal command.
 */
__STATIC __VOID	__stThreads(__VOID)
{

	__PTHREAD	th = __threadGetChain();
	__STRING	buf[20];

	DBGMSG(__TRUE, ("\r\nCurrent threads:\r\n"));
	DBGMSG(__TRUE, ("Name     Address   TTL    Stack Memory Prio State"));
	DBGMSG(__TRUE, ("----------------------------------------------------"));
	while (th)
	{
		__stAux = 0;

		__heapWalk(__stThreadCallBack,th);

		__strFmt(__stBuf,"%8s %08lXh %06lu %05lu ",
			th->th_name,
			th,
			(u32) th->th_load,
			(u32) th->th_stksize);

		/* memory */
		__strFmt(buf,"%06lu ",(u32) __stAux);
		__strCat(__stBuf,buf);

		/* priority */
		__strFmt(buf,"%03lu ",(u32) th->th_priority);
		__strCat(__stBuf,buf);

		/* state */
		__strCat(__stBuf,__thstatus[th->th_status]);

		DBGMSG(__TRUE, (__stBuf));
		th = (__PTHREAD) th->th_lstnext;
	}
}

/*!
 * @brief System terminal commands parser.
 *
 * This function will be called to check and process system commands from the terminal.
 * @param	str		Command string.
 * @return __TRUE if the command matches, otherwise __FALSE.
 */

__BOOL __stTerminalIn(__PSTRING str)
{
	/* HEAP */
	if (__strCmpNoCase(str, "HEAP") == 0)
	{
		__heapCountFree = 0;
		__heapCountBusy = 0;

		DBGMSG(__TRUE,("\r\nThe current RAM heap:\r\n"));
		DBGMSG(__TRUE,("Address     Size State Owner"));
		DBGMSG(__TRUE,("------------------------------------"));
					
		__heapWalk(__stHeapCallBack, __NULL);
		DBGMSG(__TRUE, (""));

		__strFmt(__stBuf,"Busy: %lu bytes", __heapCountBusy);
		DBGMSG(__TRUE, (__stBuf));

		__strFmt(__stBuf,"Free: %lu bytes", __heapCountFree);
		DBGMSG(__TRUE, (__stBuf));

		DBGMSG(__TRUE, (""));
		return __TRUE;
	}
	
	/* THREADS */
	if (__strCmpNoCase(str, "THREADS") == 0)
	{
		__stThreads();
		DBGMSG(__TRUE, (""));
		return __TRUE;
	}
	
	/* RESET */
	if (__strCmpNoCase(str, "RESET") == 0)
	{
		__systemReset = __TRUE;
		return __TRUE;
	}
	
	/* LOCKS */
	if (__strCmpNoCase(str, "LOCKS") == 0)
	{
		__lockTerminalOut();
		return __TRUE;
	}
	
#if __CONFIG_COMPILE_FAT
	/* DIR */
	if (__strCmpNoCase(str, "DIR") == 0)
	{
		__fatDirCmd();
		return __TRUE;
	}

#endif

	return __FALSE;
}


/**
  * @}
  */


/**
  * @}
  */


/**
  * @}
  */

#endif // __CONFIG_TERMINAL_ENABLED


