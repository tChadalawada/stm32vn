/***************************************************************************
 * device.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "device.h"
#include <common/string.h>

/** @addtogroup Core
  * @{
  */

/** @defgroup Device Devices
  * @brief Device drivers functions.
  *
  * This module defines the main functions for device drivers.
  * To implement a device driver fill a __DEVICE structure with the required
  * parameters, to be used with the functions described below.
  * Users may find appropriate to implement the device driver in two or more steps:
  * One step is to implement the common code that can be used in different platforms right in the
  * \\drives directory. Other steps may include the division of the common driver code from the
  * platform-specific code, and to declare the __DEVICE structure in the \\board directory inside the platform.
  * This way, for example, an application developer should find himself using __SERIAL_1 no matter the platform
  * or board is he using; because the serial code for that platform is surrounded with __deviceXXXXXX functions
  * that hides driver implementation, and by defining __SERIAL_1 on the \\board directory should guarantee that
  * switching boards for a specific development may still find the __SERIAL_1 device wherever is located on the
  * board.
  *
  * @{
  */

/** @defgroup Device_Constants Constants
  * @{
  */

/** @defgroup Device_PrivateDefines Private constants
  * Internal defines.
  * @{
  */

#define	__DEV_INITIALIZED	0x80	/*!< @brief Device init flag. */
#define	__DEV_OPENED		0x40	/*!< @brief Device open flag. */
#define	__DEV_EOL			0x00	/*!< @brief Line null terminator char. */
#define	__DEV_CR			0x0D	/*!< @brief CR char. */
#define	__DEV_LF			0x0A	/*!< @brief LF char. */
#define	__DEV_RD_CRLFMASK	0x03	/*!< @brief Mask to obtain CR/LF read bits */
#define	__DEV_WR_CRLFMASK	0x0C	/*!< @brief Mask to obtain CR/LF read bits */

/**
  * @}
  */

/**
  * @}
  */

/** @defgroup Device_PrivateVariables Private variables
  * @{
  */

__STATIC __PDEVICE __deviceChain = __NULL;	/*!< @brief Device list chain. */

/**
  * @}
  */


/** @defgroup Device_Functions Functions
  * @{
  */

/*!
 * @brief Find device by name.
 *
 * This function returns the address of the device specified in the name parameter.
 *
 * @param	name		Pointer to device name string.
 * @return				Device address or __NULL if device is not registered.
 *
 */
#if __CONFIG_COMPILE_STRING
__PDEVICE __deviceFindName(__CONST __PSTRING name)
{
	__PDEVICE	dv = __deviceChain;

	while(dv)
	{
		if (__strCmpNoCase(dv->dv_name,name) == 0) return(dv);
		dv = dv->dv_next;
	}
	return(__NULL);
}
#endif /* __CONFIG_COMPILE_STRING */

/*!
 * @brief Find device by pointer.
 *
 * This function returns the address of the device specified in the name parameter,
 * if found.
 *
 * @param	dv			Pointer to device.
 * @return				Device address or __NULL if device is not registered.
 *
 */
__PDEVICE __deviceFind(__CONST __PDEVICE dv)
{
	__PDEVICE	dvc = __deviceChain;

	while(dvc)
	{
		if (dvc == dv) return dvc;
		dvc = dvc->dv_next;
	}
	return __NULL;
}


/*!
 * @brief Registers a device.
 *
 * Call this function to register a device. It will generate a call to the
 * __DEV_INIT() function provided in the __DEVICE structure pointer.
 * @param	dv			Pointer to valid __DEVICE device to register
 * @param	param1		Optional parameter 1
 * @param	param2		Optional parameter 2
 * @param	mode		Optional mode (used by device)
 * @arg __DEV_RD_CR: When a CR is received, the __deviceReadLine() function
 * will add a NULL character and return the read line.
 * @arg __DEV_RD_LF: When a LF is received, the __deviceReadLine() function
 * will add a NULL character and return the read line.
 * @arg __DEV_RD_CRLF: The combination of __DEV_RD_CR and __DEV_RD_LF flags.
 * @arg __DEV_WR_CR: The __deviceWriteLine() function will transmit a CR
 * character after a successfully call to the __DEV_WRITE() function.
 * @arg __DEV_WR_LF: The __deviceWriteLine() function will transmit a LF
 * character after a successfully call to the __DEV_WRITE() function.
 * @arg __DEV_WR_CRLF: The combination of __DEV_WR_CR and __DEV_WR_LF flags.
 * @arg __DEV_AUTOFLUSH: The __deviceWrite() function will flush the TX
 * buffer immediately after a successfully call to the __DEV_WRITE() function.
 * @return	__DEV_OK on success, non-zero on failure. Error code may depend on underlying
 * 			device implementation.
 *
 */
i32	__deviceRegister(__PDEVICE dv, i16 param1, i16 param2, u16 mode)
{

	if (!dv) return(__DEV_ERROR);

	/* Check if already registered */
	if (__deviceFind(dv) == __NULL)
	{
		/* Check if device has an init function */
		if (dv->dv_init != __NULL)
		{
			if ((*dv->dv_init)(dv,param1,param2,mode) == __DEV_OK)
			{
				dv->dv_next = __deviceChain;
				__deviceChain = dv;
				dv->dv_mode |= (mode & 0xFF3F);
				/* Increment register count */
				++dv->dv_rgcnt;
				return __DEV_OK;
			}
		}
		return __DEV_ERROR;
	}

	/* Increment register count */
	++dv->dv_rgcnt;
	return __DEV_OK;
}

/*!
 * @brief Unregisters a device.
 *
 * Call this function to unregister a device. It will generate a call to the
 * __DEV_DESTROY() function provided in the __DEVICE structure pointer.
 * @param dv	Pointer to a valid device to unregister.
 * @return		__DEV_OK on success, non-zero on failure. Error code may depend on underlying
 * 				device implementation.
 */
i32	__deviceUnregister(__PDEVICE dv)
{
	__PDEVICE	p;

	/* Check if registered */
	if (__deviceFind(dv) == __NULL || dv->dv_rgcnt == 0) return __DEV_ERROR;

	/* Last registered/ */
	if (dv->dv_rgcnt == 1)
	{
		/* Check if device has a destroy function */
		if (dv->dv_dstry != __NULL)
		{
			if ((*dv->dv_dstry)(dv) == __DEV_OK)
			{
				/* Check if it is the first device */
				if (dv == __deviceChain)
				{
					__deviceChain = dv->dv_next;
				} else
				{
					p = __deviceChain;
					while (p->dv_next != dv) p = p->dv_next;
					p->dv_next = dv->dv_next;
				}
				dv->dv_rgcnt = 0;
				return __DEV_OK;
			}
		}
		return(-1);
	}

	/* Decrement counter */
	--dv->dv_rgcnt;
	return __DEV_OK;
}

/*!
 * @brief Opens a device.
 *
 * Opens a device. Must be called from a thread. It will generate a call to the
 * __DEV_OPEN() function provided in the __DEVICE structure pointer.
 * @param dv	Pointer to valid device to open.
 * @param mode	Optional value. It will be passed to the __DEV_OPEN() function.
 * @return		__DEV_OK on success, non-zero on failure. Error code may depend on underlying
 * 				device implementation.
 */
i32	__deviceOpen(__PDEVICE dv, u8 mode)
{

	/* Must be called from inside a thread */
	if (__threadGetCurrent()) {
		if (__deviceFind(dv) != __NULL)
		{
			/* Check if already opened */
			if (dv->dv_opcnt == 0)
			{
				/* Check for an open function */
				if (dv->dv_open != __NULL)
				{
					if ((*dv->dv_open)(dv,mode) == __DEV_OK)
					{
						dv->dv_owner = __threadGetCurrent();
						++dv->dv_opcnt;
						return __DEV_OK;
					}
				}
			} else {
				++dv->dv_opcnt;
				return __DEV_OK;
			}
		}
	}

	return __DEV_ERROR;
}

/*!
 * @brief Closes a device.
 *
 * Closes an opened device. It will generate a call to the __DEV_CLOSE()
 * function provided in the __DEVICE structure pointer.
 * @param	dv		Pointer to valid device to close.
 * @return			__DEV_OK on success, non-zero on failure. Error code may depend on underlying
 * 					device implementation.
 */
i32	__deviceClose(__PDEVICE dv) {

	/* Must be called from inside a thread */
	if (__threadGetCurrent())
	{
		if (__deviceFind(dv) != __NULL && dv->dv_opcnt > 0)
		{
			if (dv->dv_opcnt == 1)
			{
				/* Check for a close function */
				if (dv->dv_close != __NULL)
				{
					if ((*dv->dv_close)(dv) == __DEV_OK)
					{
						dv->dv_owner = __NULL;
						dv->dv_opcnt = 0;
						return __DEV_OK;
					}
				}
			} else
			{
				--dv->dv_opcnt;
				return __DEV_OK;
			}
		}
	}

	return __DEV_ERROR;
}

/*!
 * @brief Device IO Control function
 *
 * Generates a call to the __DEV_IOCTL() function provided in the __DEVICE
 * structure pointer.
 * @param	dv		Pointer to valid device.
 * @param	cmd		Command code.
 * @param	param	Optional parameter value.
 * @param	data	Optional parameter pointer.
 * @param	len		Length of \c data.
 * @return			__DEV_OK on success, non-zero on failure. Error code may depend on underlying
 * 					device implementation. __deviceIOCtl() may return values instead of error
 * 					codes. See the specific driver documentation.
 */
i32 __deviceIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len)
{
	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	if (dv->dv_ioctl)
	{
		return((*dv->dv_ioctl)(dv,cmd,param,data,len));
	}

	return __DEV_ERROR;
}

/*!
 * @brief Reads from device.
 *
 * Generates a call to the __DEV_READ() function provided in the __DEVICE
 * structure pointer.
 * @param 	dv 		Pointer to valid device to read from.
 * @param 	buf		Buffer to receive device data.
 * @param 	qty		Amount of bytes to read.
 * @return			Quantity of bytes read. A negative value on error. The
 * 					error code depends on the underlying driver implementation.
 * 					See the driver documentation.
 */
i32	__deviceRead(__PDEVICE dv, __PVOID buf, u16 qty)
{
	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	if (dv->dv_owner != __NULL)
	{
		/* Check for a read function */
		if (dv->dv_read != __NULL)
		{
			return((*dv->dv_read)(dv,buf,qty));
		}
	}

	return __DEV_ERROR;
}

/*!
 * @brief Writes to a device.
 *
 * Generates a call to the __DEV_WRITE() function provided in the __DEVICE
 * structure pointer.
 * @param 	dv		Pointer to a valid device to write to.
 * @param 	buf		Pointer to data to write.
 * @param 	qty		Amount of bytes to write.
 * @return			Quantity of bytes written, otherwise an error code. The
 * 					error code depends on the underlying driver implementation.
 * 					See the driver documentation.
 */
i32	__deviceWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty) {

	u32	res;

	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	if (dv->dv_owner != __NULL)
	{
		if (dv->dv_write != __NULL)
		{
			res = ((*dv->dv_write)(dv,buf,qty));
			if (res > __DEV_OK) {
				if (dv->dv_mode & __DEV_AUTOFLUSH) __deviceFlush(dv);
			}
			return res;
		}
	}
	return __DEV_ERROR;
}

/*!
 * @brief Flushes device's TX buffer.
 *
 * Generates a call to the __DEV_FLUSH() function provided in the __DEVICE
 * structure pointer.
 * @param 	dv		Pointer to a valid device.
 * @return			0 on success, otherwise an error code.
 */
i32	__deviceFlush(__PDEVICE dv)
{

	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	if (dv->dv_owner != __NULL)
	{
		if (dv->dv_flush != __NULL)
		{
			return((*dv->dv_flush)(dv));
		}
	}

	return __DEV_ERROR;
}

/*!
 * @brief Get the remaining TX or RX bytes in the device's buffer.
 *
 * Generates a call to the __DEV_SIZE() function provided in the __DEVICE
 * structure pointer.
 * @param	dv		Pointer to a valid device.
 * @param	mode	TX or RX buffer flag.
 * @arg __DEV_RXSIZE: Retrieves the remaining unread bytes from the device's RX buffer.
 * @arg __DEV_TXSIZE: Retrieves the remaining unsent bytes from the device's TX buffer.
 * @return			Bytes remaining or an error code.
 */
i32	__deviceSize(__PDEVICE dv, u8 mode)
{
	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	if (dv->dv_owner != __NULL) {
		if (dv->dv_size != __NULL) {
			return((*dv->dv_size)(dv,mode));
		}
	}

	return __DEV_ERROR;
}

/*!
 * @brief Reads a line of text from the device.
 *
 * Calling the device's __DEV_READ() function it will scan for CR and/or LF characters
 * (depending on how the device was registered, see __deviceRegister() function) and
 * will fill the provided buffer with a line of text.
 * @param 	dv		Pointer to a valid device.
 * @param	buf		Buffer to receive the ASCII line.
 * @param	qty		Bytes to read.
 * @return 			Bytes read or an error code.
 */
i32 __deviceReadLine(__PDEVICE dv, __PSTRING buf, u16 qty)
{
	u16		i;
	u8		c, cr = 0;

	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	if (dv == __NULL || dv->dv_read == __NULL || dv->dv_owner == __NULL) return __DEV_ERROR;

	for (i = 0; i < (qty - 1); i++)
	{
		if ((*dv->dv_read)(dv,&c,1) != 1)
		{
			*buf = __DEV_EOL;
			return __DEV_ERROR;
		}

		if (c == __DEV_CR || c == __DEV_LF)
		{
			--i;
			if (dv->dv_mode & __DEV_RD_CR)
			{
				if (!(dv->dv_mode &	__DEV_RD_LF))
				{
					*buf = __DEV_EOL;
					return i;
				}
				cr = c;
			}

			if (dv->dv_mode & __DEV_RD_LF)
			{
				if (!(dv->dv_mode &	__DEV_RD_CR))
				{
					*buf = __DEV_EOL;
					return i;
				}

				if (cr == __DEV_CR)
				{
					*buf = __DEV_EOL;
					return i;
				}
				cr = 0;
			}
		} else
		{
			*buf++ = c;
			cr = 0;
		}
	}

	return i;
}

/*!
 * @brief Writes a line of text to the device.
 *
 * After calling the device's __DEV_WRITE() function, it will send a CR and/or LF
 * characters (depending on how the device was registered, check __deviceRegister()
 * function).
 * @param 	dv		Pointer to a valid device.
 * @param	buf		The ASCII line of text to send.
 * @return 			Bytes sent or an error code.
 */
i32 __deviceWriteLine(__PDEVICE dv, __CONST __PSTRING buf)
{
	i16			qty = 0;
	u8			c;

	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	if (dv == __NULL || dv->dv_write == __NULL || dv->dv_owner == __NULL) return __DEV_ERROR;

	if (buf == __NULL) return __DEV_ERROR;

	if ((*dv->dv_write)(dv, buf, __strLen(buf)) != __strLen(buf)) {
		return __DEV_ERROR;
	}
	
	qty = __strLen(buf);
	
	if (dv->dv_mode & __DEV_WR_CR) {
		c = __DEV_CR;
		if ((*dv->dv_write)(dv,&c,1) != 1)
		{
			return __DEV_ERROR;
		}
		++qty;
	}

	if (dv->dv_mode & __DEV_WR_LF)
	{
		c = __DEV_LF;
		if ((*dv->dv_write)(dv,&c,1) != 1)
		{
			return __DEV_ERROR;
		}
		++qty;
	}

	if (dv->dv_mode & __DEV_AUTOFLUSH)
	{
		if (dv->dv_flush) (*dv->dv_flush)(dv);
	}

	return qty;
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

