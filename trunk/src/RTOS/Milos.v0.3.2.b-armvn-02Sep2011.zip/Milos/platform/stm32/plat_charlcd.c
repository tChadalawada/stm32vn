/***************************************************************************
 * plat_charlcd.c
 * (C) 2011 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "plat_charlcd.h"
#include <drivers/charlcd/charlcd.h>

#if __CONFIG_COMPILE_CHARLCD

__STATIC __VOID __charlcdPlatInitHw(__PDEVICE dv)
{
	__PCHARLCDPDB pd = dv->dv_pdb;
	__PCHARLCD_PARAMS params = dv->dv_params;
	GPIO_InitTypeDef GPIO_InitStructure;

	if (params->apb_bus_num == 2)
	{
		RCC_APB2PeriphClockCmd(params->port_clock_addr, ENABLE);
	} else
	{
		RCC_APB1PeriphClockCmd(params->port_clock_addr, ENABLE);
	}

	GPIO_InitStructure.GPIO_Pin = (1 << params->d4 | 1 << params->d5 | 1 << params->d6 | 1 << params->d7 |
								   1 << params->rw | 1 << params->e | 1 << params->rs);

	if (pd->pd_mode & __CHARLCD_MODE_8_BITS)
	{
		GPIO_InitStructure.GPIO_Pin |= (1 << params->d0 | 1 << params->d1 | 1 << params->d2 | 1 << params->d3);
	}

	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(params->port_addr, &GPIO_InitStructure);

}

__STATIC __VOID __charlcdPlatDeInitHw(__PDEVICE dv)
{
	__PCHARLCDPDB pd = dv->dv_pdb;
	__PCHARLCD_PARAMS params = dv->dv_params;
	GPIO_InitTypeDef GPIO_InitStructure;

	GPIO_InitStructure.GPIO_Pin = (1 << params->d4 | 1 << params->d5 | 1 << params->d6 | 1 << params->d7 |
									1 << params->rw | 1 << params->e | 1 << params->rs);

	if (pd->pd_mode & __CHARLCD_MODE_8_BITS)
	{
		GPIO_InitStructure.GPIO_Pin |= (1 << params->d0 | 1 << params->d1 | 1 << params->d2 | 1 << params->d3);
	}

	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(params->port_addr, &GPIO_InitStructure);

}

__STATIC __VOID __charlcdWrite4(__PDEVICE dv, u8 data, u8 reg)
{
	__PCHARLCD_PARAMS params = dv->dv_params;

	/* write mode */
	__pinSet(params->port_addr, (1 << params->rw), 0);

	/* if reg == 1, write register */
	__pinSet(params->port_addr, (1 << params->rs), !reg);

	/* toggle E */
	__pinSet(params->port_addr, (1 << params->e), 1);

	/* Write */
	__pinSet(params->port_addr, (1 << params->d4), data & 1);
	__pinSet(params->port_addr, (1 << params->d5), (data  >> 1) & 1);
	__pinSet(params->port_addr, (1 << params->d6), (data  >> 2) & 1);
	__pinSet(params->port_addr, (1 << params->d7), (data  >> 3) & 1);

	__cpuDelayMs(1);

	/* toggle E */
	__pinSet(params->port_addr, (1 << params->e), 0);

	__cpuDelayMs(1);
}

__STATIC __VOID __charlcdWrite8(__PDEVICE dv, u8 data, u8 reg)
{
	__PCHARLCD_PARAMS params = dv->dv_params;
	__PCHARLCDPDB pd = dv->dv_pdb;

	/* write mode */
	__pinSet(params->port_addr, (1 << params->rw), 0);

	/* if reg == 1, write register */
	__pinSet(params->port_addr, (1 << params->rs), !reg);

	/* if 8-bit mode, write directly, otherwise use __charlcdWrite4 twice */
	if (pd->pd_mode & __CHARLCD_MODE_8_BITS)
	{
		/* toggle E */
		__pinSet(params->port_addr, (1 << params->e), 1);

		__pinSet(params->port_addr, (1 << params->d0), data & 1);
		__pinSet(params->port_addr, (1 << params->d1), (data  >> 1) & 1);
		__pinSet(params->port_addr, (1 << params->d2), (data  >> 2) & 1);
		__pinSet(params->port_addr, (1 << params->d3), (data  >> 3) & 1);

		__pinSet(params->port_addr, (1 << params->d4), (data  >> 4) & 1);
		__pinSet(params->port_addr, (1 << params->d5), (data  >> 5) & 1);
		__pinSet(params->port_addr, (1 << params->d6), (data  >> 6) & 1);
		__pinSet(params->port_addr, (1 << params->d7), (data  >> 7) & 1);

		__cpuDelayMs(1);

		/* toggle E */
		__pinSet(params->port_addr, (1 << params->e), 0);
	} else {
		__charlcdWrite4(dv, data >> 4, reg);
		__charlcdWrite4(dv, data & 0x0F, reg);
	}

	__cpuDelayMs(1);
}

__STATIC u8 __charlcdPlatReadStatus(__PDEVICE dv)
{
	__PCHARLCDPDB pd = dv->dv_pdb;
	__PCHARLCD_PARAMS params = dv->dv_params;
	GPIO_InitTypeDef GPIO_InitStructure;
	u8 ret = 0;

	GPIO_InitStructure.GPIO_Pin = (1 << params->d4 | 1 << params->d5 | 1 << params->d6 | 1 << params->d7);

	if (pd->pd_mode & __CHARLCD_MODE_8_BITS)
	{
		GPIO_InitStructure.GPIO_Pin |= (1 << params->d0 | 1 << params->d1 | 1 << params->d2 | 1 << params->d3);
	}

	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(params->port_addr, &GPIO_InitStructure);

	__cpuDelayMs(1);

	__pinSet(params->port_addr, (1 << params->rs), 0);

	/* read mode */
	__pinSet(params->port_addr, (1 << params->rw), 1);

	__cpuDelayMs(1);

	__pinSet(params->port_addr, (1 << params->e), 1);

	__cpuDelayMs(1);

	ret = __pinGet(params->port_addr, (1 << params->d7)) << 7;
	ret |= __pinGet(params->port_addr, (1 << params->d6)) << 6;
	ret |= __pinGet(params->port_addr, (1 << params->d5)) << 5;
	ret |= __pinGet(params->port_addr, (1 << params->d4)) << 4;


	if (pd->pd_mode & __CHARLCD_MODE_8_BITS)
	{

		ret |= __pinGet(params->port_addr, (1 << params->d3)) << 3;
		ret |= __pinGet(params->port_addr, (1 << params->d2)) << 2;
		ret |= __pinGet(params->port_addr, (1 << params->d1)) << 1;
		ret |= __pinGet(params->port_addr, (1 << params->d0));

	} else {

		__pinSet(params->port_addr, (1 << params->e), 0);

		__cpuDelayMs(1);

		__pinSet(params->port_addr, (1 << params->e), 0);

		__cpuDelayMs(1);

		ret |= __pinGet(params->port_addr, (1 << params->d7)) << 3;
		ret |= __pinGet(params->port_addr, (1 << params->d6)) << 2;
		ret |= __pinGet(params->port_addr, (1 << params->d5)) << 1;
		ret |= __pinGet(params->port_addr, (1 << params->d4));

	}

	__pinSet(params->port_addr, (1 << params->e), 0);

	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(params->port_addr, &GPIO_InitStructure);

	return ret;
}

i32 __charlcdPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len)
{

	switch (code)
	{
		case __CHARLCD_PLAT_INIT_HW:
			__charlcdPlatInitHw(dv);
			return __DEV_OK;

		case __CHARLCD_PLAT_DEINIT_HW:
			__charlcdPlatDeInitHw(dv);
			return __DEV_OK;

		case __CHARLCD_PLAT_WRITE_4:
			__charlcdWrite4(dv, *((u8*) in), (u8) param);
			break;

		case __CHARLCD_PLAT_WRITE_8:
			__charlcdWrite8(dv, *((u8*) in), (u8) param);
			break;

		case __CHARLCD_PLAT_SET_POWER:
			return __DEV_OK;

		case __CHARLCD_PLAT_GET_STATUS:
			return __charlcdPlatReadStatus(dv);
	}

	return __DEV_UNK_IOCTL;
}

#endif /* __CONFIG_COMPILE_CHARLCD */
