/***************************************************************************
 * plat_charlcd.c
 * (C) 2011 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/
#ifndef __PLAT_CHARLCD_H__
#define __PLAT_CHARLCD_H__

#include <plat_cpu.h>
#include <core/device.h>

#if __CONFIG_COMPILE_CHARLCD
#include <stm32f10x_spi.h>

typedef struct __charlcdParamsTag
{
	GPIO_TypeDef*	port_addr;
	u32				port_clock_addr;
	u8				apb_bus_num;
	u8				d0,d1,d2,d3,d4,d5,d6,d7,rs,rw,e;
} __CHARLCD_PARAMS, *__PCHARLCD_PARAMS;

extern __DEVICE charlcdDevice;

i32 __charlcdPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len);

#endif /* __CONFIG_COMPILE_CHARLCD */

#endif /* __PLAT_CHARLCD_H__ */

