/***************************************************************************
 * mcbstm32.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef __MCBSTM32_H__
#define __MCBSTM32_H__

#include <plat_ostypes.h>
#include <plat_config.h>

#ifdef BOARD_MCBSTM32

/*
 * Define UART location for the MSBSTM32 board
 */
#if __CONFIG_COMPILE_SERIAL

/* UART count for MSBSTM32 */
#define BOARD_UART_COUNT				1

/* UART1 parameters */
#define	BOARD_UART1_IRQ					37
#define BOARD_UART1_TX_PIN				GPIO_Pin_9
#define BOARD_UART1_RX_PIN				GPIO_Pin_10
#define BOARD_UART1_PORT				GPIOA
#define BOARD_UART1_BASE_REG			USART1
#define BOARD_UART1_APB_BUS				2
#define BOARD_UART1_BUS_ADDR			RCC_APB2Periph_USART1
#define BOARD_UART1_PORT_BUS_ADDR		RCC_APB2Periph_GPIOA

#define	__SERIAL_1		&serialDevices[0]

#endif // __CONFIG_COMPILE_SERIAL

/*
 * Define SPI location for the MSBSTM32 board
 */
#if __CONFIG_COMPILE_SPI

/* SPI count for MSBSTM32 */
#define BOARD_SPI_COUNT					1

/* SPI1 parameters */
#define BOARD_SPI1_IRQ					35

#define BOARD_SPI1_GPIO_PORT			GPIOA
#define BOARD_SPI1_BUS_ADDR				RCC_APB2Periph_SPI1
#define BOARD_SPI1_GPIO_BUS_ADDR		RCC_APB2Periph_GPIOA
#define BOARD_SPI1_APB_NUM				2
#define BOARD_SPI1_BASE_ADDR			SPI1
#define BOARD_SPI1_PIN_MISO				GPIO_Pin_6
#define BOARD_SPI1_PIN_MOSI				GPIO_Pin_7
#define BOARD_SPI1_PIN_CLK				GPIO_Pin_5
#define BOARD_SPI1_PIN_CS				GPIO_Pin_4
#define BOARD_SPI1_DIRECTION			SPI_Direction_2Lines_FullDuplex
#define BOARD_SPI1_PRESCALER			SPI_BaudRatePrescaler_256
#define BOARD_SPI1_CPOL					SPI_CPOL_Low
#define BOARD_SPI1_CPHA					SPI_CPHA_1Edge
#define BOARD_SPI1_NSS_MODE				SPI_NSS_Soft

#define	__SPI_1		&spiDevices[0]

#endif // __CONFIG_COMPILE_SPI

/*
 * Define SD location and parameters for the MSBSTM32 board
 */
#if __CONFIG_COMPILE_SD

#define BOARD_SD_COUNT				1

/* SD on MCBSTM32 has not a write protect pin */
/*
#define BOARD_SD1_WP_PIN
#define BOARD_SD1_WP_PORT
#define BOARD_SD1_WP_PIN_BUS_NUM
#define BOARD_SD1_WP_PIN_BUS_ADDR
*/
/* Card detect pin configuration */
#define BOARD_SD1_CD_PIN				GPIO_Pin_8
#define BOARD_SD1_CD_PORT				GPIOA
#define BOARD_SD1_CD_PIN_BUS_NUM		2
#define BOARD_SD1_CD_PIN_BUS_ADDR		RCC_APB2Periph_GPIOA
#define BOARD_SD1_DEVICE				__SPI_1
#define BOARD_SD1_DEVICE_MODE			__SPIMODE_MASTER

#define	__SD_1		&sdDevices[0]

#endif // __CONFIG_COMPILE_SD

/*
 * Character LCD for the MCBSTM32 board
 */
#if __CONFIG_COMPILE_CHARLCD

#define BOARD_CHARLCD_PORT				GPIOC
#define BOARD_CHARLCD_PORT_CLK_ADDR		RCC_APB2Periph_GPIOC
#define BOARD_CHARLCD_PORT_APB_BUS		2
#define BOARD_CHARLCD_PIN_D0			0
#define BOARD_CHARLCD_PIN_D1			0
#define BOARD_CHARLCD_PIN_D2			0
#define BOARD_CHARLCD_PIN_D3			0
#define BOARD_CHARLCD_PIN_D4			3
#define BOARD_CHARLCD_PIN_D5			2
#define BOARD_CHARLCD_PIN_D6			1
#define BOARD_CHARLCD_PIN_D7			0
#define BOARD_CHARLCD_PIN_RS			12
#define BOARD_CHARLCD_PIN_RW			11
#define BOARD_CHARLCD_PIN_E				10

#define __CHARLCD	&charlcdDevice

#endif /* __CONFIG_COMPILE_CHARLCD */

__VOID __boardInitHW(__VOID);
__VOID __boardDeInitCharLcd(__VOID);

#endif // BOARD_MCBSTM32

#endif // __MCBSTM32_H__
