/***************************************************************************
 * akstm32gps.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "akstm32gps.h"

#ifdef BOARD_AKSTM32GPS

#if __CONFIG_COMPILE_SERIAL
#include <drivers/serial/serial.h>

__SERIALPDB serialPdb[BOARD_UART_COUNT];
__EVENT		serialTxEvts[BOARD_UART_COUNT];
__EVENT		serialRxEvts[BOARD_UART_COUNT];

/* Definition of the UART1.
 * Each UART in the akstm32gps board should have a definition
 * like the following.
 */
UART_PARAMS	uartParams[BOARD_UART_COUNT] = {
	{
		BOARD_UART1_TX_PIN,
		BOARD_UART1_RX_PIN,
		BOARD_UART1_PORT,
		BOARD_UART1_BASE_REG,
		BOARD_UART1_BUS_ADDR,
		BOARD_UART1_PORT_BUS_ADDR,
		BOARD_UART1_APB_BUS,
	},
	{
		BOARD_UART2_TX_PIN,
		BOARD_UART2_RX_PIN,
		BOARD_UART2_PORT,
		BOARD_UART2_BASE_REG,
		BOARD_UART2_BUS_ADDR,
		BOARD_UART2_PORT_BUS_ADDR,
		BOARD_UART2_APB_BUS,
	}
};

__DEVICE serialDevices[BOARD_UART_COUNT] = {
		{
			"serial1",
			__DEV_USART,
			0,
			0,
			BOARD_UART1_IRQ,
			BOARD_UART1_IRQ,
			0,
			0,
			&serialTxEvts[0],		// TX event manager
			&serialRxEvts[0],		// RX event manager
			__NULL,
			&serialPdb[0],
			&uartParams[0],
			__serialInit,			// Device init function
			__serialDestroy,		// Device destroy function
			__serialIOCtl,			// Device IO control function
			__serialOpen,			// Device open function
			__serialClose,			// Device close function
			__serialRead,			// Device read function
			__serialWrite,			// Device write function
			__serialFlush,			// Device flush function
			__serialSize,			// Device size function
			__serialPlatIoCtl,		// Platform-related IO control */
			__NULL,					// Pointer to next device driver*/
		},
		{
			"serial2",
			__DEV_USART,
			0,
			0,
			BOARD_UART2_IRQ,
			BOARD_UART2_IRQ,
			0,
			0,
			&serialTxEvts[1],		// TX event manager
			&serialRxEvts[1],		// RX event manager
			__NULL,
			&serialPdb[1],
			&uartParams[1],
			__serialInit,			// Device init function
			__serialDestroy,		// Device destroy function
			__serialIOCtl,			// Device IO control function
			__serialOpen,			// Device open function
			__serialClose,			// Device close function
			__serialRead,			// Device read function
			__serialWrite,			// Device write function
			__serialFlush,			// Device flush function
			__serialSize,			// Device size function
			__serialPlatIoCtl,		// Platform-related IO control */
			__NULL,					// Pointer to next device driver*/
		}
};

#endif // __CONFIG_COMPILE_SERIAL

#if __CONFIG_COMPILE_SPI
#include <drivers/spi/spi.h>

/*
 * As with the UART definitions,we do the same
 * for SPI driver interface (definitions used by
 * plat_spi.c helper).
 */

__SPIPDB spiPdb[BOARD_SPI_COUNT];
__EVENT	spiTxEvts[BOARD_SPI_COUNT];
__EVENT	spiRxEvts[BOARD_SPI_COUNT];

SPI_PARAMS spiParams[BOARD_SPI_COUNT] = {
	{
	BOARD_SPI1_GPIO_PORT,
	BOARD_SPI1_BUS_ADDR,
	BOARD_SPI1_GPIO_BUS_ADDR,
	BOARD_SPI1_APB_NUM,
	BOARD_SPI1_BASE_ADDR,
	BOARD_SPI1_PIN_MISO,
	BOARD_SPI1_PIN_MOSI,
	BOARD_SPI1_PIN_CLK,
	BOARD_SPI1_PIN_CS,
	BOARD_SPI1_DIRECTION,
	BOARD_SPI1_PRESCALER,
	BOARD_SPI1_CPOL,
	BOARD_SPI1_CPHA,
	BOARD_SPI1_NSS_MODE,
	}
};

__DEVICE spiDevices[BOARD_SPI_COUNT] = {
		{
			"spi1",
			__DEV_SPI,
			0,
			0,
			BOARD_SPI1_IRQ,
			BOARD_SPI1_IRQ,
			0,
			0,
			&spiTxEvts[0],		// TX event manager
			&spiRxEvts[0],		// RX event manager
			__NULL,
			&spiPdb[0],
			&spiParams[0],
			__spiInit,			// Device init function
			__spiDestroy,		// Device destroy function
			__spiIOCtl,			// Device IO control function
			__spiOpen,			// Device open function
			__spiClose,			// Device close function
			__spiRead,			// Device read function
			__spiWrite,			// Device write function
			__spiFlush,			// Device flush function
			__spiSize,			// Device size function
			__spiPlatIoCtl,
			__NULL,				// Pointer to next device driver*/
		}
};

#endif // __CONFIG_COMPILE_SPI


#if __CONFIG_COMPILE_SD
#include <drivers/sd/sd.h>

/*
 * As with the UART and SPI definitions,we do the same
 * for the SD driver (definitions used by plat_sd.c helper).
 */

__EVENT	sdTxEvts[BOARD_SD_COUNT];
__EVENT	sdRxEvts[BOARD_SD_COUNT];

__SDPDB sdPdb[BOARD_SD_COUNT] = {
	{
		BOARD_SD1_DEVICE,
		BOARD_SD1_DEVICE_MODE,
	}
};

SD_PARAMS sdParams[BOARD_SD_COUNT] = {
	{

#ifdef BOARD_SD1_CD_PIN
		1,
		BOARD_SD1_CD_PIN,
		BOARD_SD1_CD_PORT,
		BOARD_SD1_CD_PIN_BUS_NUM,
		BOARD_SD1_CD_PIN_BUS_ADDR,
#else
		0,
#endif //BOARD_SD1_CD_PIN

#ifdef BOARD_SD1_WP_PIN
		1,
		0,
		0,
		0,
		0,
#else
		0,
#endif // BOARD_SD1_WP_PIN
	}
};

__DEVICE sdDevices[BOARD_SD_COUNT] = {
	{
		"sd1",
		__DEV_CFSD,
		0,
		0,
		0,
		0,
		0,
		0,
		&sdTxEvts[0],		// TX event manager
		&sdRxEvts[0],		// RX event manager
		__NULL,
		&sdPdb[0],
		&sdParams[0],
		__sdInit,			// Device init function
		__sdDestroy,		// Device destroy function
		__sdIOCtl,			// Device IO control function
		__sdOpen,			// Device open function
		__sdClose,			// Device close function
		__sdRead,			// Device read function
		__sdWrite,			// Device write function
		__sdFlush,			// Device flush function
		__sdSize,			// Device size function
		__sdPlatIoCtl,		// Pointer to next device driver*/
	}
};

#endif // __CONFIG_COMPILE_SD

#if __CONFIG_COMPILE_GPS
#include <drivers/gps/gps.h>
#include <common/nmea.h>

__GPS_PDB gpsPdb = {
	BOARD_GPS_DEVICE,
	BOARD_GPS_DEVICE_SPEED,
};

GPS_PARAMS gpsParams = {
	/* GPS power pin */
	__TRUE,
	BOARD_GPS_POWER_PIN,
	BOARD_GPS_POWER_PIN_PORT,
	BOARD_GPS_POWER_PIN_BUS_NUM,
	BOARD_GPS_POWER_PIN_BUS_ADDR,

	/* GPS fix pin */
	__TRUE,
	BOARD_GPS_FIX_PIN,
	BOARD_GPS_FIX_PIN_PORT,
	BOARD_GPS_FIX_PIN_BUS_NUM,
	BOARD_GPS_FIX_PIN_BUS_ADDR,
};

__DEVICE gpsDevice = {
	"gps",
	__DEV_STREAM,
	0,
	0,
	0,
	0,
	0,
	0,
	__NULL,				// TX event manager
	__NULL,				// RX event manager
	__NULL,
	&gpsPdb,
	&gpsParams,
	__gpsInit,			// Device init function
	__gpsDestroy,		// Device destroy function
	__gpsIOCtl,			// Device IO control function
	__gpsOpen,			// Device open function
	__gpsClose,			// Device close function
	__gpsRead,			// Device read function
	__gpsWrite,			// Device write function
	__gpsFlush,			// Device flush function
	__gpsSize,			// Device size function
	__gpsPlatIoCtl,		// Pointer to next device driver*/

};


#endif /* __CONFIG_COMPILE_GPS__ */

/*
 * Character LCD for the AKSTM32GPS board
 */
#if __CONFIG_COMPILE_CHARLCD
#include <drivers/charlcd/charlcd.h>

/* Char LCD private data block */
__CHARLCDPDB charlcdPdb = {0};

/* Char LCD HW parameters */
__CHARLCD_PARAMS charlcdParams = {
	BOARD_CHARLCD_PORT,
	BOARD_CHARLCD_PORT_CLK_ADDR,
	BOARD_CHARLCD_PORT_APB_BUS,
	BOARD_CHARLCD_PIN_D0,
	BOARD_CHARLCD_PIN_D1,
	BOARD_CHARLCD_PIN_D2,
	BOARD_CHARLCD_PIN_D3,
	BOARD_CHARLCD_PIN_D4,
	BOARD_CHARLCD_PIN_D5,
	BOARD_CHARLCD_PIN_D6,
	BOARD_CHARLCD_PIN_D7,
	BOARD_CHARLCD_PIN_RS,
	BOARD_CHARLCD_PIN_RW,
	BOARD_CHARLCD_PIN_E
};

/* Char LCD device definition */
__DEVICE charlcdDevice = {
	"charlcd",
	__DEV_DISPLAY,
	0,
	0,
	0,
	0,
	0,
	0,
	__NULL,					// TX event manager
	__NULL,					// RX event manager
	__NULL,
	&charlcdPdb,
	&charlcdParams,
	__charlcdInit,			// Device init function
	__charlcdDestroy,		// Device destroy function
	__charlcdIOCtl,			// Device IO control function
	__charlcdOpen,			// Device open function
	__charlcdClose,			// Device close function
	__charlcdRead,			// Device read function
	__charlcdWrite,			// Device write function
	__charlcdFlush,			// Device flush function
	__charlcdSize,			// Device size function
	__charlcdPlatIoCtl,		// Pointer to next device driver*/
};

#endif /* __CONFIG_COMPILE_CHARLCD */

/*!
 * @brief Custom board hardware initialization.
 *
 * If you are implementing a custom board, this is the only
 * function you should define.
 *
 * Called from __cpuInitHardware() to initialize
 * custom hardware for a specific board.
 *
 * @return 		Nothing.
 */
__VOID __boardInitHW(__VOID) {

	/* Configure all the pins for the akstm32gps
	 * For known devices like GPS, UART, SPI, etc., let the
	 * driver configure their pins.
	 * We will set here some leds, keys, and leave unused pins
	 * as floating inputs.
	 */
	GPIO_InitTypeDef 	GPIO_InitStructure;

	/* Clock alternate function, we will use this feature later */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);

	/* ==== PORT A ==== */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

	/* PORT A inputs */
	GPIO_InitStructure.GPIO_Pin = (	GPIO_Pin_1  |		/* USB Wake up */
									GPIO_Pin_11 |		/* USB_M */
									GPIO_Pin_12);		/* USB_P */

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOA, &GPIO_InitStructure);

	/* ==== PORT B ==== */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);

	/* PORT B inputs */
	GPIO_InitStructure.GPIO_Pin = (	GPIO_Pin_8  |		/* I2C_SCL */
									GPIO_Pin_9  |		/* I2C_SDA */
									GPIO_Pin_14 |		/* GPS antenna status */
									GPIO_Pin_15);		/* GPS antenna short circuit */

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* PORT B outputs */
	GPIO_InitStructure.GPIO_Pin = (	GPIO_Pin_1  |		/* LED 1 */
									GPIO_Pin_5  |		/* LED 2 */
									GPIO_Pin_6  |		/* LED 3 */
									GPIO_Pin_7  |		/* LED 4 */
									GPIO_Pin_10 |		/* LED 5 */
									GPIO_Pin_11 |		/* LED 6 */
									GPIO_Pin_12 |		/* LED 7 */
									GPIO_Pin_13);		/* LED 8 */

	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	/* ==== PORT C ==== */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);

	/* PORT C inputs */
	GPIO_InitStructure.GPIO_Pin = (	GPIO_Pin_0  |		/* Display data 5 */
									GPIO_Pin_1  |		/* Display data 6 */
									GPIO_Pin_2  |		/* Display data 7 */
									GPIO_Pin_3  |		/* Display data 8 */
									GPIO_Pin_4  |		/* To expansion connector */
									GPIO_Pin_5  |		/* To expansion connector */
									GPIO_Pin_6  |		/* To expansion connector */
									GPIO_Pin_7  |		/* To expansion connector */
									GPIO_Pin_8  |		/* Display RS */
									GPIO_Pin_9  |		/* Display r/w */
									GPIO_Pin_10);		/* Display E */

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

	/* PORT C inputs (KEYS) */
	GPIO_InitStructure.GPIO_Pin = (	GPIO_Pin_11  |		/* Key 1 */
									GPIO_Pin_12  |		/* Key 2 */
									GPIO_Pin_13);		/* Key 3 */

	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
	GPIO_Init(GPIOC, &GPIO_InitStructure);

}


#endif // BOARD_MCBSTM32
