/***************************************************************************
 * mcbstm32.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "mcbstm32.h"

#ifdef BOARD_MCBSTM32

#if __CONFIG_COMPILE_SERIAL
#include <drivers/serial/serial.h>

/*
 * Example of lower-layer driver definition for
 * USART1, for the stm32f103x, on the KEIL MCBSTM32 board
 * --------------------------------------------------------------------------
 *
 * The plat_uart.c helper will use the serialDevices array when indexing the
 * available uarts (that may vary from board to board).
 *
 * We are defining the available uarts this way. However they can be
 * initialized at runtime using __boardInitHW(). This is done because the
 * stm32 can remap it's ports to different pins, and that could be a difference
 * between boards. The same applies for the rest of the implemented device
 * drivers.
 *
 * If you are implementing another board for a stm32 mcu you can copy this
 * initialization and change it.
 *
 * This is naturally a characteristic of the default base implementation
 * for Milos device drivers. It is not said that ALL the drivers helpers
 * bound to a platform should be implemented this way. You can even define
 * constants for parameters for example, in the  mcbstm32.h, and reference
 * these constants directly in your plat_xxxxx.c driver (without defining
 * and array like the drivers implemented below).
 *
 * It is important to make the __PDEVICE pointers visible to the upper layers.
 * For example to "map" serialDevices[0] to __SERIAL_1
 *
 * The file mcbstm32.h declares:
 * #define __SERIAL_1 &serialDevices[0]
 *
 * The file plat_uart.h defines:
 * extern __DEVICE serialDevices[BOARD_UART_COUNT];
 *
 * What to do when adding/modifying/removing an uart:
 * 	-	Change BOARD_UART_COUNT if necessary.
 * 	-	Change the parameters constants (like BOARD_UART1_TX_PIN, etc.)
 * 	-	Change the uartParams array.
 * 	- 	Change the serialDevices array.
 */

__SERIALPDB serialPdb[BOARD_UART_COUNT];
__EVENT		serialTxEvts[BOARD_UART_COUNT];
__EVENT		serialRxEvts[BOARD_UART_COUNT];

/* Definition of the UART1.
 * Each UART in the mcbstm32 board should have a definition
 * like the following.
 */
UART_PARAMS	uartParams[BOARD_UART_COUNT] = {
	{
		BOARD_UART1_TX_PIN,
		BOARD_UART1_RX_PIN,
		BOARD_UART1_PORT,
		BOARD_UART1_BASE_REG,
		BOARD_UART1_BUS_ADDR,
		BOARD_UART1_PORT_BUS_ADDR,
		BOARD_UART1_APB_BUS,
	}
};

__DEVICE serialDevices[BOARD_UART_COUNT] = {
		{
			"serial1",
			__DEV_USART,
			0,
			0,
			BOARD_UART1_IRQ,
			BOARD_UART1_IRQ,
			0,
			0,
			&serialTxEvts[0],		// TX event manager
			&serialRxEvts[0],		// RX event manager
			__NULL,
			&serialPdb[0],
			&uartParams[0],
			__serialInit,			// Device init function
			__serialDestroy,		// Device destroy function
			__serialIOCtl,			// Device IO control function
			__serialOpen,			// Device open function
			__serialClose,			// Device close function
			__serialRead,			// Device read function
			__serialWrite,			// Device write function
			__serialFlush,			// Device flush function
			__serialSize,			// Device size function
			__serialPlatIoCtl,		// Platform-related IO control */
			__NULL,					// Pointer to next device driver*/
		}
};

#endif // __CONFIG_COMPILE_SERIAL

#if __CONFIG_COMPILE_SPI
#include <drivers/spi/spi.h>

/*
 * As with the UART definitions,we do the same
 * for SPI driver interface (definitions used by
 * plat_spi.c helper).
 */

__SPIPDB spiPdb[BOARD_SPI_COUNT];
__EVENT	spiTxEvts[BOARD_SPI_COUNT];
__EVENT	spiRxEvts[BOARD_SPI_COUNT];

SPI_PARAMS spiParams[BOARD_SPI_COUNT] = {
	{
	BOARD_SPI1_GPIO_PORT,
	BOARD_SPI1_BUS_ADDR,
	BOARD_SPI1_GPIO_BUS_ADDR,
	BOARD_SPI1_APB_NUM,
	BOARD_SPI1_BASE_ADDR,
	BOARD_SPI1_PIN_MISO,
	BOARD_SPI1_PIN_MOSI,
	BOARD_SPI1_PIN_CLK,
	BOARD_SPI1_PIN_CS,
	BOARD_SPI1_DIRECTION,
	BOARD_SPI1_PRESCALER,
	BOARD_SPI1_CPOL,
	BOARD_SPI1_CPHA,
	BOARD_SPI1_NSS_MODE,
	}
};

__DEVICE spiDevices[BOARD_SPI_COUNT] = {
		{
			"spi1",
			__DEV_SPI,
			0,
			0,
			BOARD_SPI1_IRQ,
			BOARD_SPI1_IRQ,
			0,
			0,
			&spiTxEvts[0],		// TX event manager
			&spiRxEvts[0],		// RX event manager
			__NULL,
			&spiPdb[0],
			&spiParams[0],
			__spiInit,			// Device init function
			__spiDestroy,		// Device destroy function
			__spiIOCtl,			// Device IO control function
			__spiOpen,			// Device open function
			__spiClose,			// Device close function
			__spiRead,			// Device read function
			__spiWrite,			// Device write function
			__spiFlush,			// Device flush function
			__spiSize,			// Device size function
			__spiPlatIoCtl,
			__NULL,				// Pointer to next device driver*/
		}
};

#endif // __CONFIG_COMPILE_SPI


#if __CONFIG_COMPILE_SD
#include <drivers/sd/sd.h>

/*
 * As with the UART and SPI definitions,we do the same
 * for the SD driver (definitions used by plat_sd.c helper).
 */

__EVENT	sdTxEvts[BOARD_SD_COUNT];
__EVENT	sdRxEvts[BOARD_SD_COUNT];

__SDPDB sdPdb[BOARD_SD_COUNT] = {
	{
		BOARD_SD1_DEVICE,
		BOARD_SD1_DEVICE_MODE,
	}
};

SD_PARAMS sdParams[BOARD_SD_COUNT] = {
	{

#ifdef BOARD_SD1_CD_PIN
		1,
		BOARD_SD1_CD_PIN,
		BOARD_SD1_CD_PORT,
		BOARD_SD1_CD_PIN_BUS_NUM,
		BOARD_SD1_CD_PIN_BUS_ADDR,
#else
		0,
#endif //BOARD_SD1_CD_PIN

#ifdef BOARD_SD1_WP_PIN
		1,
		0,
		0,
		0,
		0,
#else
		0,
#endif // BOARD_SD1_WP_PIN
	}
};

__DEVICE sdDevices[BOARD_SD_COUNT] = {
	{
		"sd1",
		__DEV_CFSD,
		0,
		0,
		0,
		0,
		0,
		0,
		&sdTxEvts[0],		// TX event manager
		&sdRxEvts[0],		// RX event manager
		__NULL,
		&sdPdb[0],
		&sdParams[0],
		__sdInit,			// Device init function
		__sdDestroy,		// Device destroy function
		__sdIOCtl,			// Device IO control function
		__sdOpen,			// Device open function
		__sdClose,			// Device close function
		__sdRead,			// Device read function
		__sdWrite,			// Device write function
		__sdFlush,			// Device flush function
		__sdSize,			// Device size function
		__sdPlatIoCtl,		// Pointer to next device driver*/
	}
};

#endif // __CONFIG_COMPILE_SD

/*
 * Character LCD for the AKSTM32GPS board
 */
#if __CONFIG_COMPILE_CHARLCD
#include <drivers/charlcd/charlcd.h>

/* Char LCD private data block */
__CHARLCDPDB charlcdPdb = {0};

/* Char LCD HW parameters */
__CHARLCD_PARAMS charlcdParams = {
	BOARD_CHARLCD_PORT,
	BOARD_CHARLCD_PORT_CLK_ADDR,
	BOARD_CHARLCD_PORT_APB_BUS,
	BOARD_CHARLCD_PIN_D0,
	BOARD_CHARLCD_PIN_D1,
	BOARD_CHARLCD_PIN_D2,
	BOARD_CHARLCD_PIN_D3,
	BOARD_CHARLCD_PIN_D4,
	BOARD_CHARLCD_PIN_D5,
	BOARD_CHARLCD_PIN_D6,
	BOARD_CHARLCD_PIN_D7,
	BOARD_CHARLCD_PIN_RS,
	BOARD_CHARLCD_PIN_RW,
	BOARD_CHARLCD_PIN_E
};

/* Char LCD device definition */
__DEVICE charlcdDevice = {
	"charlcd",
	__DEV_DISPLAY,
	0,
	0,
	0,
	0,
	0,
	0,
	__NULL,					// TX event manager
	__NULL,					// RX event manager
	__NULL,
	&charlcdPdb,
	&charlcdParams,
	__charlcdInit,			// Device init function
	__charlcdDestroy,		// Device destroy function
	__charlcdIOCtl,			// Device IO control function
	__charlcdOpen,			// Device open function
	__charlcdClose,			// Device close function
	__charlcdRead,			// Device read function
	__charlcdWrite,			// Device write function
	__charlcdFlush,			// Device flush function
	__charlcdSize,			// Device size function
	__charlcdPlatIoCtl,		// Pointer to next device driver*/
};

#endif /* __CONFIG_COMPILE_CHARLCD */


/*!< @brief Custom board hardware initialization.
 *
 * If you are implementing a custom board, this is the only
 * function you should define.
 * Called from __cpuInitHardware() to initialize
 * custom hardware for a specific board.
 *
 * @return 		Nothing.
 */
__VOID __boardInitHW(__VOID) {

	GPIO_InitTypeDef 	GPIO_InitStructure;

	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO | RCC_APB2Periph_GPIOB, ENABLE);
	GPIO_InitStructure.GPIO_Pin = (	GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 |
									GPIO_Pin_11 | GPIO_Pin_12 | GPIO_Pin_13 |
									GPIO_Pin_14 | GPIO_Pin_15);
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
}

#endif // BOARD_MCBSTM32
