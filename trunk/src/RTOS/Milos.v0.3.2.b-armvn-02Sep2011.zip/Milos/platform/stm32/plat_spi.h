/***************************************************************************
 * plat_spi.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef	__PLAT_SPI_H__
#define	__PLAT_SPI_H__

#include "plat_cpu.h"
#include <core/device.h>


#if __CONFIG_COMPILE_SPI
#include <stm32f10x_spi.h>

typedef struct {
	GPIO_TypeDef*	gpio_port;
	u32				bus_clock_addr;
	u32				gpio_clock_addr;
	u8				apb_num;
	SPI_TypeDef*	base_addr;
	u32				pin_miso;
	u32				pin_mosi;
	u32				pin_clk;
	u32				pin_cs;	
	u16				direction;
	u32				prescaler;	
	u32				cpol;
	u32				cpha;	
	u32				nss_mode;
	
} SPI_PARAMS, *PSPI_PARAMS;

/* Glue here the SPIs from board definition file */
/* Define here the available SPI devices on you board file */
extern __DEVICE spiDevices[BOARD_SPI_COUNT];

i32 __spiPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len);

#endif // __CONFIG_COMPILE_SPI

#endif // __PLAT_SPI_H__


