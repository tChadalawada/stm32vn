/***************************************************************************
 * plat_cpu.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef __PLAT_CPU_H__
#define	__PLAT_CPU_H__

#include "plat_ostypes.h"
#include "plat_comp_dep.h"
#include "plat_config.h"

/* Include available boards
 * Any file that provides access to exclusive devices
 * for a certain mcu/board should be included here.
 */
/* TODO Decide where to define the board type.
 * 		It should be filtering which board to compile.
 * 		By now we're putting it in plat_config.h */
#include __PLATCONFIG_BOARD_DEF_FILE

#define __pinGet(x, y) ((x)->ODR & y)
#define __pinSet(x, y, z) (__VOID)((z) ? ((x)->ODR |= (y)) : ((x)->ODR &= ~(y)))
#define __portSet(x, y) ((x)->ODR = y)

#define CPU_TICKS_TO_MS(x)			((u32)(x))
#define CPU_MS_TO_TICKS(x)			((u32)(x))

/** @addtogroup Platform
  * @{
  */

/** @addtogroup PlatformFunctions Functions
  * @{
  */

/*!
 * @brief Disable interrupts.
 *
 * @return Nothing.
 */
#define __cpuDisableInterrupts()		__pcd_DisableIRQs()

/*!
 * @brief Enable interrupts.
 *
 * @return Nothing.
 */
#define __cpuEnableInterrupts()			__pcd_EnableIRQs()

/*!
 * @brief OS in entering IDLE mode.
 *
 * @return Nothing.
 */
#define	__cpuIdleIn()


/*!
 * @brief OS in exiting IDLE mode.
 *
 * @return Nothing.
 */
#define	__cpuIdleOut()

/**
  * @}
  */

/**
  * @}
  */

#define __CPU_MAX_IRQ	44

__VOID	__cpuInitHardware(__VOID);
__VOID 	__cpuInitTimers(__VOID);
__VOID 	__cpuInitSchedulerTimer(__VOID);
u32 	__cpuMakeStackFrame(u32 stkptr, __PVOID *func, __PVOID param);
u32		__cpuStackFramePointer(pu8 stkptr, u32 stack);
__VOID 	__cpuInitClock(__VOID);
__VOID 	__cpuInitInterrupts(__VOID);
__VOID 	__cpuInitSVCPendingInterrupt(__VOID);
__VOID 	__cpuCustomCreateSystemThread(__VOID);
__VOID	__cpuScheduleThreadChange(__VOID);
__VOID	__cpuClearPendingThreadChange(__VOID);
__BOOL	__cpuThreadChangeScheduled(__VOID);
__VOID	__cpuStartMMU(__VOID);
__VOID	__cpuStartWatchdog(__VOID);
__VOID	__cpuResetWatchdog(__VOID);
__VOID	__cpuHeartBeat(__VOID);
__VOID 	__cpuDelayMs(u32 ms);

#endif //__PLAT_CPU_H__
