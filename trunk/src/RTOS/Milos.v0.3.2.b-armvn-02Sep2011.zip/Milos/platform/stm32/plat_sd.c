/***************************************************************************
 * plat_sd.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

/*
 * This file is part of the sd.c driver
 * for the stm32. Bounds the sd.c interface
 * with the hardware.
 */
 
#include "plat_sd.h"
#include <drivers/sd/sd.h>

#ifdef __PLATCONFIG_BOARD
#include __PLATCONFIG_BOARD_DEF_FILE
#endif // __PLATCONFIG_BOARD

#if __CONFIG_COMPILE_SD

__STATIC u8 __sdSetParameters(__PDEVICE dv)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	PSD_PARAMS params;

	params = dv->dv_params;
	
	/* Card detect configuration */
	if (params->cd_present)
	{
		GPIO_InitStructure.GPIO_Pin = params->cd_pin;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_Init(params->cd_port, &GPIO_InitStructure);
		
		if (params->cd_bus_num == 1)
		{
	  		RCC_APB1PeriphClockCmd(params->cd_bus_addr, ENABLE);
  		} else
  		{
  			RCC_APB2PeriphClockCmd(params->cd_bus_addr, ENABLE);
  		}		
	}

	/* Write protect configuration */	
	if (params->wp_present)
	{
		GPIO_InitStructure.GPIO_Pin = params->wp_pin;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
		GPIO_Init(params->wp_port, &GPIO_InitStructure);
		
		if (params->wp_bus_num == 1)
		{
	  		RCC_APB1PeriphClockCmd(params->wp_bus_addr, ENABLE);
  		} else
  		{
  			RCC_APB2PeriphClockCmd(params->wp_bus_addr, ENABLE);
  		}
	}
	
	return __TRUE;
}

__STATIC u8 __sdGetCD(__PDEVICE dv)
{
	PSD_PARAMS params;
	params = dv->dv_params;
	
	if (!params->cd_present) return 0;
	
	return (__pinGet(params->cd_port, params->cd_pin)?1:0);
}

__STATIC u8 __sdGetWP(__PDEVICE dv)
{
	PSD_PARAMS params;
	params = dv->dv_params;
	if (!params->wp_present) return 0;
	return (__pinGet(params->wp_port, params->wp_pin)?1:0);
}


/*
 * @brief SD for stm32 IO control function
 *
 * Called from @ref SD driver to perform platform-related
 * tasks, like pin configuration or baudrate settings.
 *
 * @param	dv		Pointer to device.
 * @param	code	IO control code.
 *
 * @arg	__SD_PLAT_INIT_HW			Initialize hardware.
 * @arg __SD_PLAT_SET_SPEED			Set communication speed.
 * @arg	__SD_PLAT_GET_CD			Card detect value.
 * @arg	__SD_PLAT_GET_WP			Write protect value.
 *
 * @param	param	Optional parameter.
 * @param	in		Input buffer pointer.
 * @param	in_len	Input buffer pointer length.
 * @param	out		Output buffer pointer.
 * @param	out_len Output buffer pointer length.
 *
 * @return 	A value depending on the requested code execution.
 *
 */
i32 __sdPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len)
{
	switch (code)
	{
		case __SD_PLAT_INIT_HW:
			return __sdSetParameters(dv);

		case __SD_PLAT_GET_CD:
			return __sdGetCD(dv);

		case __SD_PLAT_GET_WP:
			return __sdGetWP(dv);
	}

	return 0;
}

#endif /* __CONFIG_COMPILE_SD */
