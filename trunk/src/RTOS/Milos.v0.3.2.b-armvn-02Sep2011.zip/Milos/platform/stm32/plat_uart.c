/***************************************************************************
 * plat_uart.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

/*
 * This file is part of the serial.c driver
 * for the stm32. Bounds the serial.c interface
 * with the hardware.
 */


#include "plat_uart.h"
#include <drivers/serial/serial.h>
#include <core/intrvect.h>
#include <stm32f10x_usart.h>

#ifdef __PLATCONFIG_BOARD
#include __PLATCONFIG_BOARD_DEF_FILE
#endif // __PLATCONFIG_BOARD

#if __CONFIG_COMPILE_SERIAL

__STATIC u8 __uartSetParameters(__PDEVICE dv)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	USART_InitTypeDef USART_InitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	USART_ClockInitTypeDef	USART_InitClock;
	PUART_PARAMS params;

	params = dv->dv_params;

	if (params->apb_bus_num == 2)
	{
		RCC_APB2PeriphClockCmd(params->port_clock_addr, ENABLE);
	} else
	{
		RCC_APB1PeriphClockCmd(params->port_clock_addr, ENABLE);
	}

 	/* 	Configure USART1 Tx as alternate function push-pull */
  	GPIO_InitStructure.GPIO_Pin = params->tx_pin;
  	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  	GPIO_Init(params->port_addr, &GPIO_InitStructure);

  	/* 	Configure USART1 Rx as input floating */
  	GPIO_InitStructure.GPIO_Pin = params->rx_pin;
  	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
  	GPIO_Init(params->port_addr, &GPIO_InitStructure);

  	/* APB clock */
	if (params->apb_bus_num == 2)
	{
		RCC_APB2PeriphClockCmd(params->bus_clock_addr, ENABLE);
	} else
	{
		RCC_APB1PeriphClockCmd(params->bus_clock_addr, ENABLE);
	}

	/* 	SET the SERIAL NVIC channel */
	NVIC_InitStructure.NVIC_IRQChannel = dv->dv_txint;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
	USART_InitStructure.USART_BaudRate = 9600;
  	USART_InitStructure.USART_WordLength = USART_WordLength_8b;
  	USART_InitStructure.USART_StopBits = USART_StopBits_1;
  	USART_InitStructure.USART_Parity = USART_Parity_No;
  	USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  	USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	
	USART_Init(params->base_addr, &USART_InitStructure);
	
	USART_InitClock.USART_Clock = USART_Clock_Disable;
  	USART_InitClock.USART_CPOL = USART_CPOL_Low;
  	USART_InitClock.USART_CPHA = USART_CPHA_2Edge;
  	USART_InitClock.USART_LastBit = USART_LastBit_Disable;
	
	USART_ClockInit(params->base_addr, &USART_InitClock);
	
	__systemStop();
	
	/* 	Enable the USART Receive interrupt: this interrupt is generated when the 
   		USART1 receive data register is not empty */
  	USART_ITConfig(params->base_addr, USART_IT_RXNE, ENABLE);
	
  	/* 	Enable USART1 */
  	USART_Cmd(params->base_addr, ENABLE);
	
	__systemStart();

	return __DEV_OK;
}

__STATIC u8 __uartCharOutput(__PDEVICE dv, u8 c)
{
	USART_TypeDef* pSERIAL;
	pSERIAL = ((UART_PARAMS*) dv->dv_params)->base_addr;
	pSERIAL->DR = (c & (u16)0x01FF);
	return __DEV_OK;
}

__STATIC u8 __uartCharInput(__PDEVICE dv)
{
	USART_TypeDef* pSERIAL;
	pSERIAL = ((UART_PARAMS*) dv->dv_params)->base_addr;
	return pSERIAL->DR;
}

__STATIC u8 __uartSetBaudrate(__PDEVICE dv, u32 spd)
{
	u32 				tmpreg = 0x00;
	u32 				apbclock = 0x00;
	RCC_ClocksTypeDef	RCC_ClocksStatus;
	USART_TypeDef* 		pSERIAL;
	u32 				integerdivider = 0x00;
	u32 				fractionaldivider = 0x00;

	pSERIAL = ((UART_PARAMS*) dv->dv_params)->base_addr;
	
	/* Get SERIAL address using ST libraries (map) */
	RCC_GetClocksFreq(&RCC_ClocksStatus);
	if (pSERIAL == USART1)
	{
    	apbclock = RCC_ClocksStatus.PCLK2_Frequency;
  	} else {
    	apbclock = RCC_ClocksStatus.PCLK1_Frequency;
  	}

  	/* Determine the integer part */
  	integerdivider = ((0x19 * apbclock) / (0x04 * (spd)));
  	tmpreg = (integerdivider / 0x64) << 0x04;

  	/* Determine the fractional part */
  	fractionaldivider = integerdivider - (0x64 * (tmpreg >> 0x04));
  	tmpreg |= ((((fractionaldivider * 0x10) + 0x32) / 0x64)) & ((u8)0x0F);
	
 	/* Write to USART BRR */
  	pSERIAL->BRR = (u16)tmpreg;

  	return __DEV_OK;
}

__VOID __uartISR(__PVOID pVoid)
{
	__PDEVICE dv;
	__PSERIALPDB pd;
	USART_TypeDef* pSERIAL;
	u32	irr;

	__systemEnterISR();

	dv = (__PDEVICE) pVoid;
	pd = dv->dv_pdb;

	pSERIAL = ((UART_PARAMS*) dv->dv_params)->base_addr;
	irr = pSERIAL->SR;

	if (irr & USART_FLAG_TC)
	{
		pSERIAL->SR &= ~USART_FLAG_TC;
	}

	if (irr & USART_FLAG_TXE)
	{
		pSERIAL->SR &= ~USART_FLAG_TXE;

		if (pd->pd_txcnt)
		{
			__uartCharOutput(dv, *(pd->pd_txbuf + pd->pd_tcidx));
			if (++pd->pd_tcidx >= pd->pd_txlen) pd->pd_tcidx = 0;
			--pd->pd_txcnt;
		} else
		{
			/* Nothing to send, disable TXE and set event */
			if (pSERIAL->CR1 & USART_FLAG_TXE)
			{
				pSERIAL->CR1 &= ~USART_FLAG_TXE;
				__eventSet(dv->dv_txev);
			}
		}
	}

	if (irr & USART_FLAG_RXNE)
	{
		*(pd->pd_rxbuf + pd->pd_rcidx) = __uartCharInput(dv);
		if (++pd->pd_rcidx >= pd->pd_rxlen) pd->pd_rcidx = 0;
		if (++pd->pd_rxcnt > pd->pd_rxlen) pd->pd_rxerr |= __SERIALERR_OVERFLOW;
		__eventSet(dv->dv_rxev);
	}

	__systemLeaveISR();
}

u8 __uartInitTx(__PDEVICE dv)
{
	USART_TypeDef* pSERIAL;
	pSERIAL = ((UART_PARAMS*) dv->dv_params)->base_addr;
	pSERIAL->CR1 |= USART_FLAG_TXE;

	return __DEV_OK;
}

/*
 * @brief UART for stm32 IO control function
 *
 * Called from @ref Serial driver to perform platform-related
 * tasks, like pin configuration or baudrate settings.
 *
 * @param	dv		Pointer to device.
 * @param	code	IO control code.
 *
 * @arg	__SERIAL_PLAT_INIT_HW			Initialize hardware.
 * @arg __SERIAL_PLAT_SET_BAUDRATE		Set baudrate.
 * @arg	__SERIAL_PLAT_CHAR_OUTPUT		Character output.
 * @arg	__SERIAL_PLAT_CHAR_INPUT		Character input.
 * @arg __SERIAL_PLAT_INIT_TX			Start transmission.
 * @arg __SERIAL_PLAT_SET_IRQ			Configure interrupts.
 *
 * @param	param	Optional parameter.
 * @param	in		Input buffer pointer.
 * @param	in_len	Input buffer pointer length.
 * @param	out		Output buffer pointer.
 * @param	out_len Output buffer pointer length.
 *
 * @return 	A value depending on the requested code execution.
 *
 */
i32 __serialPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len)
{
	u8 ret;
	switch (code)
	{
		case __SERIAL_PLAT_INIT_HW:
			return __uartSetParameters(dv);

		case __SERIAL_PLAT_SET_BAUDRATE:
			return __uartSetBaudrate(dv, param);

		case __SERIAL_PLAT_CHAR_OUTPUT:
			return __uartCharOutput(dv, (u8) param);

		case __SERIAL_PLAT_CHAR_INPUT:
			ret = __uartCharInput(dv);
			*((u8*) out) = ret;
			out_len = 1;
			return __DEV_OK;

		case __SERIAL_PLAT_INIT_TX:
			return __uartInitTx(dv);

		case __SERIAL_PLAT_SET_IRQ:
			__intSetVector(dv->dv_txint,__uartISR,dv);
			return __DEV_OK;

		case __SERIAL_PLAT_UNSET_IRQ:
			__intSetVector(dv->dv_txint,__NULL,__NULL);
			return __DEV_OK;
	}

	return __DEV_UNK_IOCTL;
}

#endif // __CONFIG_COMPILE_SERIAL

