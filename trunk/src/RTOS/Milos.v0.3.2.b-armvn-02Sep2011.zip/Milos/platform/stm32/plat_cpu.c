/***************************************************************************
 * plat_cpu.c
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "plat_cpu.h"
#include <core/thread.h>
#include <core/system.h>
#include <stm32f10x_gpio.h>
#include <stm32f10x_rcc.h>
#include <stm32f10x_flash.h>
#include <misc.h>

/** @addtogroup Platform
  * @{
  */

#define NVIC_INT_CTRL   		0xE000ED04			/* @brief Interrupt control state register */
#define NVIC_PENDSVSET  		0x10000000			/* @brief Value to trigger PendSV exception */
#define NVIC_PENDSVCLEAR  		(1 << 27)			/* @brief Value to clear PendSV pending bit */
#define WD_BASE					0x40003000
#define WD_IWDG_KR				WD_BASE
#define WD_IWDG_PR				WD_BASE + 0x04
#define WD_IWDG_RLR				WD_BASE + 0x08
#define WD_IWDG_SR				WD_BASE + 0x0C
#define DBGMCU_CR				0xE0042004
#define SYSTICK_RELOAD			(SystemCoreClock / 1000)

/** @defgroup PlatformFunctions Functions
  * @{
  */

/*!
 * @brief Prepares thread stack frame.
 *
 * This function has to create and reorder the stack pointer passed as argument
 * in a way that when the thread is about to be executed for the first time, at
 * the moment of branching to the first instruction of the thread and popping the
 * registers, the stack is perfectly aligned, and the entry point of the function
 * of the thread is in the right place on the stack. For example, when using the
 * STM32, this function reorders the stack having in mind the way the CortexM3
 * restores the registers (in a particular order) when returning from an ISR.
 * Called from __threadCreate().
 *
 * @param	stkptr	Stack pointer start address.
 * @param	func	Pointer to thread execution function.
 * @param	param	Optional parameter to retrieve with __threadGetParameter().
 * @return	Stack pointer start address.
 */
u32 __cpuMakeStackFrame(u32 stkptr, __PVOID *func, __PVOID param)
{
	pu32 stk;

	stk = (pu32) stkptr;
	*(--stk)	= (u32)0x01000000L; 	/* xPSR */
	*(--stk) 	= (u32)func; 			/* Thread functions */
	*(--stk) 	= (u32)0x00000014L; 	/* R14 */
	*(--stk) 	= (u32)0x00000012L; 	/* R12 */
	*(--stk)	= (u32)0x00000003L; 	/* R3 */
	*(--stk) 	= (u32)0x00000002L; 	/* R2 */
	*(--stk)	= (u32)0x00000001L; 	/* R1 */
	*(--stk) 	= (u32)0;				/* R0 */
	 
	*(--stk) = (u32)0x00000011L; 	/* R11 */
	*(--stk) = (u32)0x00000010L; 	/* R10 */
	*(--stk) = (u32)0x00000009L; 	/* R9 */
	*(--stk) = (u32)0x00000008L; 	/* R8 */
	*(--stk) = (u32)0x00000007L; 	/* R7 */
	*(--stk) = (u32)0x00000006L; 	/* R6 */
	*(--stk) = (u32)0x00000005L; 	/* R5 */
    *(--stk)  = (u32)0x00000004L;	/* R4 */
    return (u32) stk;
}

/*!
 * @brief Initializes the clock.
 *
 * Initializes the microprocessor clock if needed.
 * As with __cpuInitHardware() the developer may implement this
 * initialization elsewhere. Called from __systemInit().
 *
 * @return Nothing.
 */
__VOID __cpuInitClock(__VOID)
{
	ErrorStatus HSEStartUpStatus;

	/* RCC system reset(for debug purpose) */
	RCC_DeInit();
	
	/* Enable High Speed Oscilator (HSE) */
	RCC_HSEConfig(RCC_HSE_ON);
	
	/* Wait till HSE is ready */
	HSEStartUpStatus = RCC_WaitForHSEStartUp();
	
	if(HSEStartUpStatus == SUCCESS)
	{
		/* HCLK = SYSCLK */
		RCC_HCLKConfig(RCC_SYSCLK_Div1); 
	  
		/* PCLK2 = HCLK */
		RCC_PCLK2Config(RCC_HCLK_Div1); 
	
		/* PCLK1 = HCLK/2 */
		RCC_PCLK1Config(RCC_HCLK_Div2);
		
		/* Flash 2 wait state */
		FLASH_SetLatency(FLASH_Latency_2);
		/* Enable Prefetch Buffer */
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);
	
		/* PLLCLK = 8MHz * 9 = 72 MHz */
		RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);
	
		/* Enable PLL */ 
		RCC_PLLCmd(ENABLE);
	
		/* Wait till PLL is ready */
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}
	
		/* Select PLL as system clock source */
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
	
		/* Wait till PLL is used as system clock source */
		while(RCC_GetSYSCLKSource() != 0x08)
		{
		}
	}
	
  	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE);
}

/*!
 * @brief Initializes interrupts
 *
 * Initializes interrupts, interrupts priorities, reallocates the
 * vector table if needed. Called from __systemInit().
 *
 * @return Nothing.
 */
__VOID __cpuInitInterrupts(__VOID)
{
#ifdef  VECT_TAB_RAM  
	/* Set the Vector Table base location at 0x20000000 */ 
	NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0); 
#else  /* VECT_TAB_FLASH  */
	/* Set the Vector Table base location at 0x08000000 */ 
	NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);   
#endif

	/* Init SVCPend Interrupt */
	__cpuInitSVCPendingInterrupt();	
}

/*!
 * @brief Starts the STM32 SYSTICK timer.
 *
 * Internal platform function. Configures the SYSTICK timer.
 *
 * @return Nothing.
 */
__VOID __cpuSetTimerSYSTICK(__VOID)
{
	SysTick_Config(SYSTICK_RELOAD);
}

/*!
 * @brief Initializes platform optional timers.
 *
 * Start hardware timers, mainly used by the applications. Called from __systemInit().
 *
 * @return Nothing.
 */
__VOID __cpuInitTimers(__VOID)
{
}


/*!
 * @brief Sets the STM32 PendSV interrupt.
 *
 * Internal platform function.
 *
 * @return Nothing.
 */
__VOID __cpuInitSVCPendingInterrupt(__VOID)
{
	__pcd_SetSvcPend();
}


/*!
 * @brief STM32 SYSTICK interrupt handler.
 *
 * As required in @ref platisrimpl, this function call
 * the __systemProcessTick() function.
 *
 * @return Nothing.
 */
__VOID __cpuSysTickHandler(__VOID)
{
	__systemEnterISR();
	__systemProcessTick();
	__systemLeaveISR();
}


/*!
 * @brief Extra configuration before entering first context switch.
 *
 * Called after the creation of the System Thread but before the first context
 * switching, to insert custom code before enabling interrupts and start changing
 * threads. Called from __systemCreateThread().
 *
 * @return Nothing.
 */
__VOID __cpuCustomCreateSystemThread(__VOID)
{
	__systemStop();
	__pcd_ZeroPSP();
	__systemStart();
}

/*!
 * @brief Forces a context switch.
 *
 * Used on __threadSleep() and __eventWait().
 * Sets (schedules) a call to the context-switching function.
 *
 * @return Nothing.
 */
__VOID	__cpuScheduleThreadChange(__VOID)
{
	pu32 intreg = (pu32) NVIC_INT_CTRL;
	*intreg |= NVIC_PENDSVSET;
}

/*!
 * @brief Disables a forced context switch.
 *
 * Disables the context-switch pending call if it was previously configured.
 *
 * @return Nothing.
 */
__VOID	__cpuClearPendingThreadChange(__VOID) {

	pu32 intreg = (pu32) NVIC_INT_CTRL;
	*intreg |= NVIC_PENDSVCLEAR;
}

/*!
 * @brief Checks for a previously pended call to the scheduler.
 *
 * @return Nothing.
 */
__BOOL	__cpuThreadChangeScheduled(__VOID)
{
	pu32 intreg = (pu32) NVIC_INT_CTRL;
	if (*intreg & NVIC_PENDSVSET) return __TRUE;
	return __FALSE;
}


/*!
 * @brief Starts the watchdog, if available.
 *
 * Starts the watchdog if any. Called from __systemInit().
 *
 * @return Nothing.
 */
__VOID	__cpuStartWatchdog(__VOID)
{
	pu32	reg_kr;
	pu32	reg_pr;
	pu32	reg_rlr;
	pu32	reg_dbg;

	reg_kr 	= (pu32) WD_IWDG_KR;
	reg_pr 	= (pu32) WD_IWDG_PR;
	reg_rlr = (pu32) WD_IWDG_RLR;
	reg_dbg = (pu32) 0xE0042004;
	
	/* Set watchdog to stop in debug mode */
	*reg_dbg |= (1 << 8);
		
	/* Unprotect registers */
	*reg_kr = 0x5555;
	
	/* Set prescaller and reload value */
	*reg_pr = 0x00;
	*reg_rlr = 0xFFF;
	
	/* Start watchdog */
	*reg_kr = 0xCCCC;
}

/*!
 * @brief Resets the watchdog, if available.
 *
 * Resets the watchdog if any. Called from __systemInit().
 *
 * @return Nothing.
 */
__VOID	__cpuResetWatchdog(__VOID)
{
	pu32 reg_kr = (pu32) WD_IWDG_KR;
	*reg_kr = 0xAAAA;
}


/*!
 * @brief Initializes the platform hardware.
 *
 * Main hardware initialization, like pins/ports direction.
 * This is optional because the developer may provide his own initialization.
 * Called from __systemInit().
 *
 * @return Nothing.
 */
__VOID	__cpuInitHardware(__VOID)
{
	/* Init Clock */
	__cpuInitClock();

#ifdef __PLATCONFIG_BOARD
	/* Call board-specific initialization */
	__boardInitHW();
#endif // __PLATCONFIG_BOARD

}

/*!
 * @brief Initializes the main timer for context-switching.
 *
 * The OS needs just one timer to work. This timer will be the timer used in context
 * change operations, and determines the granularity of the time units of the system.
 * For example, when using the STM32, this function sets the SYSTICK timer to 1 millisecond.
 * Called from __systemInit().
 *
 * @return Nothing.
 */
__VOID 	__cpuInitSchedulerTimer(__VOID)
{
	__cpuSetTimerSYSTICK();
}

/*!
 * @brief Aligns the stack pointer address, if required.
 *
 * Used in the case the stack pointer of the thread has to be re-aligned.
 * Called from __threadCreate().
 *
 * @return Nothing.
 */
u32 __cpuStackFramePointer(pu8 stkptr, u32 stack)
{
	u32 ptr = 0;
	/* align address to 8-bit for stm32 */
	ptr = (u32) (stkptr + stack);
	ptr = ((u32) ptr & 0xFFFFFFFC);
	
	return ptr;
}

/*!
 * @brief Starts memory manager, if any.
 *
 * @return Nothing.
 */
__VOID	__cpuStartMMU(__VOID)
{
}

/*!
 * @brief Heartbeat, called each 100ms from the __systemThread().
 *
 * @return Nothing.
 */
__VOID	__cpuHeartBeat(__VOID)
{
	if (GPIOB->ODR & GPIO_Pin_10) {
		GPIOB->ODR &= ~GPIO_Pin_10;
	} else {
		GPIOB->ODR |= GPIO_Pin_10;
	}
}

__VOID __cpuDelayMs(u32 ms)
{
	u32 ticks = __systemGetTickCount();
	while (__systemGetTickCount() - ticks < ms);
}

/**
  * @}
  */

/**
  * @}
  */

