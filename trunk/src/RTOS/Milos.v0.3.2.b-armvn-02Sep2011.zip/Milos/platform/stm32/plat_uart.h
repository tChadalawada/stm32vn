/***************************************************************************
 * plat_uart.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef __PLAT_UART_H__
#define __PLAT_UART_H__

#include "plat_cpu.h"
#include <core/thread.h>
#include <core/device.h>

/*! @file  */

#if __CONFIG_COMPILE_SERIAL

#ifndef BOARD_UART_COUNT
#error "uart.c helper needs BOARD_UART_COUNT to be defined. It depends on the board you have defined."
#endif

typedef struct {
	u32				tx_pin;
	u32				rx_pin;
	GPIO_TypeDef*	port_addr;
	USART_TypeDef*	base_addr;
	u32				bus_clock_addr;
	u32				port_clock_addr;
	u8				apb_bus_num;
} UART_PARAMS, *PUART_PARAMS;

/* Glue here the UARTs from board definition file */
/* Define here the available UART devices on your board file */
extern __DEVICE serialDevices[BOARD_UART_COUNT];

i32 __serialPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len);

#endif // __CONFIG_COMPILE_SERIAL

#endif // __PLAT_UART_H__
