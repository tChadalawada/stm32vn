/***************************************************************************
 * plat_gps.c
 * (C) 2011 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef __PLAT_GPS_H__
#define __PLAT_GPS_H__

#include <plat_cpu.h>
#include <core/device.h>

#if __CONFIG_COMPILE_GPS

extern __DEVICE gpsDevice;

typedef struct {
	u8				power_present;
	u32				power_pin;
	GPIO_TypeDef*	power_port;
	u8				power_bus_num;
	u32				power_bus_addr;
	u8				fix_present;
	u32				fix_pin;
	GPIO_TypeDef*	fix_port;
	u8				fix_bus_num;
	u32				fix_bus_addr;
} GPS_PARAMS, *PGPS_PARAMS;

i32 __gpsPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len);


#endif /* __CONFIG_COMPILE_GPS */

#endif /* __PLAT_GPS_H__ */
