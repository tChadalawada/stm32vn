/***************************************************************************
 * plat_sd.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef	__PLAT_SD_H__
#define	__PLAT_SD_H__

#include <plat_cpu.h>
#include <core/device.h>

/*! @file  */

#if __CONFIG_COMPILE_SD

typedef struct {
	u8				cd_present;
	u32				cd_pin;
	GPIO_TypeDef*	cd_port;
	u8				cd_bus_num;
	u32				cd_bus_addr;
	u8				wp_present;
	u32				wp_pin;
	GPIO_TypeDef*	wp_port;
	u8				wp_bus_num;
	u32				wp_bus_addr;
} SD_PARAMS, *PSD_PARAMS;

extern __DEVICE sdDevices[BOARD_SD_COUNT];

#endif // __CONFIG_COMPILE_SD

i32 __sdPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len);

#endif // __PLAT_SD_H__
