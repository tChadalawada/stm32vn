/***************************************************************************
 * plat_gps.c
 * (C) 2011 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "plat_gps.h"
#include "plat_cpu.h"
#include <drivers/gps/gps.h>

#if __CONFIG_COMPILE_GPS

__STATIC __VOID __gpsPower(__PDEVICE dv, __BOOL on_off)
{
	PGPS_PARAMS params;
	params = dv->dv_params;

	/* Power pin exists? */
	if (params->power_present)
	{
		if (on_off)
		{
			/* GPS is powered up with a 0 on the power pin */
			__pinSet(params->power_port, params->power_pin, __FALSE);
		} else {
			/* GPS is powered down with a 1 on the power pin */
			__pinSet(params->power_port, params->power_pin, __TRUE);
		}
	}
}

__STATIC __VOID __gpsInitHardware(__PDEVICE dv)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	PGPS_PARAMS params;

	params = dv->dv_params;

	/* Power pin configuration */
	if (params->power_present)
	{
		GPIO_InitStructure.GPIO_Pin = params->power_pin;
		GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
		GPIO_Init(params->power_port, &GPIO_InitStructure);

		if (params->power_bus_num == 1)
		{
	 		RCC_APB1PeriphClockCmd(params->power_bus_addr, ENABLE);
	  	} else
	  	{
	  		RCC_APB2PeriphClockCmd(params->power_bus_addr, ENABLE);
	  	}
	}

	/* Fix pin configuration */
	if (params->fix_present)
	{
		GPIO_InitStructure.GPIO_Pin = params->fix_pin;
		GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
		GPIO_Init(params->fix_port, &GPIO_InitStructure);

		if (params->fix_bus_num == 1)
		{
	 		RCC_APB1PeriphClockCmd(params->fix_bus_addr, ENABLE);
	  	} else
	  	{
	  		RCC_APB2PeriphClockCmd(params->fix_bus_addr, ENABLE);
	  	}
	}

	/* By default the GPS is off */
	__gpsPower(dv, __FALSE);

	return;
}

i32 __gpsPlatIoCtl(__PDEVICE dv, u32 code, u32 param, __PVOID in, u32 in_len, __PVOID out, u32 out_len)
{
	switch (code)
	{
		case __GPS_PLAT_SET_POWER:
			__gpsPower(dv, param);
			return __DEV_OK;

		case __GPS_PLAT_INIT_HW:
			__gpsInitHardware(dv);
			return __DEV_OK;

		case __GPS_PLAT_GET_FIX_FLAG:
		{
			PGPS_PARAMS params = dv->dv_params;
			if (params->fix_present)
			{
				return (__pinGet(params->fix_port, params->fix_pin)?1:0);
			}
			break;
		}
	}

	return __DEV_UNK_IOCTL;
}

#endif /* __CONFIG_COMPILE_GPS */
