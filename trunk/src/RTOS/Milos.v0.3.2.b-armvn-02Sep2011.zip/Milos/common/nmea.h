/***************************************************************************
 * nmea.h
 * (C) 2011 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef __NMEA_H__
#define __NMEA_H__

#include <plat_cpu.h>

/** @addtogroup Common
  * @{
  */

/** @defgroup NMEA NMEA
  * @{
  */

/** @defgroup NMEA_Constants Constants
  * @{
  */

/*
 * Local configuration.
 * @todo NMEA string configuration moved elsewhere.
 */
#define __NMEA_USE_RMC		1			/*!< @brief Parse RMC */
#define __NMEA_USE_GGA		1			/*!< @brief Parse GGA */
#define __NMEA_USE_GSV		1			/*!< @brief Parse GSV */
#define __NMEA_USE_VTG		1			/*!< @brief Parse VTG */

#if __NMEA_USE_GSV
#define __NMEA_MAX_GSV		4			/*!< @brief Max. GSV sentences */
#endif /* __NMEA_USE_GSV */

/**
  * @}
  */

/** @defgroup NMEA_Typedefs Typedefs
  * @{
  */

/*!
 * @brief NMEA RMC sentence.
 */
typedef struct __nmeaRMC
{
	u32 time;					/*!< @brief Time as received (long). */
	u32 date;					/*!< @brief Date as received (long). */
	u8 status;					/*!< @brief Status: 'A' for fix, 'V' for no-fix */
	i32 lat;					/*!< @brief Latitude in thousands of seconds (degrees * 60000) */
	i32 lon;					/*!< @brief Longitude in thousands of seconds (degrees * 60000) */
	u32 speed;					/*!< @brief Ground speed (knots) * 1000. */
	u32 heading;				/*!< @brief Heading (degrees) * 1000. */
	u32 magvar;					/*!< @brief Magnetic variation (degrees) * 1000. */
} __NMEA_RMC, *__PNMEA_RMC;

/*!
 * @brief NMEA GGA sentence.
 */
typedef struct __nmeaGGA
{
	i32 lat;					/*!< @brief Latitude in thousands of seconds (degrees * 60000) */
	i32 lon;					/*!< @brief Longitude in thousands of seconds (degrees * 60000) */
	u32 time;					/*!< @brief Time as received (long). */
	u8 quality;					/*!< @brief Quality of fix. */
	u8 sats;					/*!< @brief Satellites in view. */
	i32 altitude;				/*!< @brief Altitude (meters). */
	u32 hdop;					/*!< @brief Accuracy (degrees) * 1000. */
	i16 geoid;					/*!< @brief Height above WGS84 ellipsoid (Meter). */
} __NMEA_GGA, *__PNMEA_GGA;

/*!
 * @brief NMEA VTG sentence.
 */
typedef struct __nmeaVTG
{
	u32 track;					/*!< @brief True track made good (degrees) * 1000. */
	u32 knots;					/*!< @brief Knots * 1000. */
	u32 kmh;					/*!< @brief (Kilometers/hour) * 1000. */
} __NMEA_VTG, *__PNMEA_VTG;

/*!
 * @brief From GSV sentence.
 */
typedef struct __nmeaSV
{
	u16	prn;					/*!< @brief SV PRN number. */
	u16 elevation;				/*!< @brief Elevation (degrees). */
	u16 azimut;					/*!< @brief Azimuth (degrees). */
	u16 snr;					/*!< @brief SNR (00-99 dB). */
} __NMEA_SV, *__PNMEA_SV;

/*
 * @brief GSV message
 */
typedef struct __nmeaGSVMsg
{
	u16	msg_num;	  			/*!< @brief Message number. */
	__NMEA_SV sv[4];			/*!< @brief Detailed info for satellites in view (max. 4). */
} __NMEA_GSVMSG, *__PNMEA_GSVMSG;


/*!
 * @brief NMEA GSV sentence.
 */
typedef struct __nmeaGSV
{
	u16	total_msgs;  			/*!< @brief Number of VTG messages. */
	u16 qty_sv;					/*!< @brief Number of satellites in view. */
	__NMEA_GSVMSG vtg_msg[__NMEA_MAX_GSV];
} __NMEA_GSV, *__PNMEA_GSV;

/*!
 * @brief GPS data.
 */
typedef struct __gpsData
{

#if __NMEA_USE_RMC
	__NMEA_RMC 	rmc;					/*!< @brief RMC data */
#endif

#if __NMEA_USE_GGA
	__NMEA_GGA 	gga;					/*!< @brief GGA data */
#endif

#if __NMEA_USE_VTG
	__NMEA_VTG	vtg;					/*!< @brief VTG data */
#endif

#if __NMEA_USE_GSV
	__NMEA_GSV	gsv;					/*!< @brief GSV data */
#endif

} __GPS_DATA, *__PGPS_DATA;

/**
  * @}
  */

/** @defgroup NMEA_Prototypes Prototypes
  * @{
  */

typedef __VOID (__GPS_CMDFN)(__CONST __PSTRING);

/**
  * @}
  */

/** @addtogroup NMEA_Typedefs
  * @{
  */

/*!
 * @brief Structure to be used to register a parser for a given custom NMEA sentence.
 * To be used with the __nmeaRegisterCommand() function.
 */
typedef struct __gpsCmdTag {
	__PSTRING cmd;						/*!< @brief	Null-terminated string containing
													the header of the custom NMEA sentence,
													for example "GPTXT". */
	__GPS_CMDFN* fn;					/*!< @brief	Pointer to a __GPS_CMDFN type function. */
	struct __gpsCmdTag* next;			/*!< @brief Next __GPS_CMDFN structure. Leave to __NULL
													when passing this structure to the
													__nmeaRegisterCommand() function. */
} __GPS_CMD, *__PGPS_CMD;

/**
  * @}
  */


__BOOL __nmeaParseLine(__CONST __PSTRING line, __PGPS_DATA data);
u8 __nmeaChecksum(__CONST __PSTRING line);
__VOID __nmeaRegisterCommand(__PGPS_CMD cmd);
__VOID __nmeaUnregisterCommand(__PGPS_CMD cmd);
__CONST __PSTRING __nmeaGetField(__CONST __PSTRING line, u8 field, u8* len);
__BOOL __nmeaCheck(__CONST __PSTRING line);

/**
  * @}
  */

/**
  * @}
  */


#endif /* __NMEA_H__ */

