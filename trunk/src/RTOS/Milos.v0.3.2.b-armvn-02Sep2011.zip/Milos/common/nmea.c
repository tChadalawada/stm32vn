/***************************************************************************
 * nmea.c
 * (C) 2011 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

/* NMEA PARSER */

#include "nmea.h"
#include <common/string.h>

#if __CONFIG_COMPILE_NMEA

/** @addtogroup NMEA
  * @{
  */

/** @defgroup NMEA_PrivateVariables Private variables
  * @{
  */

__STATIC __PGPS_CMD __nmeaCommands = __NULL;

/**
  * @}
  */

/** @defgroup NMEA_PrivateFunctions Private Functions
  * @{
  */

/*!
 * @brief Returns a string pointer to the given field number.
 *
 * Use this function to retrieve a pointer to the first character of the given
 * \c field. \c field is the zero-based index of the field.
 *
 * Example:
 * @code
 * String=  $GPGSA,A,3,25,02,29,27,31,09,12,... *
 * Field=        0 1 2  3  4  5  6  7  8  9 N
 * @endcode
 *
 * @param line	Pointer to a zero-terminated string containing a complete NMEA sentence,
 * 				including checksum.
 * @param field	Zero-based index of the field number.
 * @param len	If not null, will contain the retrieved field length.
 *
 *
 * @return A pointer to the first character for the given field. If a '*' character or null is
 * detected the function returns zero.
 *
 */
__CONST __PSTRING __nmeaGetField(__CONST __PSTRING line, u8 field, u8* len)
{
	u8 count = 0;
	__CONST __PSTRING str = line;
	__PSTRING token;

	if (*str == '$') str++;

	while (*str)
	{
		/* Try with ',' */
		token = __strChr(str, ',');

		/* Not found, try with '*' */
		if (!token)
		{
			token = __strChr(str, '*');
			if (!token) return __NULL;
		}

		if (count == field)
		{
			if (len)
			{
				*len = (u8) (token - str);
			}

			return str;
		}

		str = ++token;
		count++;
	}

	return __NULL;
}

/*!
 * @brief Calculates a multiple of 1000 for a string representing an integer or fractional
 * number.
 *
 * For example, for the number "18,03" the return value will be 18030; for the number "18,003"
 * the value will be 18003; for the number "18,0003" the return value will be 18000.
 *
 * @param str	Pointer to a string containing an ASCII number.
 *
 * @return The value of the ASCII string multiplied by 1000.
 *
 */
__STATIC u32 __nmeaGetU32x1000(__CONST __PSTRING str)
{
	__PSTRING token;
	u32 ret = 0;
	u8 res = 100;

	/* Find decimal point */
	token = __strChr(str, '.');

	ret = __strToU32(str) * 1000;

	/* Decimal part? */
	if (token)
	{
		/* Multiply each number after the decimal point
		 * by 100, 10 and 1, respectively.
		 */
		token++;
		while (*token >= '0'&& *token <= '9' && res >= 1)
		{
			ret += (*token - '0') * res;
			res = (u8) (res / 10);
			token++;
		}
	}

	return ret;
}

/*!
 * @brief Calculates thousands of minutes from a degree.minute.dec string.
 *
 * To retrieve decimal degrees divide the returning value by 60000.
 *
 * @param str	Pointer to a string containing the coordinate.
 *
 * @return Thousands of minutes for the \c str parameter coordinate.
 *
 */
__STATIC i32 __nmeaGetThousandsOfMinutes(__CONST __PSTRING str)
{
	__PSTRING token;
	u32 deg = 0;
	u32 min = 0;
	u32 dec = 0;
	u8 res = 100;

	/* Find decimal point */
	token = __strChr(str, '.');
	if (!token) return 0;

	deg = __strToU32(str) / 100;
	min = (__strToU32(str) - (deg * 100));

	dec = (deg * 60000) + (min * 1000);

	token++;
	while (*token >= '0'&& *token <= '9' && res >= 1)
	{
		dec += (*token - '0') * res;
		res = (u8) (res / 10);
		token++;
	}

	return dec;
}

#if __NMEA_USE_RMC
/*!
 * @brief Parses a RMC sentence.
 *
 * This function fills the fields of an __NMEA_RMC structure.
 *
 * @param line	Pointer to a null-terminated string containing a complete
 * 				RMC sentence.
 * @param rmc	Pointer to a __NMEA_RMC data structure to be filled.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __nmeaParseRMC(__CONST __PSTRING line, __PNMEA_RMC rmc)
{
	__CONST __PSTRING str = line;
	u8 field = 1;
	u8 len = 0;

	do
	{
		str = __nmeaGetField(line, field, &len);
		if (str && len)
		{
			switch (field)
			{
				/* Time */
				case 1:
					rmc->time = __strToU32(str);
					break;

				/* Fix flag */
				case 2:
					rmc->status = *str;
					break;

				/* Latitude */
				case 3:
					rmc->lat = __nmeaGetThousandsOfMinutes(str);
					break;

				/* North/South */
				case 4:
					if (*str == 'N')
					{
						rmc->lat = +rmc->lat;
					} else if (*str == 'S')
					{
						rmc->lat = -rmc->lat;
					}
					break;

				/* Longitude */
				case 5:
					rmc->lon = __nmeaGetThousandsOfMinutes(str);
					break;

				/* East/West */
				case 6:
					if (*str == 'E')
					{
						rmc->lat = +rmc->lat;
					} else if (*str == 'W')
					{
						rmc->lat = -rmc->lat;
					}
					break;

				/* Speed */
				case 7:
					rmc->speed = __nmeaGetU32x1000(str);
					break;

				/* Heading */
				case 8:
					rmc->heading = __nmeaGetU32x1000(str);
					break;

				/* Date */
				case 9:
					rmc->date = __strToU32(str);
					break;

				/* Magnetic variation */
				case 10:
					rmc->magvar = __nmeaGetU32x1000(str);

					/* Last field, return */
					return;

			}
		}

		field++;

	} while (str);

}
#endif /* __NMEA_USE_RMC */

#ifdef __NMEA_USE_GGA
/*!
 * @brief Parses a GGA sentence.
 *
 * This function fills the fields of an __NMEA_GGA structure.
 *
 * @param line	Pointer to a null-terminated string containing a complete
 * 				GGA sentence.
 * @param gga	Pointer to a __NMEA_GGA data structure to be filled.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __nmeaParseGGA(__CONST __PSTRING line, __PNMEA_GGA gga)
{
	__CONST __PSTRING str = line;
	u8 field = 1;
	u8 len = 0;

	do
	{
		str = __nmeaGetField(line, field, &len);
		if (str && len)
		{
			switch (field)
			{
				/* Time */
				case 1:
					gga->time = __strToU32(str);
					break;

				/* Latitude */
				case 2:
					gga->lat = __nmeaGetThousandsOfMinutes(str);
					break;

				/* North/South */
				case 3:
					if (*str == 'N')
					{
						gga->lat = +gga->lat;
					} else if (*str == 'S')
					{
						gga->lat = -gga->lat;
					}
					break;

				/* Longitude */
				case 4:
					gga->lon = __nmeaGetThousandsOfMinutes(str);
					break;

				/* East/West */
				case 5:
					if (*str == 'E')
					{
						gga->lat = +gga->lat;
					} else if (*str == 'W')
					{
						gga->lat = -gga->lat;
					}
					break;

				/* Quality of fix */
				case 6:
					gga->quality = *str - 0x30;
					break;

				/* Satellites being tracked */
				case 7:
					gga->sats = (u8) __strToU32(str);
					break;

				/* Horizontal dilution of position */
				case 8:
					gga->hdop = __nmeaGetU32x1000(str);
					break;

				/* Altitude */
				case 9:
					gga->altitude = __strToI32(str);
					break;

				/*  Height above WGS84 ellipsoid */
				case 11:
					gga->geoid = __strToI32(str);

					/* Last field, return */
					return;
			}
		}
		field++;

	} while (str);
}
#endif /* __NMEA_USE_GGA */

#ifdef __NMEA_USE_GSV
/*!
 * @brief Parses a GSV sentence.
 *
 * This function fills the fields of an __NMEA_GSV structure.
 *
 * @param line	Pointer to a null-terminated string containing a complete
 * 				GSV sentence.
 * @param gsv	Pointer to a __NMEA_GSV data structure to be filled.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __nmeaParseGSV(__CONST __PSTRING line, __PNMEA_GSV gsv)
{
	__CONST __PSTRING str = line;
	u8 field = 1;
	u8 len = 0;
	u8 idx = 0;
	u8 satnum = 0;

	do
	{
		str = __nmeaGetField(line, field, &len);
		if (str && len)
		{
			switch (field)
			{
				/* Total messages */
				case 1:
					gsv->total_msgs = (u8) __strToU32(str);
					if (gsv->total_msgs > __NMEA_MAX_GSV) return;
					break;

				/* Message number */
				case 2:
					idx = (u8) __strToU32(str);
					if (!idx || idx > __NMEA_MAX_GSV) return;
					idx--;
					gsv->vtg_msg[idx].msg_num = idx + 1;
					break;

				/* Quantity of satellites in view */
				case 3:
					gsv->qty_sv = (u8) __strToU32(str);
					break;

				/* PRN number for the given satellite */
				case 16:
				case 12:
				case 8:
					satnum++;
				case 4:
					gsv->vtg_msg[idx].sv[satnum].prn = (u8) __strToU32(str);
					break;

				/* Elevation */
				case 17:
				case 13:
				case 9:
				case 5:
					gsv->vtg_msg[idx].sv[satnum].elevation = (u8) __strToU32(str);
					break;

				/* Azimut (degrees) */
				case 18:
				case 14:
				case 10:
				case 6:
					gsv->vtg_msg[idx].sv[satnum].azimut = (u8) __strToU32(str);
					break;

				/* SNR */
				case 19:
				case 15:
				case 11:
				case 7:
					gsv->vtg_msg[idx].sv[satnum].snr = (u8) __strToU32(str);
					break;

			}
		}

		field++;

	} while (str);

}
#endif /* __NMEA_USE_GSV */

#if __NMEA_USE_VTG
/*!
 * @brief Parses a VTG sentence.
 *
 * This function fills the fields of an __NMEA_VTG structure.
 *
 * @param line	Pointer to a null-terminated string containing a complete
 * 				VTG sentence.
 * @param vtg	Pointer to a __NMEA_VTG data structure to be filled.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __nmeaParseVTG(__CONST __PSTRING line, __PNMEA_VTG vtg)
{
	__CONST __PSTRING str = line;
	u8 field = 1;
	u8 len = 0;

	do
	{
		str = __nmeaGetField(line, field, &len);
		if (str && len)
		{
			switch (field)
			{
				/* Track made good (degrees) */
				case 1:
					vtg->track = __nmeaGetU32x1000(str);
					break;

				/* Ground speed (knots) */
				case 5:
					vtg->knots = __nmeaGetU32x1000(str);
					break;

				/* Ground speed, (Kilometers per hour) */
				case 7:
					vtg->kmh = __nmeaGetU32x1000(str);

					/* Last field, return */
					return;

			}
		}

		field++;
	} while (str);

}
#endif /* __NMEA_USE_VTG */

/**
  * @}
  */

/** @defgroup NMEA_Functions Functions
  * @{
  */

/*!
 * @brief NMEA checksum verification.
 *
 * @param line Null-terminated string containing a complete NMEA sentence.
 *
 * @return __TRUE if the checksum matches, __FALSE on checksum error.
 */
__BOOL __nmeaCheck(__CONST __PSTRING line)
{
	__CONST __PSTRING str = line;
	u8 chksum = 0;
	u8 calc = 0;

	/* Check for '$' */
	if (*str != '$') return __FALSE;

	str++;

	/* Calculate checksum while *str is not zero and not '*' */
	while (*str && *str != '*')
	{
		calc ^= *str++;
	}

	/* Check on string error */
	if (!(*str)) return __FALSE;

	/* Discard '*' character */
	str++;

	/* Get checksum low (from ASCII value) */
	if (*str >= '0' && *str <= '9')
	{
		chksum = (*str - 0x30) << 4;
	} else {
		chksum = (*str - 0x37) << 4;
	}

	/* Advance to the next checksum character */
	++str;

	/* Get checksum high (from ASCII value) */
	if (*str >= '0' && *str <= '9')
	{
		chksum |= (*str - 0x30);
	} else {
		chksum |= (*str - 0x37);
	}

	return (chksum == calc);
}


/*!
 * @brief Parses a NMEA sentence and fill the fields in the \c data structure.
 *
 * If the \c line passed is not of the type of a known sentence (i.e. has a matching
 * field in the \c data structure) it will be discarded.
 *
 * @param line 	Null-terminated string containing a complete NMEA sentence.
 * @param data	Pointer to a __GPS_DATA structure, to be filled with the sentence data.
 *
 * @return __TRUE if the line was successfully parsed, otherwise __FALSE.
 */
__BOOL __nmeaParseLine(__CONST __PSTRING line, __PGPS_DATA data)
{

	__CONST __PSTRING str = line;
	__PGPS_CMD list = __nmeaCommands;

	/* Check integrity */
	if (!__nmeaCheck(str)) {
		/* Checksum error */
		return __FALSE;
	}

	str = __nmeaGetField(line, 0, __NULL);

#if __NMEA_USE_RMC
	if (__strnCmpNoCase(str, "GPRMC", 5) == 0)
	{
		/*
		 * Parse RMC
		 */
		__nmeaParseRMC(line, &data->rmc);
		return __TRUE;
	}
#endif /* __NMEA_USE_RMC */

#if __NMEA_USE_GGA
	if (__strnCmpNoCase(str, "GPGGA", 5) == 0)
	{
		/*
		 * Parse GGS
		 */
		__nmeaParseGGA(line, &data->gga);
		return __TRUE;
	}
#endif /* __NMEA_USE_GGA */

#ifdef __NMEA_USE_GSV
	if (__strnCmpNoCase(str, "GPGSV", 5) == 0)
	{
		/*
		 * Parse GSV
		 */
		__nmeaParseGSV(line, &data->gsv);
		return __TRUE;

	}
#endif /* __NMEA_USE_GSV */

#ifdef __NMEA_USE_VTG
	if (__strnCmpNoCase(str, "GPVTG", 5) == 0)
	{
		/*
		 * Parse VTG
		 */
		__nmeaParseVTG(line, &data->vtg);
		return __TRUE;

	}
#endif /* __NMEA_USE_VTG */

	/*
	 * The sentence was not recognized by the parser.
	 * Check if there are registered commands by external parsers.
	 */
	while (list)
	{
		if (__strCmp(list->cmd, str))
		{
			if (list->fn)
			{
				(list->fn)(line);
				return __TRUE;
			}
		}

		list = list->next;
	}

	return __FALSE;
}

/*!
 * @brief Calculates the checksum for the given NMEA sentence.
 *
 * Useful when sending NMEA sentences.
 *
 * @param line Null-terminated string containing a complete NMEA sentence.
 *
 * @returns The calculated checksum.
 */
u8 __nmeaChecksum(__CONST __PSTRING line)
{
	__CONST __PSTRING str = line;
	u8 checksum = 0;

	if (!str) return 0;

	if (*str == '$') str++;

	while (*str && *str != '*')
	{
		checksum ^= *str++;
	}

	return checksum;
}

/*!
 * @brief Registers a function to parse a NMEA sentence this
 * parser do not.
 *
 * Fill a __GPS_CMD structure and pass it to this function to register a callback
 * function.
 *
 * The NMEA parser works only with RMC, GGA, GSV and VTG sentences. If there
 * are sentences that need to be parsed (like proprietary sentences for a given
 * GPS module manufacturer) the user may register a function to be called anytime
 * the \c cmd string from the __GPS_CMD structure is found.
 *
 * @param cmd Pointer to a __GPS_CMD structure.
 *
 * @return Nothing.
 */
__VOID __nmeaRegisterCommand(__PGPS_CMD cmd)
{
	__PGPS_CMD list = __nmeaCommands;
	__PGPS_CMD last = list;

	if (!__nmeaCommands)
	{
		__nmeaCommands = cmd;
		return;
	}

	while (list)
	{
		last = list;
		list = list->next;
	}

	last->next = cmd;
}

/*!
 * @brief Unregisters a command registered with the __nmeaRegisterCommand() function.
 *
 * @param cmd	Pointer to the structure containing the function to be unregistered.
 *
 * @return Nothing.
 */
__VOID __nmeaUnregisterCommand(__PGPS_CMD cmd)
{
	__PGPS_CMD list = __nmeaCommands;
	__PGPS_CMD last = __NULL;

	while (list)
	{
		if (list == cmd)
		{
			if (!last) {
				__nmeaCommands = __nmeaCommands->next;
				return;
			} else {
				last = list->next;
				return;
			}
		}
		last = list;
		list = list->next;
	}
}

/**
  * @}
  */

/**
  * @}
  */


#endif /* __CONFIG_COMPILE_NMEA */

