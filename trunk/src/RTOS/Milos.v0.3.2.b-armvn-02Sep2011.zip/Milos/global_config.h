/***************************************************************************
 * global_config.h
 * (C) 2010 Ivan Meleca
 * Based on original code written by Ruben Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef __GLOBAL_CONFIG_H__
#define __GLOBAL_CONFIG_H__

/* Include here your application configuration header.
 * An application can override any of these values by defining
 * them in a "private" file.
 */
/* #include <apps/dummy/dummy_config.h> */

#ifndef __CONFIG_TERMINAL_DEVICE
/*! @brief Terminal device */
#define __CONFIG_TERMINAL_DEVICE		__SERIAL_1
#endif

#ifndef __CONFIG_TERMINAL_BAUDRATE
/*! @brief Terminal baudrate, if using serial */
#define __CONFIG_TERMINAL_BAUDRATE		115200
#endif

#ifndef __CONFIG_TERMINAL_INCLUDES
/*! @brief Terminal device include */
#define __CONFIG_TERMINAL_INCLUDES		<drivers/serial/serial.h>
#endif



#ifndef __CONFIG_CALL_HEAP_DEFRAG
/*! @brief Call heap defrag periodically */
#define __CONFIG_CALL_HEAP_DEFRAG		0
#endif

#ifndef __CONFIG_HEAP_DEFRAG_TIME
/*! @brief Time in milliseconds to call heap defrag */
#define __CONFIG_HEAP_DEFRAG_TIME		30000
#endif

#ifndef __CONFIG_PRIO_SYSTHREAD
/*! @brief System thread priority */
#define __CONFIG_PRIO_SYSTHREAD			50
#endif

#ifndef __CONFIG_PRIO_TERMTHREAD
/*! @brief Terminal thread priority */
#define __CONFIG_PRIO_TERMTHREAD		100
#endif

#ifndef __CONFIG_PRIO_TIMTHREAD
/*! @brief Timer thread priority */
#define __CONFIG_PRIO_TIMTHREAD			100
#endif

#ifndef __CONFIG_STACK_TIMTHREAD
/*! @brief Timer thread stack size */
#define __CONFIG_STACK_TIMTHREAD		256
#endif

#ifndef __CONFIG_SYSTHREAD_SLEEP_TIME
/*! @brief The time in milliseconds the system thread should sleep */
#define __CONFIG_SYSTHREAD_SLEEP_TIME 	100
#endif

#ifndef __CONFIG_TERM_HIST_DEPTH
/*! @brief Terminal commands to keep in historic */
#define __CONFIG_TERM_HIST_DEPTH		3
#endif

#ifndef __CONFIG_TERM_LINE_LEN
/*! @brief Terminal maximum line length */
#define __CONFIG_TERM_LINE_LEN			128
#endif

#ifndef __CONFIG_TERM_MAX_SUBSCRIBERS
/*! @brief Terminal maximum quantity of subscriber threads */
#define __CONFIG_TERM_MAX_SUBSCRIBERS	3
#endif

#ifndef __CONFIG_COMPILE_STRING
/*! @brief OS uses strings module */
#define __CONFIG_COMPILE_STRING			1
#endif

#ifndef __CONFIG_TERMINAL_ENABLED
/*! @brief Compile-enable terminal module */
#define __CONFIG_TERMINAL_ENABLED		1
#endif

#ifndef __CONFIG_COMPILE_SERIAL
/*! @brief Compile serial driver */
#define __CONFIG_COMPILE_SERIAL			1
#endif
#if 0 //duc: Sep - 2 - 2011
#ifndef __CONFIG_COMPILE_SPI
/*! @brief Compile spi driver */
#define __CONFIG_COMPILE_SPI			0
#endif

#ifndef __CONFIG_COMPILE_SD
/*! @brief Compile SD driver */
#define __CONFIG_COMPILE_SD				0
#endif

#ifndef __CONFIG_COMPILE_FAT
/*! @brief Use Fat */
#define __CONFIG_COMPILE_FAT			0
#endif
#endif //duc: Sep - 2 - 2011
#ifndef __CONFIG_COMPILE_QUEUE
/*! @brief Compile @ref Queue module */
#define __CONFIG_COMPILE_QUEUE			0
#endif

#ifndef __CONFIG_COMPILE_NMEA
/*! @brief Compile NMEA parser */
#define __CONFIG_COMPILE_NMEA			1
#endif

#if 0 //duc: Sep - 2 - 2011
#ifndef __CONFIG_COMPILE_GPS
/*! @brief Compile GPS driver */
#define __CONFIG_COMPILE_GPS			1
#ifndef __CONFIG_COMPILE_NMEA
#error "GPS driver needs __CONFIG_COMPILE_NMEA"
#endif
#endif

#ifndef __CONFIG_COMPILE_CHARLCD
/*! @brief Character LCD Driver */
#define __CONFIG_COMPILE_CHARLCD		1
#endif
#endif //duc: Sep - 2 - 2011


#ifndef __CONFIG_POST_STACK_OVERFLOW
/*! @brief Post stack overflow enabled */
#define __CONFIG_POST_STACK_OVERFLOW	0
#endif

#ifndef __CONFIG_DEBUG_RR
/*! @brief If set to any value but zero, it will force
 * all the threads with the value defined below. */
#define __CONFIG_DEBUG_RR				0
#endif

#endif /* __GLOBAL_CONFIG_H__ */
