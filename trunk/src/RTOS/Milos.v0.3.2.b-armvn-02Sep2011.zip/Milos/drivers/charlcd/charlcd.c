/***************************************************************************
 * charlcd.c
 * (C) 2011 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "charlcd.h"
#include <core/heap.h>
#include <common/mem.h>

#if __CONFIG_COMPILE_CHARLCD

/** @addtogroup Driver
  * @{
  */

/** @defgroup CharLcd Character LCD
  * Character LCD
  * @{
  */

/** @defgroup CharLdc_PrivateMacros Private Macros
  * @{
  */

#define __charlcdPower(x) 			(dv->dv_plat_ioctl)(dv,	__CHARLCD_PLAT_SET_POWER, x, __NULL, 0, __NULL, 0)
#define __charlcdInitHW(x) 			(dv->dv_plat_ioctl)(dv,	__CHARLCD_PLAT_INIT_HW, 0, __NULL, 0, __NULL, 0)
#define __charlcdDeInitHW(x)		(dv->dv_plat_ioctl)(dv,	__CHARLCD_PLAT_DEINIT_HW, 0, __NULL, 0, __NULL, 0)
#define __charlcdWrite4(x, y) 		(dv->dv_plat_ioctl)(dv,	__CHARLCD_PLAT_WRITE_4, y, x, 0, __NULL, 0)
#define __charlcdWrite8(x, y) 		(dv->dv_plat_ioctl)(dv,	__CHARLCD_PLAT_WRITE_8, y, x, 0, __NULL, 0)
#define __charlcdGetStatus()		(dv->dv_plat_ioctl)(dv,	__CHARLCD_PLAT_GET_STATUS, 0, __NULL, 0, __NULL, 0)
#define __charlcdWriteCommand(x) 	{ while (__charlcdBusy(dv)); __charlcdWrite8(x, __CHARLCD_REGISTER); }
#define __charlcdWriteData(x) 		{ while (__charlcdBusy(dv)); __charlcdWrite8(x, __CHARLCD_DATA); }


/**
  * @}
  */

/** @defgroup CharLdc_PrivateFunctions Private Functions
  * @{
  */

/*!
 * @brief Get busy flag
 *
 * @param dv Pointer to device.
 *
 * @return __TRUE if the display is busy, otherwise __FALSE.
 *
 */
__STATIC __BOOL __charlcdBusy(__PDEVICE dv)
{
	__PCHARLCDPDB pd = dv->dv_pdb;
	if (pd->pd_flags & __CHARLCD_MODE_NO_BF) return __FALSE;

	return (__BOOL) __charlcdGetStatus() >> 7;
}

/*!
 * @brief Clears the screen.
 *
 * Clears the screen and resets the screen buffer.
 *
 * @param dv Pointer to device.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __charlcdClearScreen(__PDEVICE dv)
{
	__PCHARLCDPDB pd = dv->dv_pdb;
	u8 val = __CHARLCD_DISP_CLEAR;
	__charlcdWriteCommand(&val);
	__memSet(pd->pd_buf, 0x00, pd->pd_chars * pd->pd_lines);
}

/*!
 * @brief Scrolls up the screen buffer.
 *
 * @param pd Pointer to device pdb.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __charlcdScroll(__PCHARLCDPDB pd)
{
	/* Copy from line 1 */
	__memCpy(pd->pd_buf, &pd->pd_buf[pd->pd_chars], pd->pd_chars * (pd->pd_lines - 1));

	/* Clear last line */
	__memSet(&pd->pd_buf[pd->pd_chars * (pd->pd_lines - 1)], 0, pd->pd_chars);

	/* Set cursor to last line */
	pd->pd_cur_y = pd->pd_lines - 1;
}

/*!
 * @brief Sets the cursor at the givex x-y position.
 *
 * @param dv Pointer to device.
 * @param x	X position in characters (typically 0:15).
 * @param y Y position in characters (typically 0:1).
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __charlcdSetCursor(__PDEVICE dv, u16 x, u16 y)
{
	u8 val = __CHARLCD_SET_DD_RAM_ADDR | (x + (y * 0x40));
	__charlcdWriteCommand(&val);
}

/*!
 * @brief Outputs a character to the screen.
 *
 * @param dv Pointer to device.
 * @param c	Character.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __charlcdPutCh(__PDEVICE dv, u8 c)
{
	__charlcdWriteData(&c);
}

/*!
 * @brief Clears and redraws the entire screen.
 *
 * The screen is redrawn based on the contents of the screen buffer.
 *
 * @param dv Pointer to device.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __charlcdRedraw(__PDEVICE dv)
{
	u16 x = 0;
	u16 y = 0;
	u8 val = 0;
	u16 count = 0;
	__PCHARLCDPDB pd = dv->dv_pdb;

	val = __CHARLCD_DISP_CLEAR;
	__charlcdWriteCommand(&val);
	__charlcdSetCursor(dv, 0, 0);

	/* For each character in buffer */
	while (count < (pd->pd_lines * pd->pd_chars))
	{
		/* If X goes beyond line length or if the character is null */
		if (x >= pd->pd_chars || *(pd->pd_buf + count) == 0)
		{
			/* Advance to the next line */
			y++;

			/* If Y is bigger than lcd lines then return */
			if (y >= pd->pd_lines) return;

			/* Reset X */
			x = 0;

			/* Set cursor */
			__charlcdSetCursor(dv, x, y);

			/* Adjust count value */
			count = pd->pd_chars * y;
		} else {

			/* Write char */
			__charlcdPutCh(dv, *(pd->pd_buf + count));
			count++;

		}
	}
}

/**
  * @}
  */

/** @defgroup CharLcd_Functions Functions
  * @{
  */

/*!
 * @brief Initialization.
 *
 * Called from __deviceRegister() to initialize the Char LCD driver.
 *
 * @param	dv			Pointer to a Character LCD device structure.
 * @param 	param1		Quantity of characters per line.
 * @param 	param2		Quantity of lines.
 * @param	mode		Not used.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __charlcdInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode)
{
	__PCHARLCDPDB pd = dv->dv_pdb;

	pd->pd_chars = param1;
	pd->pd_lines = param2;
	pd->pd_cur_x = pd->pd_cur_y = 0;

	pd->pd_buf = __heapAlloc(pd->pd_chars * pd->pd_lines);
	if (!pd->pd_buf) return __DEV_ERROR;

	return __DEV_OK;
}

/*!
 * @brief Char LCD driver destroy.
 *
 * Called from __deviceUnregister().
 *
 * @param	dv	Pointer to a Character LCD device structure.
 * @return		__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __charlcdDestroy(__PDEVICE dv)
{
	__PCHARLCDPDB pd = dv->dv_pdb;

	if (dv->dv_opcnt)
	{
		__charlcdClose(dv);
	}

	if (pd->pd_buf) __heapFree(pd->pd_buf);
	return __DEV_OK;
}

/*!
 * @brief Device Input/Output control function.
 *
 * Called from __deviceIOCtl(). The __IOCTL_SET_LINE and __IOCTL_SET_COLUMN commands are available only
 * if the driver is opened without __CHARLCD_MODE_SCROLL flag. See __charlcdOpen().
 *
 * @param	dv			Pointer to a Character LCD device structure.
 * @param 	cmd			Command code to execute. Can be any of these values:
 * @arg __IOCTL_SET_LINE Sets the cursor at the given line (one-based value taken from \c param parameter).
 * @arg __IOCTL_SET_COLUMN Sets the cursor at the given column (one-based value taken from \c param parameter).
 * @arg	__IOCTL_CLEAR_LINE Erases a line (one-based value line number taken from \c param parameter).
 * @arg __IOCTL_CLEAR_SCREEN Clears the screen. Has the same effect as calling __charlcdWrite() with __NULL data.
 * @param	param		Input parameter.
 * @param	data		Optional data pointer.
 * @param	len			\c data length.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR or __DEV_UNK_IOCTL if the
 * 						\c cmd IO control code is not implemented.
 */
i32 __charlcdIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len)
{

	__PCHARLCDPDB pd = dv->dv_pdb;

	switch (cmd)
	{
		case __IOCTL_SET_LINE:
			if (!param || param > pd->pd_lines || pd->pd_mode & __CHARLCD_MODE_SCROLL)
				return __DEV_ERROR;

			pd->pd_cur_y = param - 1;

			/* Move cursor */
			__charlcdSetCursor(dv, pd->pd_cur_x, pd->pd_cur_y);
			return __DEV_OK;

		case __IOCTL_SET_COLUMN:
			if (!param || param > pd->pd_lines || pd->pd_mode & __CHARLCD_MODE_SCROLL)
				return __DEV_ERROR;

			pd->pd_cur_x = param - 1;

			/* Move cursor */
			__charlcdSetCursor(dv, pd->pd_cur_x, pd->pd_cur_y);
			return __DEV_OK;

		case __IOCTL_CLEAR_LINE:
			if (!param || param > pd->pd_lines) return __DEV_ERROR;
			__memSet(&pd->pd_buf[(param - 1) * pd->pd_chars], 0, pd->pd_chars);
			__charlcdRedraw(dv);
			return __DEV_OK;

		case __IOCTL_CLEAR_SCREEN:
			return __charlcdWrite(dv, __NULL, 0);
	}

	return __DEV_UNK_IOCTL;
}

/*!
 * @brief Char LCD device driver open function.
 *
 * Called from __deviceOpen() to open the Character LCD driver.
 *
 * @param	dv			Pointer to a Character LCD device structure.
 * @param 	mode		Open modes. A combination of these values:
 * @arg __CHARLCD_MODE_4_BITS Opens the driver in 4-bits mode.
 * @arg __CHARLCD_MODE_8_BITS Opens the driver in 8-bits mode.
 * @arg __CHARLCD_MODE_SCROLL Automatically scrolls up the screen when a new line is detected.
 * IO control values __IOCTL_SET_LINE and __IOCTL_SET_COLUMN do not work when this mode is enabled.
 * @arg __CHARLCD_MODE_CURSOR Sets a visible and blinking cursor.
 * @arg __CHARLCD_MODE_NO_BF Do not check Busy Flag.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 */
i32 __charlcdOpen(__PDEVICE dv, u8 mode)
{
	__PCHARLCDPDB pd = dv->dv_pdb;
	u8 val;
	pd->pd_mode = mode;

	/* Custom platform hardware initialization */
	__charlcdInitHW();

	__charlcdPower(1);

	__cpuDelayMs(50);

	/* If 8-bit mode */
	if (pd->pd_mode & __CHARLCD_MODE_8_BITS)
	{
		/* Send standard commands */
		val = __CHARLCD_SET_FUNC | __CHARLCD_8_BITS;
		__charlcdWrite8(&val, __CHARLCD_REGISTER);
		__cpuDelayMs(5);
		__charlcdWrite8(&val, __CHARLCD_REGISTER);
		__cpuDelayMs(5);
		__charlcdWrite8(&val, __CHARLCD_REGISTER);
		__cpuDelayMs(5);
	} else
	{
		/* Send initialization commands */
		val = 0x03;
		__charlcdWrite4(&val, __CHARLCD_REGISTER);
		__cpuDelayMs(5);
		__charlcdWrite4(&val, __CHARLCD_REGISTER);
		__cpuDelayMs(5);
		__charlcdWrite4(&val, __CHARLCD_REGISTER);
		__cpuDelayMs(5);

		val = 0x02;
		__charlcdWrite4(&val, __CHARLCD_REGISTER);
		__cpuDelayMs(5);

		val = __CHARLCD_SET_FUNC;

	}

	if (pd->pd_lines == 2) val |= __CHARLCD_2_LINES;
	__charlcdWriteCommand(&val);

	val = __CHARLCD_DISP_ON_FF | __CHARLCD_DIPLAY_ON;
	if (mode & __CHARLCD_MODE_CURSOR)
	{
		 val |= __CHARLCD_CURSOR_ON | __CHARLCD_BLINK_ON;
	}
	__charlcdWriteCommand(&val);

	val = __CHARLCD_DISP_CLEAR;
	__charlcdWriteCommand(&val);

	val = __CHARLCD_ENTRY_MODE | __CHARLCD_CURSOR_INCREASE;
	__charlcdWriteCommand(&val);

	pd->pd_cur_x = pd->pd_cur_y = 0;

	return __DEV_OK;
}

/*!
 * @brief Char LCD driver close function.
 *
 * Called from __deviceClose() to close the Character LCD driver.
 *
 * @param	dv			Pointer to a Character LCD device structure.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __charlcdClose(__PDEVICE dv)
{
	__charlcdPower(0);
	__charlcdDeInitHW();
	return __DEV_OK;
}

/*!
 * @brief Returns the count of the Character LCD buffer size.
 *
 * Called from __deviceSize().
 *
 * @param	dv				Pointer to a device.
 * @param 	mode			Parameter defining on which buffer operate. Not used.
 * @return					The Character LCD screen buffer size.
 *
 */
i32 __charlcdSize(__PDEVICE dv, u8 mode)
{
	__PCHARLCDPDB pd = dv->dv_pdb;
	return (pd->pd_chars * pd->pd_lines);
}

/*!
 * @brief Character LCD driver flush function.
 *
 * Not used for the Character LCD driver.
 *
 * @param	dv		Pointer to a device.
 * @return			__DEV_OK on success, __DEV_TIMEOUT on timeout.
 *
 */
i32 __charlcdFlush(__PDEVICE dv)
{
	return __DEV_OK;
}

/*!
 * @brief Character LCD driver read function.
 *
 * Copies the screen buffer into the \c buf buffer.
 *
 * @param	dv			Pointer to a device.
 * @param 	buf			Pointer to a buffer to receive the data.
 * @param	qty			Quantity of bytes to read.
 * @return				Quantity of bytes read.
 *
 */
i32 __charlcdRead(__PDEVICE dv, __PVOID buf, u16 qty)
{
	__PCHARLCDPDB pd = dv->dv_pdb;

	if (qty > pd->pd_chars * pd->pd_lines) qty = pd->pd_chars * pd->pd_lines;

	__memCpy(buf, pd->pd_buf, qty);

	return qty;
}

/*!
 * @brief Character LCD driver write function.
 *
 * Writes to the screen.
 *
 * @param	dv			Pointer to a device.
 * @param 	buf			Pointer to a buffer. Maximum length is the quantity of characters per line defined
 *						when registering the device. If __NULL, the screen is erased.
 * @param	qty			Quantity of data to send, in bytes.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 */
i32 __charlcdWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty)
{
	__PCHARLCDPDB pd = dv->dv_pdb;
	u16 i;
	u32 pos;
	__BOOL redraw = __FALSE;
	__PSTRING str = (__PSTRING) buf;

	/* Check size */
	if (qty > (pd->pd_chars * pd->pd_lines))
		return __DEV_ERROR;

	/* If buf is null, it means 'clear screen' */
	if (!buf)
	{
		/* Clear screen */
		__charlcdClearScreen(dv);
		pd->pd_cur_x = pd->pd_cur_y = 0;

		/* Move cursor */
		__charlcdSetCursor(dv, pd->pd_cur_x, pd->pd_cur_y);

		return __DEV_OK;
	}

	/* Scan all characters */
	for (i = 0; i < qty; i++)
	{
		/* Is CR? */
		if (*(str+i) == '\r')
		{
			/* Carriage return */
			pd->pd_cur_x = 0;

			/* Move cursor */
			if (!redraw) __charlcdSetCursor(dv, pd->pd_cur_x, pd->pd_cur_y);

		} else if (*(str+i) == '\n')
		{
			/* Line feed */
			if (pd->pd_mode & __CHARLCD_MODE_SCROLL)
			{
				/* Scroll only when we're writing in the last line */
				if (pd->pd_cur_y == pd->pd_lines - 1)
				{
					__charlcdScroll(pd);
					redraw = __TRUE;
				} else {
					pd->pd_cur_y++;
				}

			} else {
				/* Line feed, go to the next line */
				if (pd->pd_cur_y == pd->pd_lines - 1) return qty;
				pd->pd_cur_x = 0;
				pd->pd_cur_y++;
			}

			/* Move cursor */
			if (!redraw) __charlcdSetCursor(dv, pd->pd_cur_x, pd->pd_cur_y);

		} else {
			/* Normal character, check if going beyond the chars limits. */
			if (pd->pd_cur_x >= pd->pd_chars)
			{
				/* Beyond permitted chars quantity */
				pd->pd_cur_x = 0;

				/* on the last line? */
				if (pd->pd_cur_y == pd->pd_lines - 1)
				{
					/* If set as scroll */
					if (pd->pd_mode & __CHARLCD_MODE_SCROLL)
					{
						/* scroll, and flag redraw */
						__charlcdScroll(pd);
						redraw = __TRUE;
					} else {
						/* Last line and no-scroll mode, return error */
						return i;
					}
				} else {
					/* Go to next line */
					if (pd->pd_cur_y == pd->pd_lines - 1) return __DEV_OK;
					pd->pd_cur_y++;
				}

				/* Move cursor */
				if (!redraw) __charlcdSetCursor(dv, pd->pd_cur_x, pd->pd_cur_y);
			}

			/* Buffer the character */
			pos = (pd->pd_cur_y * pd->pd_chars) + pd->pd_cur_x;
			pd->pd_buf[pos] = *(str + i);
			pd->pd_cur_x++;

			/* If we're not redrawing the entire screen, put the char */
			if (!redraw) {
				__charlcdPutCh(dv, pd->pd_buf[pos]);
			}
		}
	}

	/* Redraw all? */
	if (redraw)
	{
		__charlcdRedraw(dv);
	}

	return qty;
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif /* __CONFIG_COMPILE_CHARLCD__ */
