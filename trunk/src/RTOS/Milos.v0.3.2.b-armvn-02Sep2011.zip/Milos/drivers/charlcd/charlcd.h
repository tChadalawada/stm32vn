/***************************************************************************
 * charlcd.h
 * (C) 2011 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef	__CHARLCD_H__
#define	__CHARLCD_H__

#include <plat_cpu.h>
#include <plat_charlcd.h>
#include <core/device.h>

/** @addtogroup Driver
  * @{
  */

/** @addtogroup CharLcd
  * @{
  */

/** @defgroup CharLcd_Constants	Constants
  * @{
  */

/** @defgroup CharLcd_OpenMode Open modes
  * @{
  */

#define __CHARLCD_MODE_4_BITS		0x00
#define __CHARLCD_MODE_8_BITS		0x01
#define __CHARLCD_MODE_SCROLL		0x02
#define __CHARLCD_MODE_CURSOR		0x04
#define __CHARLCD_MODE_NO_BF		0x08

/**
  * @}
  */

/** @defgroup CharLcd_PlatIoCtlCodesDefines Platform IOCTLs
  * @{
  */

#define __CHARLCD_PLAT_INIT_HW		1
#define __CHARLCD_PLAT_DEINIT_HW	2
#define __CHARLCD_PLAT_SET_POWER	3
#define __CHARLCD_PLAT_WRITE_4		4
#define __CHARLCD_PLAT_WRITE_8		5
#define __CHARLCD_PLAT_GET_STATUS	6

/**
  * @}
  */

/** @defgroup CharLcd_Commands Commands
  * @{
  */

#define __CHARLCD_DISP_CLEAR		0x01
#define __CHARLCD_MOVE_CURSOR		0x02
#define __CHARLCD_ENTRY_MODE		0x04
#define __CHARLCD_DISP_ON_FF		0x08
#define __CHARLCD_SET_FUNC			0x20
#define __CHARLCD_SET_CG_RAM_ADDR	0x40
#define __CHARLCD_SET_DD_RAM_ADDR	0x80

/* Entry mode parameters */
#define __CHARLCD_CURSOR_INCREASE	0x02
#define __CHARLCD_DISPLAY_SHIFTED	0x01

/* Display on/off parameters */
#define __CHARLCD_DIPLAY_ON			0x04
#define __CHARLCD_CURSOR_ON			0x02
#define __CHARLCD_BLINK_ON			0x01

/* Set function parameters */
#define __CHARLCD_8_BITS			0x10
#define __CHARLCD_2_LINES			0x08
#define __CHARLCD_5X10_DOTS			0x04

/**
  * @}
  */

/** @defgroup CharLcd_TransmissionType Tx types
  * @{
  */

#define __CHARLCD_DATA				0x00
#define __CHARLCD_REGISTER			0x01

/**
  * @}
  */

/**
  * @}
  */

/** @defgroup CharLcd_Typedefs	Typedefs
  * @{
  */

typedef struct __charlcdPdb {

	u16			pd_chars;
	u16			pd_lines;
	u16			pd_cur_x;
	u16			pd_cur_y;
	u8			pd_flags;
	u8			pd_mode;
	__PSTRING	pd_buf;

} __CHARLCDPDB, *__PCHARLCDPDB;

/**
  * @}
  */

i32 __charlcdInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode);
i32 __charlcdDestroy(__PDEVICE dv);
i32 __charlcdIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len);
i32 __charlcdOpen(__PDEVICE dv, u8 mode);
i32 __charlcdClose(__PDEVICE dv);
i32 __charlcdSize(__PDEVICE dv, u8 mode);
i32 __charlcdFlush(__PDEVICE dv);
i32 __charlcdRead(__PDEVICE dv, __PVOID buf, u16 qty);
i32 __charlcdWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty);

/**
  * @}
  */


/**
  * @}
  */

#endif /* __CHARLCD_H__ */
