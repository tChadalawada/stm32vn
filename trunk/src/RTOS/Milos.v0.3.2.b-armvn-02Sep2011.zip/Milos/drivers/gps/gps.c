/***************************************************************************
 * gps.c
 * (C) 2011 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "gps.h"
#include <core/thread.h>
#include <core/system.h>
#include <core/heap.h>
#include <common/nmea.h>
#include <common/mem.h>
#include <core/terminal.h>

#ifdef __CONFIG_COMPILE_GPS

/** @addtogroup Driver
  * @{
  */

/** @defgroup GPS GPS
  * GPS driver.
  * @{
  */

/** @defgroup GPS_PrivateFunctions Private functions
  * @{
  */


/*!
 * @brief Thread for reading from the underlying GPS device.
 *
 * @return Nothing.
 */
__STATIC __VOID __gpsThread(__VOID)
{
	__PDEVICE dv = __threadGetParameter();
	__PGPS_PDB pd = dv->dv_pdb;
	__BOOL res;

	for (;;)
	{
		/* Read a line of text */
		while (__deviceReadLine(pd->pd_dv, pd->pd_buf, __GPS_MAX_LINE_LEN) != __DEV_ERROR)
		{
			/* Lock, we are about to write in the possibly (shared) pd_data structure */
			if (__lockOwn(pd->pd_lock, 1000))
			{
				/* Parse the read line with the NMEA parser */
				res = __nmeaParseLine(pd->pd_buf, &pd->pd_data);

				/* Release the lock */
				__lockRelease(pd->pd_lock);

				/* If the sentence is OK, output to terminal */
				if (res) {
					DBGMSG(pd->pd_terminal, (pd->pd_buf));
				} else {
					DBGMSG(pd->pd_terminal, ("GPS checksum error"));
				}
			}
		}

		/* Give up the remaining time-to-live */
		__threadYield();
	}
}

/**
  * @}
  */

/** @defgroup GPS_Functions Functions
  * @{
  */

/*!
 * @brief Initialization.
 *
 * Called from __deviceRegister() to initialize the GPS driver.
 *
 * @param	dv			Pointer to a GPS device structure.
 * @param 	param1		Not used.
 * @param 	param2		Not used.
 * @param	mode		Not used.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __gpsInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode)
{
	__PGPS_PDB pd = dv->dv_pdb;
	u16 mode_flags = 0;

	/* Check for initialized */
	if (dv->dv_rgcnt > 0) return __DEV_ERROR;

	/* Alloc buffer for reception */
	pd->pd_buf = __heapAllocZero(__GPS_MAX_LINE_LEN);
	if (!pd->pd_buf) return __DEV_ERROR;

	/* Create a lock to protect pd->pd_data */
	pd->pd_lock = __lockCreate();
	if (!pd->pd_lock)
	{
		__heapFree(pd->pd_buf);
		return __DEV_ERROR;
	}

	/* Initialize underlying driver */
	mode_flags = __DEV_RD_CRLF | __DEV_WR_CRLF | __DEV_AUTOFLUSH;

	if (__deviceRegister(pd->pd_dv, __GPS_MAX_LINE_LEN, 0, mode_flags) != __DEV_OK)
	{
		__heapFree(pd->pd_buf);
		return __DEV_ERROR;
	}

	/*	Init hardware */
	if (dv->dv_plat_ioctl)
		(dv->dv_plat_ioctl)(dv,	__GPS_PLAT_INIT_HW, 0, __NULL, 0, __NULL, 0);

	/* Create a thread for gps reception (if not already created) */
	if (!pd->pd_thread)
	{
		pd->pd_thread = __threadCreate("gps", __gpsThread, 150, 256, 10, dv);
		if (!pd->pd_thread) {
			__deviceUnregister(pd->pd_dv);
			__heapFree(pd->pd_buf);
			__lockDestroy(pd->pd_lock);
			return __DEV_ERROR;
		}
	}

	return __DEV_OK;
}

/*!
 * @brief GPS driver destroy.
 *
 * Called from __deviceUnregister().
 *
 * @param	dv	Pointer to a GPS device structure.
 * @return		__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __gpsDestroy(__PDEVICE dv)
{
	__PGPS_PDB pd = dv->dv_pdb;

	/* Check for still opened */
	if (dv->dv_opcnt != 0) return __DEV_ERROR;

	/* Unregister underlying driver */
	__deviceUnregister(pd->pd_dv);

	/* Destroy lock */
	__lockDestroy(pd->pd_lock);

	/* Free buffers */
	__heapFree(pd->pd_buf);

	/*	De-init hardware */
	if (dv->dv_plat_ioctl)
		(dv->dv_plat_ioctl)(dv,	__GPS_PLAT_DEINIT_HW,	0, __NULL, 0, __NULL, 0);

	return __DEV_OK;
}

/*!
 * @brief Device Input/Output control function.
 *
 * Called from __deviceIOCtl().
 *
 * @param	dv			Pointer to a GPS device structure.
 * @param 	cmd			Command code to execute.
 * @param	param		Input parameter.
 * @param	data		Optional data pointer.
 * @param	len			\c data length.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR or __DEV_UNK_IOCTL if the
 * 						\c cmd IO control code is not implemented.
 */
i32 __gpsIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len)
{
	__PGPS_PDB pd = dv->dv_pdb;

	switch (cmd)
	{
		case __IOCTL_GET_POWER_STATUS:
			if (dv->dv_plat_ioctl)
				return (dv->dv_plat_ioctl)(dv, __GPS_PLAT_GET_POWER, 0, __NULL, 0, __NULL, 0);
			break;

		case __IOCTL_SET_POWER_STATUS:
			if (dv->dv_plat_ioctl)
				return (dv->dv_plat_ioctl)(dv, __GPS_PLAT_SET_POWER, (u8) param, __NULL, 0, __NULL, 0);
			break;

		case __IOCTL_GET_FIX_FLAG:
			if (dv->dv_plat_ioctl)
				return (dv->dv_plat_ioctl)(dv, __GPS_PLAT_GET_FIX_FLAG, 0, __NULL, 0, __NULL, 0);
			break;

		case __IOCTL_TERMINAL_OUTPUT:
			pd->pd_terminal = (u8) param;
			break;
	}

	return __DEV_UNK_IOCTL;
}

/*!
 * @brief GPS device driver open function.
 *
 * Called from __deviceOpen() to open the GPS driver.
 *
 * @param	dv			Pointer to a GPS device structure.
 * @param 	mode		Open modes, not used.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 */
i32 __gpsOpen(__PDEVICE dv, u8 mode)
{
	__PGPS_PDB pd = dv->dv_pdb;

	/* Open underlying device */
	if (__deviceOpen(pd->pd_dv, 0) == __DEV_OK)
	{
		/* Set baudrate and timeouts */
		__deviceIOCtl(pd->pd_dv, __IOCTL_SETBAUD, pd->pd_dvspeed, __NULL, 0);
		__deviceIOCtl(pd->pd_dv, __IOCTL_SETTXTIMEOUT, 1000, __NULL, 0);
		__deviceIOCtl(pd->pd_dv, __IOCTL_SETRXTIMEOUT, 1000, __NULL, 0);

		/*	Power on GPS */
		if (dv->dv_plat_ioctl)
			(dv->dv_plat_ioctl)(dv,	__GPS_PLAT_SET_POWER, 1, __NULL, 0, __NULL, 0);

		return __DEV_OK;
	}

	return __DEV_ERROR;
}

/*!
 * @brief GPS driver close function.
 *
 * Called from __deviceClose() to close the GPS driver.
 *
 * @param	dv			Pointer to a GPS device structure.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __gpsClose(__PDEVICE dv)
{
	__PGPS_PDB pd = dv->dv_pdb;

	/* Close underlying device */
	__deviceClose(pd->pd_dv);

	return __DEV_OK;
}

/*!
 * @brief Returns the count of the GPS unsent/unread bytes.
 *
 * Called from __deviceSize(). This functions is not used.
 *
 * @param	dv				Pointer to a device.
 * @param 	mode			Parameter defining on which buffer operate.
 * @return					The GPS unsent/unread bytes. __DEV_ERROR on error.
 *
 */
i32 __gpsSize(__PDEVICE dv, u8 mode)
{
	return __DEV_OK;
}

/*!
 * @brief GPS driver flush function.
 *
 * Flush the GPS underlying driver.
 *
 * @param	dv		Pointer to a device.
 * @return			__DEV_OK on success, __DEV_TIMEOUT on timeout.
 *
 */
i32 __gpsFlush(__PDEVICE dv)
{
	__PGPS_PDB pd = dv->dv_pdb;

	return __deviceFlush(pd->pd_dv);
}

/*!
 * @brief GPS driver read function.
 *
 * Read the complete __GPS_DATA structure.
 * When calling __deviceRead(), pass a pointer to __GPS_DATA as the \c buf parameter,
 * and set \c qty to sizeof(__GPS_DATA).
 *
 * @param	dv			Pointer to a device.
 * @param 	buf			Pointer to a buffer to receive the data (a pointer to a __GPS_DATA structure).
 * @param	qty			The size of the __GPS_DATA structure passed.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __gpsRead(__PDEVICE dv, __PVOID buf, u16 qty)
{
	__PGPS_PDB pd = dv->dv_pdb;

	if (qty != sizeof(__GPS_DATA) || !buf) return __DEV_ERROR;

	if (__lockOwn(pd->pd_lock, 1500))
	{
		__memCpy(buf, &pd->pd_data, sizeof(__GPS_DATA));
		__lockRelease(pd->pd_lock);

		return __DEV_OK;
	}

	return __DEV_ERROR;
}

/*!
 * @brief GPS driver write function.
 *
 * Call this function send data to the GPS underlying driver.
 *
 * @param	dv			Pointer to a device.
 * @param 	buf			Pointer to a buffer.
 * @param	qty			Quantity of data to send, in bytes.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 */
i32 __gpsWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty)
{
	__PGPS_PDB pd = dv->dv_pdb;

	return __deviceWrite(pd->pd_dv, buf, qty);
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif /* __CONFIG_COMPILE_GPS */


