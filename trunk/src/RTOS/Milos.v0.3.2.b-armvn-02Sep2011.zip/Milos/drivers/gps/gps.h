/***************************************************************************
 * gps.h
 * (C) 2011 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include <core/device.h>
#include <core/lock.h>
#include <common/nmea.h>
#include <plat_gps.h>

/** @addtogroup Driver
  * @{
  */

/** @addtogroup GPS
  * @{
  */

/** @defgroup GPS_Constants	Constants
  * @{
  */

#define __GPS_MAX_LINE_LEN 0xFF

/** @defgroup GPS_PlatIoCtlCodesDefines Platform IOCTLs
  * @{
  */

#define __GPS_PLAT_INIT_HW			1
#define __GPS_PLAT_DEINIT_HW		2
#define __GPS_PLAT_SET_POWER		3
#define __GPS_PLAT_GET_POWER		4
#define __GPS_PLAT_GET_FIX_FLAG		5

/**
  * @}
  */

/**
  * @}
  */

/** @defgroup GPS_Typedefs	Typedefs
  * @{
  */

typedef struct __gpsPdbTag
{
	__PDEVICE 	pd_dv;
	u32			pd_dvspeed;
	__PSTRING	pd_buf;
	__PTHREAD	pd_thread;
	__GPS_DATA	pd_data;
	__PLOCK		pd_lock;
	u8			pd_terminal;
} __GPS_PDB, * __PGPS_PDB;

/**
  * @}
  */

i32 __gpsInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode);
i32 __gpsDestroy(__PDEVICE dv);
i32 __gpsIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len);
i32 __gpsOpen(__PDEVICE dv, u8 mode);
i32 __gpsClose(__PDEVICE dv);
i32 __gpsSize(__PDEVICE dv, u8 mode);
i32 __gpsFlush(__PDEVICE dv);
i32 __gpsRead(__PDEVICE dv, __PVOID buf, u16 qty);
i32 __gpsWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty);


/**
  * @}
  */


/**
  * @}
  */

