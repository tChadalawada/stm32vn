/***************************************************************************
 * SD.h
 * (C) 2010 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef	__SD_H__
#define	__SD_H__

#include <core/system.h>
#include <core/intrvect.h>
#include <core/device.h>
#include <core/lock.h>
#include <plat_sd.h>

/** @addtogroup Driver
  * @{
  */

/** @addtogroup SD SD
  * @{
  */

/** @defgroup SD_Constants Constants
  * @{
  */
  
#define __SD_BUFFER_SIZE			600

#define __SD_FLAG_CARD_INSERTED		0x01 /*!< @brief Card inserted */
#define __SD_FLAG_WRITE_PROTECT		0x02 /*!< @brief Write protect enabled */


#define	__SD_MINRXBUFLEN		32		/*!< @brief Min RX buffer length */
#define	__SD_MINTXBUFLEN		32		/*!< @brief Min TX buffer length */

/** @defgroup SD_PlatIoCtlCodesDefines Platform IOCTLs
  * @{
  */

#define __SD_PLAT_INIT_HW			1
#define __SD_PLAT_GET_CD			2
#define __SD_PLAT_GET_WP			3
#define __SD_PLAT_SET_POWER			4

/**
  * @}
  */

/** @defgroup SD_CommandDefines Commands
  * @{
  */

#define __SD_CMD0	(0x40+0)	/* GO_IDLE_STATE */
#define __SD_CMD1	(0x40+1)	/* SEND_OP_COND (MMC) */
#define __SD_ACMD41	(0xC0+41)	/* SEND_OP_COND (SDC) */
#define __SD_CMD8	(0x40+8)	/* SEND_IF_COND */
#define __SD_CMD9	(0x40+9)	/* SEND_CSD */
#define __SD_CMD10	(0x40+10)	/* SEND_CID */
#define __SD_CMD12	(0x40+12)	/* STOP_TRANSMISSION */
#define __SD_ACMD13	(0xC0+13)	/* SD_STATUS (SDC) */
#define __SD_CMD16	(0x40+16)	/* SET_BLOCKLEN */
#define __SD_CMD17	(0x40+17)	/* READ_SINGLE_BLOCK */
#define __SD_CMD18	(0x40+18)	/* READ_MULTIPLE_BLOCK */
#define __SD_CMD23	(0x40+23)	/* SET_BLOCK_COUNT (MMC) */
#define __SD_ACMD23	(0xC0+23)	/* SET_WR_BLK_ERASE_COUNT (SDC) */
#define __SD_CMD24	(0x40+24)	/* WRITE_BLOCK */
#define __SD_CMD25	(0x40+25)	/* WRITE_MULTIPLE_BLOCK */
#define __SD_CMD55	(0x40+55)	/* APP_CMD */
#define __SD_CMD58	(0x40+58)	/* READ_OCR */

/**
  * @}
  */

/** @defgroup SD_CardTypeDefines Card types
  * @{
  */
#define __SD_CT_MMC              0x01
#define __SD_CT_SD1              0x02
#define __SD_CT_SD2              0x04
#define __SD_CT_SDC              (__SD_CT_SD1|__SD_CT_SD2)
#define __SD_CT_BLOCK            0x08

/**
  * @}
  */


/**
  * @}
  */

/** @defgroup SD_TypeDefs Typedefs
  * @{
  */

/*!
 * @brief __SD private data block.
 *
 * TODO Fill the required fields before registering
 * the device.
 */
typedef struct	__sdpdbTag {

	__PDEVICE		pd_dv;				/*!< @brief Accessing SD through this device */
	u8				pd_dv_mode;			/*!< @brief SD device mode (for __deviceRegister()) */
	__PTHREAD		pd_th;				/*!< @brief SD thread pointer (created at __deviceRegister()) */
	__PVOID			pd_params;			/*!< @brief Hardware parameters */
	__VOLATILE u8	pd_flags;			/*!< @brief Operation flags */
	u8*				pd_buf;				/*!< @brief Tx/Rx buffer */
	__PLOCK			pd_lock;			/*!< @brief Lock to access the underlying device */
	u8				pd_ct;				/*!< @brief Card type */
	u32				pd_sector;			/*!< @brief Sector number for the next r/w operation */
	__VOLATILE u32	pd_timer;			/*!< @brief Timer counter */

} __SDPDB, *__PSDPDB;

/**
  * @}
  */


i32 __sdInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode);
i32 __sdDestroy(__PDEVICE dv);
i32 __sdIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len);
i32 __sdOpen(__PDEVICE dv, u8 mode);
i32 __sdClose(__PDEVICE dv);
i32 __sdSize(__PDEVICE dv, u8 mode);
i32 __sdFlush(__PDEVICE dv);
i32 __sdRead(__PDEVICE dv, __PVOID buf, u16 qty);
i32 __sdWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty);

/**
  * @}
  */

/**
  * @}
  */

#endif // __SD_H__

