/***************************************************************************
 * sd.c
 * (C) 2010 Ivan Meleca
 * www.milos.it
 *
 * The SD logic implementation was taken from the
 * Demo for ChaN's FAT-module on STMicroelectronics STM32 microcontroller.
 * by Martin Thomas, Kaiserslautern, Germany <mthomas(at)rhrk.uni-kl.de>
 * Here follows the original disclaimer and list of conditions.
 *
 * ******************************************************************************
 * Demo for ChaN's FAT-module on STMicroelectronics STM32 microcontroller
 * Version Timestamp 20100704
 * by Martin Thomas, Kaiserslautern, Germany <mthomas(at)rhrk.uni-kl.de>
 * ******************************************************************************
 * Copyright (c) 2009, 2010
 * - ChaN (FAT-Code, driver-template, ff_test_term)
 * - Martin Thomas (STM32 SD/MMC/SDHC driver and demo-application)
 * - ST Microelectronics (Standard Peripherals Firmware Library)
 * - ITB CompuPhase (minIni)
 * All rights reserved.
 *
 * License for this product follows. Licenses of the components may differ
 * but should be compatible. Read the license- and readme-files in the
 * library directory.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * * Redistributions of source code must retain the above copyright
 *   notice, this list of conditions and the following disclaimer.
 * * Redistributions in binary form must reproduce the above copyright
 *   notice, this list of conditions and the following disclaimer in
 *   the documentation and/or other materials provided with the
 *   distribution.
 * * Neither the name of the copyright holders nor the names of
 *   contributors may be used to endorse or promote products derived
 *   from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
 * LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 * POSSIBILITY OF SUCH DAMAGE.

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "sd.h"
#include <core/heap.h>
#include <core/system.h>
#include <common/common.h>
#include <drivers/spi/spi.h>
#include <plat_sd.h>

#if __CONFIG_COMPILE_SD

/** @addtogroup Driver
  * @{
  */

/** @defgroup SD SD
  * SD/MMC device driver
  * @{
  */

/** @defgroup SD_PrivateMacros Private macros
  * @{
  */

/*
 * SPI-related IOCTL calls
 */
#define __sdSpiCsHigh()		__deviceIOCtl(pd->pd_dv, __IOCTL_SET_CS, 1, __NULL, 0)
#define __sdSpiCsLow()		__deviceIOCtl(pd->pd_dv, __IOCTL_SET_CS, 0, __NULL, 0)
#define __sdSpiSetSpeed(x)	__deviceIOCtl(pd->pd_dv, __IOCTL_SETBAUD, x, __NULL, 0)
#define __sdSpiToggleCS(x) 	__deviceIOCtl(pd->pd_dv, __IOCTL_ASSERT_CS, x, __NULL, 0)

/*
 * SD-related platform IOCTL calls
 */
#define __sdPower(x)		(dv->dv_plat_ioctl)(dv,	__SD_PLAT_SET_POWER, x,	__NULL, 0, __NULL, 0)
#define __sdGetCD()			(dv->dv_plat_ioctl)(dv,	__SD_PLAT_GET_CD, 0, __NULL, 0, __NULL, 0)
#define __sdGetWP()			(dv->dv_plat_ioctl)(dv,	__SD_PLAT_GET_WP, 0, __NULL, 0, __NULL, 0)
#define __sdInitHW()		(dv->dv_plat_ioctl)(dv,	__SD_PLAT_INIT_HW, 0, __NULL, 0, __NULL, 0)

/**
  * @}
  */

/** @defgroup SD_PrivateFunctions  Private functions
  * @{
  */

/*!
 * @brief Performs a write/flush preceding a read operation.
 *
 * Called from the __SD driver module.
 *
 * @param dv	Pointer to a device.
 * @param wbuf	Buffer to write.
 * @param rbuf	Buffer to receive read bytes.
 * @param len	Lenght to write/read.
 *
 * @return		A __deviceRead() return code, or the quantity of bytes written/read.
 */
__STATIC i16 __sdWriteAndRead(__PDEVICE dv, u8* wbuf, u8* rbuf, u32 len)
{
	if (__deviceWrite(dv, wbuf, len) == len) {
		if (__deviceFlush(dv) == __DEV_OK) {
			return __deviceRead(dv, rbuf, len);
		}
	}

	return 0;
}

/*!
 * @brief Releases SD.
 *
 * Used when SD is accessed through SPI.
 *
 * @param dv	Pointer to the SD device.
 *
 * @return Nothing.
 *
 */
__STATIC __VOID __sdRelease(__PDEVICE dv)
{
	__PSDPDB pd = dv->dv_pdb;

	if (pd->pd_dv->dv_type == __DEV_SPI)
	{
		__sdSpiCsHigh();
		pd->pd_buf[0] = 0xFF;
		__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 1);
	}
}

/*!
 * @brief Waits for the device to be ready to operate.
 *
 * Internal function.
 *
 * @param	dv 	Pointer to a device.
 * @return	0xFF on success.
 *
 */
__STATIC u8 __sdWaitForReady(__PDEVICE dv)
{
	__PSDPDB pd;
	u8 i = 0;
	
	pd = dv->dv_pdb;
	pd->pd_timer = 500;

	do {
		__memSet(pd->pd_buf, 0xFF, 10);
		if (__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 10) != 10) return 0;
		
		for (i = 0; i < 10; i++)
			if (pd->pd_buf[i] == 0xFF) return 0xFF;
		
	} while (pd->pd_timer);
		
	return 0;
}

/*!
 * @brief Sends a command to the card through the \c dv device.
 *
 * @param 	dv		Pointer to a device.
 * @param	cmd		Command to send.
 * @param 	param	Optional parameter.
 *
 * @return	The anwser from the card.
 *
 */
__STATIC u8 __sdSendCommand(__PDEVICE dv, u8 cmd, u32 param)
{
	u8 chksum, retry, res;
	__PSDPDB pd;

	pd = dv->dv_pdb;

	if (cmd & 0x80)
	{	/* ACMD<n> is the command sequence of CMD55-CMD<n> */
		cmd &= 0x7F;
		res = __sdSendCommand(dv, __SD_CMD55, 0);
		if (res > 1) return res;
	}
	
	__sdSpiCsHigh();
	__sdSpiCsLow();

	if (__sdWaitForReady(dv) != 0xFF) {
		return 0xFF;
	}

	pd->pd_buf[0] = cmd;
	pd->pd_buf[1] = (param >> 24) & 0xFF;
	pd->pd_buf[2] = (param >> 16) & 0xFF;
	pd->pd_buf[3] = (param >> 8) & 0xFF;
	pd->pd_buf[4] = param & 0xFF;
	chksum = 0x01;
	if (cmd == __SD_CMD0) chksum = 0x95;
	if (cmd == __SD_CMD8) chksum = 0x87;
	pd->pd_buf[5] = chksum;

	/* Transmit */
	__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 6);

	if (cmd == __SD_CMD12)
	{
		/* Ignore extra byte */
		pd->pd_buf[0] = 0xFF;
		__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 1);
	}

	/* Send until we receive an answer */
	retry = 10;
	pd->pd_buf[0] = 0xFF;
	while (retry) {
		__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 1);
		res = *pd->pd_buf;
		if (!(res & 0x80))
		{
			return res;
		}

		retry--;
	}

	return res;
}

/*!
 * @brief SD driver thread.
 *
 * Here we'll be controlling/updating:
 * 	- General status
 * 	- Write protect
 * 	- Card detect
 *
 * There will be one thread like this for each
 * __SDx driver registered.
 *
 * @return		Nothing.
 *
 */
__STATIC __VOID __sdThread(__VOID)
{
	__PDEVICE dv;
	__PSDPDB pd;

	/* __SD_X device */
	dv = __threadGetParameter();

	/* Get device private data block */
	pd = dv->dv_pdb;

	/* Loop */
	for (;;) {

		/* Control Card Detect */
		if (__sdGetCD())
		{
			if (!(pd->pd_flags & __SD_FLAG_CARD_INSERTED))
			{
				/* Card detected event */
				pd->pd_flags |= __SD_FLAG_CARD_INSERTED;
			}
		} else
		{
			if (pd->pd_flags & __SD_FLAG_CARD_INSERTED)
			{
				/* Card removed event */
				pd->pd_flags &= ~__SD_FLAG_CARD_INSERTED;
			}
		}

		/* Control Write Protect */
		if (__sdGetWP())
		{
			pd->pd_flags |= __SD_FLAG_WRITE_PROTECT;
		} else
		{
			pd->pd_flags &= ~__SD_FLAG_WRITE_PROTECT;
		}

		/* Decrement timer */
		if (pd->pd_timer >= 100)
		{
			pd->pd_timer -= 100;
		} else {
			pd->pd_timer = 0;
		}
	
		__threadSleep(100);
	}
}

__STATIC u8 __sdTransmitBlock(__PDEVICE dv, u8* buf, u8 token)
{
	__PSDPDB pd;

	pd = dv->dv_pdb;

	if (__sdWaitForReady(dv) != 0xFF)
	{
		return 0;
	}

	__sdWriteAndRead(pd->pd_dv, &token, pd->pd_buf, 1);

	if (token != 0xFD)
	{
		__sdWriteAndRead(pd->pd_dv, buf, pd->pd_buf, 512);

		/* Dummy CRC */
		pd->pd_buf[0] = pd->pd_buf[1] = 0xFF;
		__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 2);

		/* Get answer */
		pd->pd_buf[0] = 0xFF;
		__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 1);
		if ((pd->pd_buf[0] & 0x1F) != 0x05) {
			return 0;
		}
	}

	return 1;
}

__STATIC u8 __sdReceiveBlock(__PDEVICE dv, u8* buf, u32 len)
{
__PSDPDB pd;
u32 read;

	if (len > __SD_BUFFER_SIZE) return 0;

	pd = dv->dv_pdb;
	pd->pd_timer = 1000;

	*pd->pd_buf = 0xFF;

	while (pd->pd_timer && *pd->pd_buf != 0xFE)
	{
		__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 1);
	}

	if (*pd->pd_buf != 0xFE)
	{
		return 0;
	}

	__memSet(pd->pd_buf, 0xFF, len);

	read = __sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, len);

	if (read != len)
	{
		return 0;
	}

	__memCpy(buf, pd->pd_buf, len);

	/* Discard CRC */
	__memSet(pd->pd_buf, 0xFF, 2);
	__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 2);
	return 1;
}

/**
  * @}
  */

/** @defgroup SD_Functions Functions
  * @{
  */

/*!
 * @brief Initialization.
 *
 * Called from __deviceRegister() to initialize the SD driver.
 *
 * Before calling this function set the pd_dv and pd_dv_mode of
 * the __PSDPDB structure (private data block) inside the __DEVICE dv.
 *
 * @param	dv			Pointer to a device.
 * @param 	param1
 * @param 	param2
 * @param	mode
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __sdInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode)
{
__PSDPDB pd;

	pd = dv->dv_pdb;

	/* Register and open our access device (can be SPI or SDIO) */
	if (__deviceRegister(pd->pd_dv, 600, 600, pd->pd_dv_mode) != __DEV_OK)
	{
		return __DEV_ERROR;
	}

	if (__deviceOpen(pd->pd_dv, 0) != __DEV_OK)
	{
		__deviceUnregister(pd->pd_dv);
		return __DEV_ERROR;
	}

	/* Create Lock */
	pd->pd_lock = __lockCreate();

	/* Create TX and RX buffers */
	pd->pd_buf = __heapAllocZero(__SD_BUFFER_SIZE);

	__deviceIOCtl(pd->pd_dv, __IOCTL_SETRXTIMEOUT, 1000, __NULL, 0);
	__deviceIOCtl(pd->pd_dv, __IOCTL_SETTXTIMEOUT, 1000, __NULL, 0);

	/* Initialize hardware */
	__sdInitHW();

	/* Chip Select low/high */
	if (pd->pd_dv->dv_type == __DEV_SPI)
	{
		__sdSpiCsLow();
		__sdSpiCsHigh();
	}

	/* Spin our thread, call it like the device */
	pd->pd_th = __threadCreate(dv->dv_name, __sdThread, 100, 164, 1, dv);
	if (!pd->pd_th)
	{
		__deviceClose(pd->pd_dv);
		__deviceUnregister(pd->pd_dv);
		return __DEV_ERROR;
	}

	dv->dv_rgcnt++;
	return __DEV_OK;
}

/*!
 * @brief SD driver destroy.
 *
 * Called from __deviceUnregister().
 *
 * @param	dv	Pointer to a device.
 * @return		__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __sdDestroy(__PDEVICE dv)
{
	/* todo */
	return __DEV_OK;
}

/*!
 * @brief Device Input/Output control function.
 *
 * Called from __deviceIOCtl().
 *
 * @param	dv			Pointer to a device.
 * @param 	cmd			Command code to execute.
 * @param	param		Input parameter.
 * @param	data		Optional data pointer.
 * @param	len			\c data length.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __sdIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len)
{
	__PSDPDB pd;
	i32 ret = __DEV_UNK_IOCTL;

	pd = dv->dv_pdb;

	if (!__lockOwn(pd->pd_lock, 1000)) return ret;

	switch (cmd)
	{
		case __IOCTL_MEDIA_AVAILABLE:
			ret = (pd->pd_flags & __SD_FLAG_CARD_INSERTED) ? __TRUE : __FALSE;
			break;

		case __IOCTL_WRITE_PROTECTED:
			ret =  (pd->pd_flags & __SD_FLAG_WRITE_PROTECT) ? __TRUE : __FALSE;
			break;

		case __IOCTL_SET_SECTOR:
			pd->pd_sector = param;
			ret = __DEV_OK;
			break;
	}

	__lockRelease(pd->pd_lock);
	return ret;
}

/*!
 * @brief SD device driver open function.
 *
 * Called from __deviceOpen() to open the SD driver.
 *
 * @param	dv			Pointer to a device.
 * @param 	mode		Open modes.
 * @return				__DEV_OK on success, otherwise __DEV_ERROR.
 *
 */
i32 __sdOpen(__PDEVICE dv, u8 mode)
{
	__PSDPDB pd = dv->dv_pdb;
	u8 retries = 10;

	if (!__lockOwn(pd->pd_lock, 1000)) return __DEV_ERROR;
	pd->pd_ct = 0;

	/* Power on the card */
	__sdPower(1);

	/* Wait 100 ms */
	__threadSleep(100);

	/* Check for CD */
	if (!(pd->pd_flags & __SD_FLAG_CARD_INSERTED))
	{
		__lockRelease(pd->pd_lock);
		return __DEV_ERROR;
	}

	if (pd->pd_dv->dv_type == __DEV_SPI)
	{
		/* SPI low speed */
		__sdSpiSetSpeed(0);

		/* Disable SPI CS generation.
		 * We will manually move CS, if SPI.
		 */
		__sdSpiToggleCS(0);

		/* Chip Select High */
		__sdSpiCsHigh();
	}

	/* +80 dummy clocks */
	__memSet(pd->pd_buf, 0xFF, 80);
	__deviceWrite(pd->pd_dv, pd->pd_buf, 80);
	__deviceFlush(pd->pd_dv);
	/* Read +80 garbage bytes */
	__deviceRead(pd->pd_dv, pd->pd_buf, 80);
	
	/* Send CMD0 */
	while (__sdSendCommand(dv, __SD_CMD0, 0) != 1 && retries--)
	{
		if (!retries)
		{
			__lockRelease(pd->pd_lock);
			return -1;
		}
	}

	/* Init with 1000 ms timeout */
	pd->pd_timer = 1000;

	if (__sdSendCommand(dv, __SD_CMD8, 0x1AA) == 1)
	{	/* SDHC */

		/* Read trailing 4 bytes */
		__memSet(pd->pd_buf, 0xFF, 4);
		__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 4);

		/* The card can work at VDD range of 2.7-3.6V */
		if (pd->pd_buf[2] == 0x01 && pd->pd_buf[3] == 0xAA)
		{
			/* Wait for leaving idle state (ACMD41 with HCS bit) */
			while (pd->pd_timer && __sdSendCommand(dv, __SD_ACMD41, 1 << 30));

			/* Check CCS bit in the OCR */
			if (pd->pd_timer && __sdSendCommand(dv, __SD_CMD58, 0) == 0)
			{
				__memSet(pd->pd_buf, 0xFF, 4);
				__sdWriteAndRead(pd->pd_dv, pd->pd_buf, pd->pd_buf, 4);
				pd->pd_ct = (pd->pd_buf[0] & 0x40) ? __SD_CT_SD2 | __SD_CT_BLOCK : __SD_CT_SD2;
			}
		}
	} else
	{							/* SDSC or MMC */
		if (__sdSendCommand(dv, __SD_ACMD41, 0) <= 1)
		{
			pd->pd_ct = __SD_CT_SD1; 	/* SD */
			while (pd->pd_timer && __sdSendCommand(dv, __SD_ACMD41, 0));
		} else
		{
			pd->pd_ct = __SD_CT_MMC;	/* MMC */
			while (pd->pd_timer && __sdSendCommand(dv, __SD_CMD1, 0));
		}

		/* Set R/W block length to 512 */
		if (!pd->pd_timer || __sdSendCommand(dv, __SD_CMD16, 512) != 0)
		{
			pd->pd_ct = 0;
		}
	}

	/* Deselect SD */
	__sdRelease(dv);

	/* Known type? */
	if (pd->pd_ct)
	{
		/* SPI high speed */
		if (pd->pd_dv->dv_type == __DEV_SPI) __sdSpiSetSpeed(1);
	} else
	{
		/* Power off the card */
		__sdPower(0);
		__lockRelease(pd->pd_lock);
		return -3;
	}

	__lockRelease(pd->pd_lock);
	return 0;
}

/*!
 * @brief SD driver close function.
 *
 * Called from __deviceClose() to close the SD driver.
 *
 * @param	dv			Pointer to a device.
 * @return				0 on success, otherwise -1.
 *
 */
i32 __sdClose(__PDEVICE dv)
{
	/* TODO */
	return 0;
}

/*!
 * @brief Returns the count of the SPI unsent/unread bytes.
 *
 * Called from __deviceSize().
 *
 * @param	dv				Pointer to a device.
 * @param 	mode			Parameter defining on which buffer operate.
 * @return					the SPI unsent/unread bytes. -1 on error.
 *
 */
i32 __sdSize(__PDEVICE dv, u8 mode)
{
	return 0;
}

/*!
 * @brief SD driver flush function.
 *
 * Unused. The __sdWrite() function directly performs the writing.
 *
 * @param	dv		Pointer to a device.
 * @return			__DEV_OK
 *
 */
i32 __sdFlush(__PDEVICE dv)
{
	return __DEV_OK;
}

/*!
 * @brief SD driver read function.
 *
 * Read SD \c qty sectors.
 *
 * @param	dv			Pointer to a device.
 * @param 	buf			Pointer to a buffer to receive the data.
 * @param	qty			Quantity of sectors.
 * @return				0 on success, otherwise a value indicating
 * 						the remaining sectors to read.
 *
 */
i32 __sdRead(__PDEVICE dv, __PVOID buf, u16 qty)
{
	__PSDPDB pd;
	u32 sector;
	u8* ptr = (u8*) buf;

	pd = dv->dv_pdb;

	if (!__lockOwn(pd->pd_lock, 1000))
	{
		return qty;
	}

	sector = pd->pd_sector;

	/* Convert to byte address if needed */
	if (!(pd->pd_ct & __SD_CT_BLOCK)) sector *= 512;
	
	/* Single block read? */
	if (qty == 1)
	{
		if (__sdSendCommand(dv, __SD_CMD17, sector) == 0)
		{
			if (__sdReceiveBlock(dv, ptr, 512))
			{
				qty = 0;
			}
		}
	} else
	{
		if (__sdSendCommand(dv, __SD_CMD17, sector) == 0)
		{
			while (qty)
			{
				if (!__sdReceiveBlock(dv, ptr, 512))
				{
					break;
				}
				ptr += 512;
				qty--;
			}

			/* Stop transmission */
			__sdSendCommand(dv, __SD_CMD12, 0);
		}
	}

	__sdRelease(dv);

	__lockRelease(pd->pd_lock);

	/* TODO see return codes */
	return qty;
}


/*!
 * @brief SD driver write function.
 *
 * Writes \c qty sectors.
 *
 * @param	dv			Pointer to a device.
 * @param	buf			Pointer to the buffer containing data.
 * @param	qty			Quantity of sectors.
 * @return				Bytes written or -1 on error.
 *
 */
i32 __sdWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty)
{
	__PSDPDB pd;
	u32 sector;
	u8* ptr = (u8*) buf;

	pd = dv->dv_pdb;

	if (!__lockOwn(pd->pd_lock, 1000))
	{
		return qty;
	}

	sector = pd->pd_sector;

	/* Convert to byte address if needed */
	if (!(pd->pd_ct & __SD_CT_BLOCK)) sector *= 512;

	/* Single block */
	if (qty == 1)
	{
		if (__sdSendCommand(dv, __SD_CMD24, sector) == 0 &&
			__sdTransmitBlock(dv, ptr, 0xFE))
		{
			qty = 0;
		}

	} else
	{
		/* Multiple blocks */
		if (__sdSendCommand(dv, __SD_CMD25, sector) == 0)
		{
			while (qty)
			{
				if (!__sdTransmitBlock(dv, ptr, 0xFC))
				{
					break;
				}
				qty--;
				ptr += 512;
			}

			/* Transmit stop transfer token */
			if (!__sdTransmitBlock(dv, __NULL, 0xFD))
			{
				qty = 1;
			}
		}
	}

	__sdRelease(dv);

	__lockRelease(pd->pd_lock);
	return qty;
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif // __CONFIG_COMPILE_SPI
