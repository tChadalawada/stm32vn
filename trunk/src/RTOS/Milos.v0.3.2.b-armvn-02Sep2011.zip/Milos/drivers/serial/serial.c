/***************************************************************************
 * serial.c
 * (C) 2010 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#include "serial.h"
#include <core/heap.h>
#include <common/common.h>

#if __CONFIG_COMPILE_SERIAL


/** @addtogroup Driver
  * @{
  */

/** @defgroup Serial Serial
  * Serial device driver
  * @{
  */

/** @defgroup Serial_Functions Functions
  * @{
  */

/*!
 * @brief Device Input/Output control function.
 *
 * Called from __deviceIOCtl().
 *
 * @param	dv			Pointer to a device.
 * @param 	cmd			Command code to execute.
 * @param	param		Input parameter.
 * @param	data		Optional data pointer.
 * @param 	len			Length of \c data.
 * @return				0 on success, otherwise -1.
 *
 */
i32	__serialIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len)
{
	pu32 lpar = data;
	__PSERIALPDB	pd = dv->dv_pdb;

	
	switch(cmd)
	{
		case __IOCTL_SETBAUD:
			(dv->dv_plat_ioctl)(dv,	__SERIAL_PLAT_SET_BAUDRATE, param,
								__NULL, 0, __NULL, 0);
			pd->pd_baud = param;
			return __DEV_OK;
		case __IOCTL_GETBAUD:
			*lpar = pd->pd_baud = param;
			return __DEV_OK;
		case __IOCTL_SETRXTIMEOUT:
			pd->pd_rxtmo = (u16) param;
			return __DEV_OK;
		case __IOCTL_GETRXTIMEOUT:
			*lpar = (u32) pd->pd_rxtmo;
			return __DEV_OK;
		case __IOCTL_SETTXTIMEOUT:
			pd->pd_txtmo = (u16) param;
			return __DEV_OK;
		case __IOCTL_GETTXTIMEOUT:
			*lpar = (u32) pd->pd_txtmo;
			return __DEV_OK;
		case __IOCTL_ECHO_ONOFF:
			if (param) {
				pd->pd_flags |= __SERIALBTYPE_ECHO;
			} else {
				pd->pd_flags &= ~(__SERIALBTYPE_ECHO);
			}
			return __DEV_OK;
		case __IOCTL_ECHO:
			return (pd->pd_flags & __SERIALBTYPE_ECHO);
	}

	return __DEV_UNK_IOCTL;
}

/*!
 * @brief Initialization.
 *
 * Called from __deviceRegister() to initialize the serial device driver.
 *
 * @param	dv			Pointer to a device.
 * @param 	rxbuflen	RX buffer size.
 * @param 	txbuflen	TX buffer size.
 * @param	mode		Not used for this device.
 * @return				0 on success, otherwise -1.
 *
 */
i32 __serialInit(__PDEVICE dv, i16 rxbuflen, i16 txbuflen, u16 mode)
{
	__PSERIALPDB pd = dv->dv_pdb;

	if (rxbuflen < __SERIAL_MINRXBUFLEN) rxbuflen = __SERIAL_MINRXBUFLEN;
	if (txbuflen < __SERIAL_MINTXBUFLEN) txbuflen = __SERIAL_MINTXBUFLEN;
	
	if (dv->dv_rxev) __memSet(dv->dv_rxev, 0, sizeof(__EVENT));
	if (dv->dv_txev) __memSet(dv->dv_txev, 0, sizeof(__EVENT));

	pd->pd_rxlen = rxbuflen;
	pd->pd_txlen = txbuflen;

	if ((pd->pd_rxbuf = __heapAlloc(rxbuflen)) == __NULL) return __DEV_ERROR;
	if ((pd->pd_txbuf = __heapAlloc(txbuflen)) == __NULL)
	{
		__heapFree(pd->pd_rxbuf);
		return __DEV_ERROR;
	}

	pd->pd_flags = __SERIALBTYPE_DYNAMIC;

	
	return __DEV_OK;
}

/*!
 * @brief Set static buffers.
 *
 * Used for supplying custom buffers to the serial device driver. The previously
 * allocated buffers will be freed.
 *
 * @param	dv			Pointer to a device.
 * @param 	rxlen		RX buffer size.
 * @param 	txlen		TX buffer size.
 * @param	brx			RX buffer address.
 * @param	btx			TX buffer address.
 * @return				0 on success, otherwise -1.
 *
 */
i32 __serialSetBuffer(__PDEVICE dv, u16 rxlen, u16 txlen, __PVOID brx, __PVOID btx)
{
	__PSERIALPDB pd = dv->dv_pdb;

	__systemStop();

	if (pd->pd_flags & __SERIALBTYPE_DYNAMIC)
	{
		if (pd->pd_rxbuf != __NULL) __heapFree(pd->pd_rxbuf);
		if (pd->pd_txbuf != __NULL) __heapFree(pd->pd_txbuf);
		pd->pd_flags &= ~__SERIALBTYPE_DYNAMIC;
	}

	pd->pd_rxbuf = (pu8) brx;
	pd->pd_txbuf = (pu8) btx;

	pd->pd_rxlen = rxlen;
	pd->pd_txlen = txlen;

	__systemStart();

	return __DEV_OK;
}

/*!
 * @brief Serial device driver destroy.
 *
 * Called from __deviceUnregister().
 *
 * @param	dv			Pointer to a device.
 * @return				0 on success, otherwise -1.
 *
 */
i32	__serialDestroy(__PDEVICE dv)
{
	__PSERIALPDB	pd = dv->dv_pdb;

	/* Check if still opened */
	if (dv->dv_opcnt != 0) return __DEV_ERROR;

	if (pd != __NULL) {
		if (pd->pd_flags & __SERIALBTYPE_DYNAMIC)
		{
			if (pd->pd_rxbuf != __NULL) __heapFree(pd->pd_rxbuf);
			if (pd->pd_txbuf != __NULL) __heapFree(pd->pd_txbuf);
		}
	}
	return __DEV_OK;
}

/*!
 * @brief Serial device driver open function.
 *
 * Called from __deviceOpen() to open the serial device.
 *
 * @param	dv			Pointer to a device.
 * @param 	mode		Open modes.
 * @return				0 on success, otherwise -1.
 *
 */
i32	__serialOpen(__PDEVICE dv, u8 mode)
{	/*	Init hardware */
	(dv->dv_plat_ioctl)(dv,	__SERIAL_PLAT_INIT_HW,
						0, __NULL, 0, __NULL, 0);

	/* Set TX/RX interrupt vector */
	(dv->dv_plat_ioctl)(dv,	__SERIAL_PLAT_SET_IRQ,
						0, __NULL, 0, __NULL, 0);

	return __DEV_OK;
}

/*!
 * @brief Serial device driver close function.
 *
 * Called from __deviceClose() to close the serial device.
 *
 * @param	dv			Pointer to a device.
 * @return		__DEV_OK	0 on success, otherwis__DEV_ERROR-1.
 *
 */
i32	__serialClose(__PDEVICE dv)
{
	/*	De-init hardware */
	(dv->dv_plat_ioctl)(dv,	__SERIAL_PLAT_DEINIT_HW,
							0, __NULL, 0, __NULL, 0);

	/* Disable TX/RX interrupt vector */
	(dv->dv_plat_ioctl)(dv,	__SERIAL_PLAT_UNSET_IRQ,
						0, __NULL, 0, __NULL, 0);

	return __DEV_OK;
}

/*!
 * @brief Returns the count of the serial unsent/unread bytes.
 *
 * Called from __deviceSize().
 *
 * @param	dv				Pointer to a device.
 * @param 	mode			Parameter defining on which buffer operate.
 * @arg		__DEV_RXSIZE	Get the RX buffer unread bytes.
 * @arg		__DEV_TXSIZE	Get the TX buffer unsent bytes.
 * @return					the serial unsent/unread bytes. -1 on error.
 *
 */
i32	__serialSize(__PDEVICE dv, u8 mode)
{
	__PSERIALPDB	pd = dv->dv_pdb;

	/*	Check for initialized or opened */

	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return(-1);

	if (mode == __DEV_RXSIZE) return(pd->pd_rxcnt);
	if (mode == __DEV_TXSIZE) return(pd->pd_txcnt);
	return __DEV_ERROR;
}


/*!
 * @brief Serial device driver read function.
 *
 * Read from the RX buffer if there is data available, otherwise it will wait
 * on an event until receives data. Called from __deviceRead().
 *
 * @param	dv			Pointer to a device.
 * @param 	buf			Pointer to a buffer to receive the data.
 * @param	qty			Required quantity to read.
 * @return				Bytes read or -1 on error.
 *
 */
i32	__serialRead(__PDEVICE dv, __PVOID buf, u16 qty)
{
	u16	cnt = 0;
	__PSTRING	p = buf;
	__PSERIALPDB	pd = dv->dv_pdb;

	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	while (cnt < qty)
	{
		if (pd->pd_rxcnt > 0)
		{
//			__systemStop();
			*p++ = *(pd->pd_rxbuf + pd->pd_rbidx);
			if (++pd->pd_rbidx >= pd->pd_rxlen) pd->pd_rbidx = 0;
			--pd->pd_rxcnt;
			++cnt;
//			__systemStart();
		} else
		{
			if (!dv->dv_rxev) return cnt;
			__eventReset(dv->dv_rxev);
			if (__eventWait(dv->dv_rxev,(u32) pd->pd_rxtmo) == __EVRET_TIMEOUT)
			{
				return cnt;
			}
		}
	}
	return cnt;
}

/*!
 * @brief Serial device driver flush function.
 *
 * Flush remaining unsent bytes through the UART. Called from __deviceFlush().
 *
 * @param	dv			Pointer to a device.
 * @return				0 on success, -1 on timeout.
 *
 */
i32	__serialFlush(__PDEVICE dv)
{
__PSERIALPDB pd = dv->dv_pdb;

	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	/* something to send? */
	if (!pd->pd_txcnt) return __DEV_OK;

	if (dv->dv_txev) __eventReset(dv->dv_txev);

	/*	Init transmission */
	(dv->dv_plat_ioctl)(dv,	__SERIAL_PLAT_INIT_TX,
						0, __NULL, 0, __NULL, 0);

	if (!dv->dv_txev) return 0;
	if (__eventWait(dv->dv_txev, pd->pd_txtmo) == __EVRET_SUCCESS) return __DEV_OK;

	return __DEV_TIMEOUT;
}

/*!
 * @brief Serial device driver write function.
 *
 * Writes to the TX buffer. Called from __deviceWrite().
 *
 * @param	dv			Pointer to a device.
 * @param	buf			Pointer to the buffer containing data.
 * @param	qty			Quantity of bytes to write.
 * @return				Bytes written or -1 on error.
 *
 */
i32	__serialWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty)
{
	u16 cnt = 0;
	u8* p = (u8*) buf;
	__PSERIALPDB pd = dv->dv_pdb;

	/* Check for initialized or opened */
	if (dv->dv_rgcnt == 0 || dv->dv_opcnt == 0) return __DEV_ERROR;

	while (cnt < qty)
	{
		if (pd->pd_txcnt < pd->pd_txlen)
		{
//			__systemStop();
			*(pd->pd_txbuf + pd->pd_tbidx) = *p++;
			if (++pd->pd_tbidx >= pd->pd_txlen) pd->pd_tbidx = 0;
			++pd->pd_txcnt;
//			__systemStart();
			
			++cnt;
		} else
		{
			if (__serialFlush(dv) != __DEV_OK)
			{
				return __DEV_ERROR;
			}
		}
	}
	return cnt;
}

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

#endif // __CONFIG_COMPILE_SERIAL

