/***************************************************************************
 * serial.h
 * (C) 2010 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef	__SERIAL_H__
#define	__SERIAL_H__

#include <core/system.h>
#include <core/intrvect.h>
#include <core/device.h>
#include <plat_uart.h>

/** @addtogroup Driver
  * @{
  */

/** @addtogroup Serial
  * @{
  */

/** @defgroup Serial_Constants Constants
  * @{
  */


/** @defgroup Serial_SpeedDefines Baudrates
  * @{
  */

#define	__SERIAL_2400				0x00
#define	__SERIAL_4800				0x01
#define	__SERIAL_9600				0x02
#define	__SERIAL_19200				0x03
#define	__SERIAL_38400				0x04
#define	__SERIAL_57600				0x05
#define	__SERIAL_115200				0x06

/**
  * @}
  */

/** @defgroup Serial_MinimumBufferDefines Buffer
  * @{
  */

#define	__SERIAL_MINRXBUFLEN		32		/*!< @brief Min RX buffer length */
#define	__SERIAL_MINTXBUFLEN		32		/*!< @brief Min TX buffer length */

/**
  * @}
  */


/** @defgroup Serial_PlatIoCtlCodesDefines Platform IOCTLs
  * @{
  */

#define __SERIAL_PLAT_INIT_HW			1
#define __SERIAL_PLAT_DEINIT_HW			2
#define __SERIAL_PLAT_SET_BAUDRATE		3
#define __SERIAL_PLAT_CHAR_OUTPUT		4
#define __SERIAL_PLAT_CHAR_INPUT		5
#define __SERIAL_PLAT_INIT_TX			6
#define __SERIAL_PLAT_SET_IRQ			7
#define __SERIAL_PLAT_UNSET_IRQ			8

/**
  * @}
  */

/** @defgroup Serial_BitsDefines Stop bits
  * @{
  */

#define	__SERIALBITS_5				1
#define	__SERIALBITS_6				2
#define	__SERIALBITS_7				3
#define	__SERIALBITS_8				4

/**
  * @}
  */

/** @defgroup Serial_ParityDefines Parity types
  * @{
  */

#define	__SERIALPARITY_NONE			1
#define	__SERIALPARITY_EVEN			2
#define	__SERIALPARITY_ODD			3

/**
  * @}
  */

/** @defgroup Serial_ErrorCodesDefines Error codes
  * @{
  */

#define	__SERIALERR_OVERFLOW		0x01	/*!< @brief Receiver buffer overflow */
#define	__SERIALERR_OVERRUN			0x02	/*!< @brief Overrun error */
#define	__SERIALERR_PARITY			0x02	/*!< @brief Parity error */

/**
  * @}
  */

/** @defgroup Serial_TypesDefines Serial types
  * @{
  */

#define __SERIALBTYPE_ECHO			0x02	/*!< @brief SERIAL sends back ECHO */
#define	__SERIALBTYPE_DYNAMIC		0x01	/*!< @brief Buffer type is dynamic */
#define	__SERIALBTYPE_STATIC		0x00	/*!< @brief Buffer type is static */

/**
  * @}
  */

/**
  * @}
  */

/** @defgroup Serial_TypeDefs Typedefs
  * @{
  */

typedef struct	__serialpdbTag {

	u8				pd_flags;		/*!< @brief Buffer type (static or dynamic) */
	u32				pd_baud;		/*!< @brief Actual BAUD RATE */
	__VOLATILE u8	pd_rxerr;		/*!< @brief Receiver error */
	__VOLATILE u16	pd_rxtmo;		/*!< @brief Receiver timeout */
	__VOLATILE u16	pd_rcidx;		/*!< @brief Receiver buffer index */
	__VOLATILE u16	pd_rbidx;		/*!< @brief Read buffer index */
	__VOLATILE u16	pd_rxcnt;		/*!< @brief Received chars count */
	__VOLATILE u16	pd_rxrev;		/*!< @brief Received chars count reverse count */
	__VOLATILE u16	pd_rxlen;		/*!< @brief RX buffer length */
	pu8				pd_rxbuf;		/*!< @brief RX buffer */
	__VOLATILE u8	pd_txsnd;		/*!< @brief Transmission is started */
	__VOLATILE u16	pd_txtmo;		/*!< @brief Transmit timeout */
	__VOLATILE u16	pd_tcidx;		/*!< @brief Transmit buffer index */
	__VOLATILE u16	pd_tbidx;		/*!< @brief Write buffer index */
	__VOLATILE u16	pd_txcnt;		/*!< @brief Transmit chars count */
	__VOLATILE u16	pd_txlen;		/*!< @brief TX buffer length */
	pu8				pd_txbuf;		/*!< @brief TX buffer */

} __SERIALPDB, *__PSERIALPDB;

/**
  * @}
  */


i32 __serialInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode);
i32 __serialDestroy(__PDEVICE dv);
i32 __serialIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len);
i32 __serialOpen(__PDEVICE dv, u8 mode);
i32 __serialClose(__PDEVICE dv);
i32 __serialSize(__PDEVICE dv, u8 mode);
i32 __serialFlush(__PDEVICE dv);
i32 __serialRead(__PDEVICE dv, __PVOID buf, u16 qty);
i32 __serialWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty);

/**
  * @}
  */

/**
  * @}
  */

#endif	// __SERIAL_H__
