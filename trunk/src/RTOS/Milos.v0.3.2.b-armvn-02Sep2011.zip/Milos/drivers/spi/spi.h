/***************************************************************************
 * spi.h
 * (C) 2010 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#ifndef	__SPI_H__
#define	__SPI_H__

#include <core/system.h>
#include <core/intrvect.h>
#include <core/device.h>
#include <plat_spi.h>

/** @addtogroup Driver
  * @{
  */

/** @addtogroup SPI
  * @{
  */

/** @defgroup SPI_Constants Constants
  * @{
  */

/** @defgroup SPI_MinimumBufferDefines Buffer
  * @{
  */

#define	__SPI_MINRXBUFLEN		32		/*!< @brief Min RX buffer length */
#define	__SPI_MINTXBUFLEN		32		/*!< @brief Min TX buffer length */

/**
  * @}
  */

/** @defgroup SPI_PlatIoCtlCodesDefines Platform IOCTLs
  * @{
  */

#define __SPI_PLAT_INIT_HW			1
#define __SPI_PLAT_DEINIT_HW		2
#define __SPI_PLAT_SET_SPEED		3
#define __SPI_PLAT_CHAR_OUTPUT		4
#define __SPI_PLAT_CHAR_INPUT		5
#define __SPI_PLAT_INIT_TX			6
#define __SPI_PLAT_END_TX			7
#define __SPI_PLAT_SET_IRQ			8
#define __SPI_PLAT_UNSET_IRQ		9
#define __SPI_PLAT_SET_CS			10

/**
  * @}
  */

/** @defgroup SPI_ModesDefines Modes
  * @{
  */

#define __SPIMODE_MASTER			0x01	/*!< @brief Master/Slave mode */

/**
  * @}
  */

/** @defgroup SPI_ErrorCodesDefines Error codes
  * @{
  */

#define	__SPIERR_OVERFLOW		0x01	/*!< @brief Receiver buffer overflow */

/**
  * @}
  */

/**
  * @}
  */

/** @defgroup SPI_TypeDefs Typedefs
  * @{
  */

typedef struct	__spipdbTag {

	u8				pd_flags;		/*!< @brief Buffer type (static or dynamic) */
	__VOLATILE u8	pd_rxerr;		/*!< @brief Receiver error */
	__VOLATILE u16	pd_rxtmo;		/*!< @brief Receiver timeout */
	__VOLATILE u16	pd_rcidx;		/*!< @brief Receiver buffer index */
	__VOLATILE u16	pd_rbidx;		/*!< @brief Read buffer index */
	__VOLATILE u16	pd_rxcnt;		/*!< @brief Received chars count */
	__VOLATILE u16	pd_rxrev;		/*!< @brief Received chars count reverse count */
	__VOLATILE u16	pd_rxlen;		/*!< @brief RX buffer length */
	pu8				pd_rxbuf;		/*!< @brief RX buffer */
	__VOLATILE u8	pd_txsnd;		/*!< @brief Transmission is started */
	__VOLATILE u16	pd_txtmo;		/*!< @brief Transmit timeout */
	__VOLATILE u16	pd_tcidx;		/*!< @brief Transmit buffer index */
	__VOLATILE u16	pd_tbidx;		/*!< @brief Write buffer index */
	__VOLATILE u16	pd_txcnt;		/*!< @brief Transmit chars count */
	__VOLATILE u16	pd_txlen;		/*!< @brief TX buffer length */
	pu8				pd_txbuf;		/*!< @brief TX buffer */
	u8				pd_asscs;		/*!< @brief CS pin assert. If 1, CS pin will be managed. */

} __SPIPDB, *__PSPIPDB;

/**
  * @}
  */

/**
  * @}
  */

/**
  * @}
  */

i32 __spiInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode);
i32 __spiDestroy(__PDEVICE dv);
i32 __spiIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len);
i32 __spiOpen(__PDEVICE dv, u8 mode);
i32 __spiClose(__PDEVICE dv);
i32 __spiSize(__PDEVICE dv, u8 mode);
i32 __spiFlush(__PDEVICE dv);
i32 __spiRead(__PDEVICE dv, __PVOID buf, u16 qty);
i32 __spiWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty);

#endif // __SPI_H__

