/***************************************************************************
 * dummy.c
 * (C) 2011 Ivan Meleca
 * www.milos.it

#   This program is free software; you can redistribute it and/or modify
#   it under the terms of the GNU General Public License as published by
#   the Free Software Foundation; either version 2 of the License, or
#   (at your option) any later version.
#
#   This program is distributed in the hope that it will be useful,
#   but WITHOUT ANY WARRANTY; without even the implied warranty of
#   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#   GNU General Public License for more details.
#
#   You should have received a copy of the GNU General Public License
#   along with this program; if not, write to the Free Software
#   Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.

***************************************************************************/

#if 0

i32 __dummyInit(__PDEVICE dv, i16 param1, i16 param2, u16 mode)
{
	return __DEV_OK;
}

i32 __dummyDestroy(__PDEVICE dv)
{
	return __DEV_OK;
}

i32 __dummyIOCtl(__PDEVICE dv, u32 cmd, u32 param, __PVOID data, u32 len)
{
	return __DEV_OK;
}

i32 __dummyOpen(__PDEVICE dv, u8 mode)
{
	return __DEV_OK;
}

i32 __dummyClose(__PDEVICE dv)
{
	return __DEV_OK;
}

i32 __dummySize(__PDEVICE dv, u8 mode)
{
	return __DEV_OK;
}

i32 __dummyFlush(__PDEVICE dv)
{
	return __DEV_OK;
}

i32 __dummyRead(__PDEVICE dv, __PVOID buf, u16 qty)
{
	return __DEV_OK;
}

i32 __dummyWrite(__PDEVICE dv, __CONST __PVOID buf, u16 qty)
{
	return __DEV_OK;
}

#endif

