#include "stm32f10x.h"
#include "VS1053.h"

int VS_Volume=0, VS_Bassamp=0, VS_Bassfreq=20, VS_Trebleamp=0, VS_Treblefreq=5000;

void VS1053_Configuration(void)
{
  VS1053_GPIO_Configuration();
}

/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : Configures the different GPIO ports.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void VS1053_GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  /* GPIO Periph clock enable */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE);

  /* Configure SPI pins: SCK, MISO and MOSI ---------------------------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_9 | GPIO_Pin_11;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  /* Configure SPI pins: MISO ---------------------------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_10;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
 

  /* Configure SPI pins: Manual CS ---------------------------------*/
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_2;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
  GPIO_Init(GPIOA, &GPIO_InitStructure);

  GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}


unsigned short int VS1053_Read(unsigned char address)
{
		unsigned short int temp;
				
        VS1053_CS_LOW;  // cs low
		Delay(5);

        VS1053_SendByte(VS_READ);       		  
        VS1053_SendByte(address);	        
            
   		temp = VS1053_SendByte(0x00);	// get data here MSBs	
   		temp <<= 8;
    
   		temp += VS1053_SendByte(0x00);	// get data here LSBs
   		
   		VS1053_CS_HIGH;			// cs high

        while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8) == 0) {  } // Wait for DREQ
		
		return temp;
}


void VS1053_Write(unsigned char address, unsigned short int data)
{		
	VS1053_CS_LOW;  // cs low
    Delay(5);
	
    VS1053_SendByte(VS_WRITE);
    VS1053_SendByte(address);
    VS1053_SendByte(data >> 8); 
    VS1053_SendByte(data);

   	VS1053_CS_HIGH;			// cs high		
    
    while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8) == 0) {  } // Wait for DREQ
}

void VS1053_Init(u16 settings) {
  u8 i;
  for (i = 0; i < 3; i++) { // The device has to be initiated 3 times at least!
    VS1053_Write(VS_MODE, settings);
  }
}

// This is SDI write so cs is reversed (internally inverted), pg 21
// for a sine wave test @ 5168 hz, send sequence: 0x53, 0xEF, 0x6E, 126, 0, 0, 0, 0
void VS1053_sineTest(unsigned char pitch)
{
	VS1053_CS_HIGH;			// cs high	
    Delay(5);

    VS1053_SendByte(0x53);
    VS1053_SendByte(0xEF);
    VS1053_SendByte(0x6E);
    VS1053_SendByte(pitch);
    VS1053_SendByte(0);
    VS1053_SendByte(0);
    VS1053_SendByte(0);
    VS1053_SendByte(0);  
}

void VS1053_StopsineTest(void)
{
	VS1053_CS_HIGH;			// cs high	
    Delay(5);	

    VS1053_SendByte(0x45);
    VS1053_SendByte(0x78);
    VS1053_SendByte(0x69);
    VS1053_SendByte(0x74); 
} 

unsigned char VS1053_SendByte(unsigned char dt)
{
  unsigned char read, mask;
  
  mask = 0x80; // 128
  read = 0;

  while (mask != 0) {
    VS1053_CLK_LOW; // Clock low
    if (dt & mask) {
      VS1053_SDO_HIGH; // Set databit      
    } else {
      VS1053_SDO_LOW; // Set databit      
    }  
    VS1053_CLK_HIGH; // Clock high
    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 1) {
      read |= mask; // Read input
    }
    mask = mask >> 1;
    VS1053_Delayus(5);
  }

  return read;
}

void VS1053_SetVolume(u8 vol) //0 - 100%
{
  if(vol <= 0) //<= 0
  {
    VS_Volume = vol;
    VS1053_Write(VS_VOL, 0xFFFF); //analog power off
  }
  else if(vol > 100) //> 100
  {
    VS_Volume = 100;
    VS1053_Volume(VS_Volume);
  }
  else //1 - 99
  {
    VS_Volume = vol;
    VS1053_Volume(VS_Volume);
  }
}

void VS1053_Volume(int vol)
{
  vol = 100-vol;
  VS1053_Write(VS_VOL, (vol<<8)|(vol<<0));
}

void VS1053_SendStreamByte(u8 stream)
{
  VS1053_SendByte(stream);
  while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8) == 0) {  } // Wait for DREQ
}

void VS1053_SendStream(u16 stream)
{
  VS1053_SendByte(stream >> 8); // Send MSB first
  while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8) == 0) {  } // Wait for DREQ
  VS1053_SendByte(stream); // Send LSB second
  while (GPIO_ReadInputDataBit(GPIOA, GPIO_Pin_8) == 0) {  } // Wait for DREQ
}



void VS1053_Bass(void)
{
  VS1053_Write(VS_BASS, ((VS_Trebleamp&0x0f)<<12)|((VS_Treblefreq&0x0f)<<8)|((VS_Bassamp&0x0f)<<4)|((VS_Bassfreq&0x0f)<<0));
}


void VS1053_SetTreblefreq(int freq) //1000 - 15000Hz
{
  freq /= 1000;

  if(freq < 1) //< 1
  {
    freq = 1;
  }
  else if(freq > 15) //> 15
  {
    freq = 15;
  }
  VS_Treblefreq = freq;
  VS1053_Bass();
}

int VS1053_GetTreblefreq(void)
{
  return VS_Treblefreq*1000;
}


void VS1053_SetTrebleamp(int amp) //-8 - 7dB
{
  if(amp < -8) //< -8
  {
    amp = -8;
  }
  else if(amp > 7) //> 7
  {
    amp = 7;
  }
  VS_Trebleamp = amp;
  VS1053_Bass();
}

int VS1053_GetTrebleamp(void)
{
  return VS_Trebleamp;
}


void VS1053_SetBassfreq(int freq) //20 - 150Hz
{
  freq /= 10;

  if(freq < 2) //< 2
  {
    freq = 2;
  }
  else if(freq > 15) //> 15
  {
    freq = 15;
  }
  VS_Bassfreq = freq;
  VS1053_Bass();
}

int VS1053_GetBassfreq(void)
{
  return VS_Bassfreq*10;
}


void VS1053_SetBassamp(int amp) //0 - 15dB
{
  if(amp < 0) //< 0
  {
    amp = 0;
  }
  else if(amp > 15) //> 15
  {
    amp = 15;
  }
  VS_Bassamp = amp;
  VS1053_Bass();
}

int VS1053_GetBassamp(void)
{
  return VS_Bassamp;
}


void VS1053_Delayus(vu32 nCount)
{
  for(; nCount != 0; nCount--);
}

