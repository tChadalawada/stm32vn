#include "stm32f10x.h"
#include "SSD2119.h"
#include "SSD2119_api.h"
#include "MicrochipGraphics.h"
#include "ads7843drv.h"
#include "SSD2119_touch.h"




int calibrationMatrix( POINT *lcdPtr, POINT *touchPtr, MATRIX *matrixPtr)
{

    int  retValue = 1 ;


    
    matrixPtr->Divider = ((touchPtr[0].x - touchPtr[2].x) * (touchPtr[1].y - touchPtr[2].y)) - 
                         ((touchPtr[1].x - touchPtr[2].x) * (touchPtr[0].y - touchPtr[2].y)) ;

    if( matrixPtr->Divider == 0 )
    {
        retValue = 0 ;
    }
    else
    {
        matrixPtr->An = ((lcdPtr[0].x - lcdPtr[2].x) * (touchPtr[1].y - touchPtr[2].y)) - 
                        ((lcdPtr[1].x - lcdPtr[2].x) * (touchPtr[0].y - touchPtr[2].y)) ;

        matrixPtr->Bn = ((touchPtr[0].x - touchPtr[2].x) * (lcdPtr[1].x - lcdPtr[2].x)) - 
                        ((lcdPtr[0].x - lcdPtr[2].x) * (touchPtr[1].x - touchPtr[2].x)) ;

        matrixPtr->Cn = (touchPtr[2].x * lcdPtr[1].x - touchPtr[1].x * lcdPtr[2].x) * touchPtr[0].y +
                        (touchPtr[0].x * lcdPtr[2].x - touchPtr[2].x * lcdPtr[0].x) * touchPtr[1].y +
                        (touchPtr[1].x * lcdPtr[0].x - touchPtr[0].x * lcdPtr[1].x) * touchPtr[2].y ;

        matrixPtr->Dn = ((lcdPtr[0].y - lcdPtr[2].y) * (touchPtr[1].y - touchPtr[2].y)) - 
                        ((lcdPtr[1].y - lcdPtr[2].y) * (touchPtr[0].y - touchPtr[2].y)) ;
    
        matrixPtr->En = ((touchPtr[0].x - touchPtr[2].x) * (lcdPtr[1].y - lcdPtr[2].y)) - 
                        ((lcdPtr[0].y - lcdPtr[2].y) * (touchPtr[1].x - touchPtr[2].x)) ;

        matrixPtr->Fn = (touchPtr[2].x * lcdPtr[1].y - touchPtr[1].x * lcdPtr[2].y) * touchPtr[0].y +
                        (touchPtr[0].x * lcdPtr[2].y - touchPtr[2].x * lcdPtr[0].y) * touchPtr[1].y +
                        (touchPtr[1].x * lcdPtr[0].y - touchPtr[0].x * lcdPtr[1].y) * touchPtr[2].y ;
    }
 
    return( retValue ) ;

}


void Touch_Calibrate(bool skipCheck)
{
  if ((*(__IO uint16_t*)(MATRIX_OPTION_FLASH_ADDR)) == MATRIX_SAVED_TO_FLASH && !skipCheck) {
    Touch_getMatrix();
  } else {
    unsigned char press;
    
    POINT screenSample[3];   //array of input points
    POINT displaySample[3] = {{32,24},{160,215},{287,120}};  //array of expected correct answers  TS.getMatrix();
    POINT capturePoint;      //array of valid input points

    Lcd_Clear(BLACK);
    Lcd_Text(20,110, "Please calibrate the Touch Screen...",36,WHITE,BLACK);
    while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) {}  // Loop while touch panel is touched, so we are sure it first start calibrating when not touched
    DelayMS(2000);
    Lcd_Clear(BLACK);
  
    Lcd_Text(0,0, "Calibrate", 9, WHITE, BLACK);
    u8 i;
    for (i=0; i<3; i++)
    {
      // draw touch point    
      Lcd_Circle(displaySample[i].x, displaySample[i].y , 4, RED, 0);
 
      press = 0;
      screenPoint.x = 0;
      screenPoint.y = 0;
      while(GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)) {}  // Loop while touch panel is NOT touch
      DelayMS(1);
    
      // got a point
      Touch_getAvarage();
      screenSample[i].x = xAvg;
      screenSample[i].y = yAvg;

      // mark complete point
      
      Lcd_Circle(displaySample[i].x, displaySample[i].y,3, WHITE, 0);
      DelayMS(100);
      Lcd_Circle(displaySample[i].x, displaySample[i].y,2, WHITE, 0);
      DelayMS(100);
      Lcd_Circle(displaySample[i].x, displaySample[i].y,1, WHITE, 0);
      DelayMS(300);    
      Lcd_Circle(displaySample[i].x, displaySample[i].y,4, WHITE, 0);
      DelayMS(100);
      Lcd_Circle(displaySample[i].x, displaySample[i].y,3, BLACK, 0);
      DelayMS(100);
      Lcd_Circle(displaySample[i].x, displaySample[i].y,2, BLACK, 0);
      DelayMS(100);
      Lcd_Circle(displaySample[i].x, displaySample[i].y,1, BLACK, 0);
      
      while(!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)) {}  // Loop while touch panel IS touched
      DelayMS(250);
     
    }

    Lcd_Clear(BLACK);
    Lcd_Text(40,110, "Saving Calibration data...", 26, WHITE, BLACK);
    calibrationMatrix(&displaySample[0], &screenSample[0], &matrix);  // calibration
    TouchScreenIScalibrated = 1;
    Touch_setMatrix();   // save matrix to eeprom  - not implemented yet
    Lcd_Clear(BLACK);
    Lcd_Text(110,110, "Calibrated", 10, WHITE, BLACK);
    DelayMS(1000);
  }
}

void Touch_ReCalibrate(void)
{ 
  TouchScreenIScalibrated = 0;
  SaveSettingsToFlash();
  Touch_Calibrate(1);
}

void DelayMS(vu32 nCount)
{
  nCount = nCount * 2000;
  for(; nCount != 0; nCount--);
}

void DelayUS(vu32 nCount)
{
  for(; nCount != 0; nCount--);
}

void Touch_screenToDisplay(void)
{
    Touch_getAvarage();
    xRealpos = xAvg;
    yRealpos = yAvg;
    while(!Touch_compare) {}
	// calculate matrix
	displayPoint.x = ((matrix.An * xRealpos) + (matrix.Bn * yRealpos) + matrix.Cn) / matrix.Divider;
	displayPoint.y = ((matrix.Dn * xRealpos) + (matrix.En * yRealpos) + matrix.Fn) / matrix.Divider;
}

void Touch_getAvarage(void)
{
  u8 count;
  xAvg = Read_Y();
  yAvg = Read_X();

  count = 0;
  while(!GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) && count <= 50)
    {
      xAvg += Read_Y();
      xAvg >>= 1;
      yAvg += Read_X();
      yAvg >>= 1;
      DelayUS(100);
      count++;     
    }
}    

u8 Touch_compare(void)
{
  Touch_getAvarage();
  if (xRealpos != xAvg || yRealpos != yAvg) {
    return 0;
    Touch_getAvarage();
    xRealpos = xAvg;
    yRealpos = yAvg;
  } else {
    Touch_getAvarage();
    if (xRealpos != xAvg || yRealpos != yAvg) {
      return 0;
      Touch_getAvarage();
      xRealpos = xAvg;
      yRealpos = yAvg;
    } else {
      return 1;
    }
  }
}
    

void Touch_getMatrix(void)
{
    uint16_t *ptr; // Create a pointer
    ptr = &matrix; // Set the pointer to the adress of the MATRIX variable

    int i;
    for (i = 0; i < sizeof(MATRIX)/2; i++) {
	  *ptr = (*(__IO uint16_t*)(MATRIX_FLASH_ADDR+(i*2)));
      ptr++;
    }
}

void Touch_setMatrix(void)
{
  SaveSettingsToFlash();
}