#include "stm32f10x.h"

/* _____PUBLIC DEFINE_____________________________________________________ */
typedef struct Point
{
	int x;
	int y;
} POINT;

typedef struct Matrix
{
	long An;
	long Bn;
	long Cn;
	long Dn;
	long En;
	long Fn;
	long Divider;
} MATRIX;

// FLASH define
#define MATRIX_SAVED_TO_FLASH 0x1234
#define MATRIX_OPTION_FLASH_ADDR	0x7F806	// address in flash to tell if matrix is stored
#define MATRIX_FLASH_ADDR	0x7F808	// address in flash to keep matrix variable

/* _____DEFINE MACRO_________________________________________________________ */

POINT screenPoint;		// touch screen point
POINT displayPoint;		// display(LCD) view point
MATRIX matrix;

bool TouchScreenIScalibrated;

long xAvg, yAvg;
long xRealpos, yRealpos;
void Touch_getAvarage(void);
void Touch_screenToDisplay(void);
void Touch_Calibrate(bool skipCheck);
void Touch_ReCalibrate(void);
u8 Touch_compare(void);