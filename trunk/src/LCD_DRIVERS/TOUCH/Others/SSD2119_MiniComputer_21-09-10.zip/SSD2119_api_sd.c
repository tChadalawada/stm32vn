#include "stm32f10x.h"
#include "SSD2119.h"
#include "SSD2119_api.h"
#include "SSD2119_api_sd.h"
#include <efs.h>
#include <ls.h>
#include <stdio.h>
#include <string.h>

signed char DispPic240_320_SD(File* file2,FileSystem *fs2,char* filename2)
{

	u32 temp;
    u16 compareColor;
    Two8BitTo16Bit convert;
    unsigned short e;
    unsigned char img_buffer[4];

  // Open file for reading
  if (file_fopen(file2,fs2,filename2,'r')!=0){
    return(-1); // Error
  } else {
	Lcd_SetCursor(0x00, 0x0000);
	//Lcd_WriteReg(0x0050,0x00);//ˮƽ GRAM��ʼλ��
	//Lcd_WriteReg(0x0051,239);//ˮƽGRAM��ֹλ��
	//Lcd_WriteReg(0x0052,0);//��ֱGRAM��ʼλ��
	//Lcd_WriteReg(0x0053,319);//��ֱGRAM��ֹλ��   
	Lcd_WR_Start();
	//Set_Rs;
  
	for (temp = 2; temp < 240*320 + 2;)
	{  
        e=file_fread(file2,2*temp,2,img_buffer);
        convert.U8[1] = img_buffer[0];
        convert.U8[0] = img_buffer[1];
        //compareColor = convert.U16;
        //while (e=file_fread(file2,1*temp,2,img_buffer) < 2) { }
        //convert.U8[1] = img_buffer[0];
        //convert.U8[0] = img_buffer[1];
        
        //if (compareColor == convert.U16) {
		  Lcd_WriteData(convert.U16);
		  Clr_nWr;
		  Set_nWr;
          temp++;
        //}
	}
Lcd_WR_End();

    // Close file
    file_fclose(file2);
    return(0); // Success
  }

//==============================  
}

signed char DispPic240_320_SD_Fast(File* file2,FileSystem *fs2,char* filename2) // This is using a larger buffer, so it uses more RAM!
{

	u8 temp;
    u8 y;
    u16 x;
    u16 compareColor;
    Two8BitTo16Bit convert;
    unsigned short e;
    unsigned char img_buffer[64];

  // Open file for reading
  if (file_fopen(file2,fs2,filename2,'r')!=0){
    return(-1); // Error
  } else {
	Lcd_SetCursor(0x00, 0x0000);
	//Lcd_WriteReg(0x0050,0x00);//ˮƽ GRAM��ʼλ��
	//Lcd_WriteReg(0x0051,239);//ˮƽGRAM��ֹλ��
	//Lcd_WriteReg(0x0052,0);//��ֱGRAM��ʼλ��
	//Lcd_WriteReg(0x0053,319);//��ֱGRAM��ֹλ��   
	Lcd_WR_Start();
	//Set_Rs;
  
    for (y = 0; y < 240; y++) {
      for (temp = 0; temp < 10; temp++) {
        e=file_fread(file2,((640*y)+(64*temp)+4),64,img_buffer);
	    for (x = 0; x < 32; x++) {	  
          convert.U8[1] = img_buffer[2*x];
          convert.U8[0] = img_buffer[2*x+1];
		  Lcd_WriteData(convert.U16);
		  Clr_nWr;
		  Set_nWr;        
        }
      }
	}
Lcd_WR_End();

    // Close file
    file_fclose(file2);
    return(0); // Success
  }

//==============================  
}

//signed char DispPic_SD(u16 x0, u16 y0, File* file2,FileSystem *fs2,char* filename2)
signed char DispPic_SD(u16 x0, u16 y0, char* filename2)
{

// SD card variables
EmbeddedFileSystem efs2;
File file2;

	u32 temp;
    u32  i;
    u32 difference;
    
    u16 x1;
    u16 y1;
    u16 imageWidth;
    u16 imageHeight;

    u8 errorCount;
    errorCount = 0;
    
    Two8BitTo16Bit convert;
    unsigned short e;
    unsigned char img_buffer[4];

  if(efs_init(&efs2,0)!=0){
    return(-1); // Error
  } else {  
    // Open file for reading
    if (file_fopen(&file2,&efs2.myFs,filename2,'r')!=0){
      return(-1); // Error
    } else {
  
         
      // Read only 4 bytes from file, starting from position 0, put that into buffer and print content
      e=file_fread(&file2,0,4,img_buffer);
      convert.U8[1] = img_buffer[0];
      convert.U8[0] = img_buffer[1];
      imageWidth = convert.U16;
      x1 = imageWidth + x0;    
      if (imageWidth > 320) { return(-1); } // Error  
 
      convert.U8[1] = img_buffer[2];
      convert.U8[0] = img_buffer[3];
      imageHeight = convert.U16;
      y1 = imageHeight + y0;
      if (imageHeight > 240) { return(-1); } // Error  
          
    
      temp = 2;
      difference = x1-x0;
      while (y0<=y1-1) {
        //efs_init(&efs2,0);
        Lcd_SetCursor(x0, y0);
        Lcd_WR_Start();
        for(i=0;i<=imageWidth-1;i++) {  //Write all pixels to ram, and then update display (fast) 
          e=file_fread(&file2,2*temp,2,img_buffer);      
          convert.U8[1] = img_buffer[0];
          convert.U8[0] = img_buffer[1];  
          
          Lcd_WriteData(convert.U16);
          Clr_nWr
          Set_nWr;
          
          temp++;                  
        } 
        y0++;
        Lcd_WR_End();
      }

      // Close file
      file_fclose(&file2);
      fs_umount(&efs2.myFs);
      return(0); // Success
    }
  }
//==============================  
}

signed char DispPic_SD_Fast(u16 x0, u16 y0, char* filename2)
{
    // SD card variables
    EmbeddedFileSystem efs2;
    File file2;

	u8 temp;
    u32  i;
    u32 difference;
    u32 imageAdress;
    
    u16 x1;
    u16 y1;
    u16 imageWidth;
    u16 imageHeight;

    u8 errorCount;
    errorCount = 0;
    
    Two8BitTo16Bit convert;
    unsigned short e;

    unsigned char img_buffer[65];

  if(efs_init(&efs2,0)!=0){
    return(-1); // Error
  } else {  
    // Open file for reading
    if (file_fopen(&file2,&efs2.myFs,filename2,'r')!=0){
      return(-1); // Error
    } else {
  
         
      // Read only 4 bytes from file, starting from position 0, put that into buffer and print content
      e=file_fread(&file2,0,4,img_buffer);
      convert.U8[1] = img_buffer[0];
      convert.U8[0] = img_buffer[1];
      imageWidth = convert.U16;
      x1 = imageWidth + x0;    
      if (imageWidth > 320) { return(-1); } // Error  
 
      convert.U8[1] = img_buffer[2];
      convert.U8[0] = img_buffer[3];
      imageHeight = convert.U16;
      y1 = imageHeight + y0;
      if (imageHeight > 240) { return(-1); } // Error  
          
      efs_init(&efs2,0);
      imageAdress = 2;
      temp = 64;
      difference = x1-x0;
      while (y0<=y1-1) {
        Lcd_SetCursor(x0, y0);
        Lcd_WR_Start();
      
        for(i=0;i<=imageWidth-1;i++) {  //Write all pixels to ram, and then update display (fast) 
          if (temp == 64) {
            e=file_fread(&file2,2*imageAdress,65,img_buffer); 
            temp = 0;
          }
          
          convert.U8[1] = img_buffer[temp];
          convert.U8[0] = img_buffer[temp+1];
          Lcd_WriteData(convert.U16);
          Clr_nWr
          Set_nWr;
          
          temp = temp + 2;   
          imageAdress++;        
        } 
        y0++;
        Lcd_WR_End();
      }

      // Close file
      file_fclose(&file2);
      fs_umount(&efs2.myFs);
      return(0); // Success
    }
  }
}