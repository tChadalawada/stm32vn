#include "stm32f10x.h"

/*********************************************************************
* The button color scheme 
*
*********************************************************************/
/* Standard color scheme (Microchip Graphics Library)
#define Color0 0x4C7F // (48,8C,F8)  - When not pressed
#define Color1 0xFDC9 // (F8,B8,48)  - When pressed
#define TextColor0 0xFDC9 // (F8,B8,48)  - When not pressed
#define TextColor1 0x001F // (0,0,F8)  - When pressed
#define ColorDisabled 0xD71E // (D8,E0,F0)  - When disabled
#define EmbossDkColor 0x181C // (18,0,E0)  - 3D effect, right bottom corner color
#define EmbossLtColor 0xAEDD // (A8,D8,E8)  - 3D effect, left top corner color
#define TextColorDisabled 0xBDD7 // (B8,B8,B8)  - When disabled
#define CommonBkColor 0x0000 // (00,00,00)  - Background where the button is placed
*/

// Red color scheme
#define Color0 0xF800 // (F8,00,00)  - When not pressed
#define Color1 0xF800 // (F8,00,00)  - When not pressed
//#define Color1 0xFFFF // (F8,FC,F8)  - When pressed
#define TextColor0 0xFFFF // (F8,FC,F8)  - When not pressed
#define TextColor1 0xFFFF // (F8,FC,F8)  - When not pressed
//#define TextColor1 0xF800 // (F8,00,00)  - When pressed
#define ColorDisabled 0xA000 // (A0,00,00)  - When disabled
#define EmbossDkColor 0x4800 // (48,00,00)  - 3D effect, right bottom corner color
#define EmbossLtColor 0xFC92 // (F8,90,90)  - 3D effect, left top corner color
#define TextColorDisabled 0xC618 // (C0,C0,C0)  - When disabled
#define CommonBkColor 0xC618 // (C0,C0,C0)  - Background where the button is placed


/*********************************************************************
* Object States Definition: 
*********************************************************************/
    #define BTN_FOCUSED     0x0001  // Bit for focus state.
    #define BTN_DISABLED    0x0002  // Bit for disabled state.
    #define BTN_PRESSED     0x0004  // Bit for press state.
    #define BTN_TOGGLE      0x0008  // Bit to indicate button will have a toggle behavior.
    #define BTN_TEXTRIGHT   0x0010  // Bit to indicate text is right aligned.
    #define BTN_TEXTLEFT    0x0020  // Bit to indicate text is left aligned.
    #define BTN_TEXTBOTTOM  0x0040  // Bit to indicate text is top aligned.
    #define BTN_TEXTTOP     0x0080  // Bit to indicate text is bottom aligned.

// Note that if bits[7:4] are all zero text is centered.
    #define BTN_DRAW_FOCUS  0x2000  // Bit to indicate focus must be redrawn.
    #define BTN_DRAW        0x4000  // Bit to indicate button must be redrawn.
    #define BTN_HIDE        0x8000  // Bit to indicate button must be removed from screen.
    #define BTN_REMOVE      0x8000
    
typedef struct
{
  bool enabled;
  u16 left;
  u16 top;
  u16 right;
  u16 bottom;
  u16 radius;
} BUTTON;   

#define MaxButtons 10
BUTTON buttons[MaxButtons];

void DrawButton(u8 buttonID, u16 buttonState, u8 *pText, u8 textLength);
void CreateButton(u8 buttonID, u16 left, u16 top, u16 right, u16 bottom, u16 radius, u16 buttonState, u8 *pText, u8 textLength);
u8 ButtonPressed(u8 buttonID, u16 TouchX, u16 TouchY);

/*********************************************************************
* Overview: Defines the parameters required for a button Object.
* 			The following relationships of the parameters determines
*			the general shape of the button:
* 			1. Width is determined by right - left.
*			2. Height is determined by top - bottom.
*			3. Radius - specifies if the button will have a rounded 
*						edge. If zero then the button will have 
*						sharp (cornered) edge.
*			4. If 2*radius = height = width, the button is a circular button.
*
*********************************************************************/

WORD BtnDraw(SHORT left, SHORT top, SHORT right, SHORT bottom, SHORT radius, SHORT buttonState, u8 *pText, u8 textLength);
WORD GOLPanelDrawTsk(SHORT _rpnlX1, SHORT _rpnlY1, SHORT _rpnlX2, SHORT _rpnlY2, SHORT _rpnlR, WORD _rpnlFaceColor, WORD _rpnlEmbossLtColor, WORD _rpnlEmbossDkColor, WORD _rpnlEmbossSize);