#include "stm32f10x.h"
#include "SSD2119.h"
#include "SSD2119_api.h"
#include "MicrochipGraphics.h"
//#include "MicrochipButton.h"

/* */
WORD Line(SHORT x1, SHORT y1, SHORT x2, SHORT y2, SHORT _lineType, BYTE _lineThickness, u16 color)
{
    SHORT   deltaX, deltaY;
    SHORT   error, stepErrorLT, stepErrorGE;
    SHORT   stepX, stepY;
    SHORT   steep;
    SHORT   temp;
    SHORT   style, type;

    // Move cursor
    Lcd_SetCursor(x2, y2);

    if(x1 == x2)
    {
        if(y1 > y2)
        {
            temp = y1;
            y1 = y2;
            y2 = temp;
        }

        style = 0;
        type = 1;
        for(temp = y1; temp < y2 + 1; temp++)
        {
            if((++style) == _lineType)
            {
                type ^= 1;
                style = 0;
            }

            if(type)
            {
                Lcd_SetPoint(x1, temp, color);
                if(_lineThickness)
                {
                    Lcd_SetPoint(x1 + 1, temp, color);
                    Lcd_SetPoint(x1 - 1, temp, color);
                }
            }
        }

        return (1);
    }

    if(y1 == y2)
    {
        if(x1 > x2)
        {
            temp = x1;
            x1 = x2;
            x2 = temp;
        }

        style = 0;
        type = 1;
        for(temp = x1; temp < x2 + 1; temp++)
        {
            if((++style) == _lineType)
            {
                type ^= 1;
                style = 0;
            }

            if(type)
            {
                Lcd_SetPoint(temp, y1, color);
                if(_lineThickness)
                {
                    Lcd_SetPoint(temp, y1 + 1, color);
                    Lcd_SetPoint(temp, y1 - 1, color);
                }
            }
        }

        return (1);
    }

    stepX = 0;
    deltaX = x2 - x1;
    if(deltaX < 0)
    {
        deltaX = -deltaX;
        --stepX;
    }
    else
    {
        ++stepX;
    }

    stepY = 0;
    deltaY = y2 - y1;
    if(deltaY < 0)
    {
        deltaY = -deltaY;
        --stepY;
    }
    else
    {
        ++stepY;
    }

    steep = 0;
    if(deltaX < deltaY)
    {
        ++steep;
        temp = deltaX;
        deltaX = deltaY;
        deltaY = temp;
        temp = x1;
        x1 = y1;
        y1 = temp;
        temp = stepX;
        stepX = stepY;
        stepY = temp;
        Lcd_SetPoint(y1, x1, color);
    }
    else
    {
        Lcd_SetPoint(x1, y1, color);
    }

    // If the current error greater or equal zero
    stepErrorGE = deltaX << 1;

    // If the current error less than zero
    stepErrorLT = deltaY << 1;

    // Error for the first pixel
    error = stepErrorLT - deltaX;

    style = 0;
    type = 1;

    while(--deltaX >= 0)
    {
        if(error >= 0)
        {
            y1 += stepY;
            error -= stepErrorGE;
        }

        x1 += stepX;
        error += stepErrorLT;

        if((++style) == _lineType)
        {
            type ^= 1;
            style = 0;
        }

        if(type)
        {
            if(steep)
            {
                Lcd_SetPoint(y1, x1, color);
                if(_lineThickness)
                {
                    Lcd_SetPoint(y1 + 1, x1, color);
                    Lcd_SetPoint(y1 - 1, x1, color);
                }
            }
            else
            {
                Lcd_SetPoint(x1, y1, color);
                if(_lineThickness)
                {
                    Lcd_SetPoint(x1, y1 + 1, color);
                    Lcd_SetPoint(x1, y1 - 1, color);
                }
            }
        }
    }   // end of while

    return (1);
}


/*********************************************************************
* Function: WORD Bar(SHORT left, SHORT top, SHORT right, SHORT bottom)
*
* PreCondition: none
*
* Input: left,top - top left corner coordinates,
*        right,bottom - bottom right corner coordinates
*
* Output: For NON-Blocking configuration:
*         - Returns 0 when device is busy and the shape is not yet completely drawn.
*         - Returns 1 when the shape is completely drawn.
*         For Blocking configuration:
*         - Always return 1.
*
* Side Effects: none
*
* Overview: draws rectangle filled with current color
*
* Note: none
*
********************************************************************/
/* */
WORD Bar(SHORT left, SHORT top, SHORT right, SHORT bottom, u16 color)
{
    SHORT   x, y;

    for(y = top; y < bottom + 1; y++)
        for(x = left; x < right + 1; x++)
            Lcd_SetPoint(x, y, color);

    return (1);
}

/*********************************************************************
* Function: WORD Bevel(SHORT x1, SHORT y1, SHORT x2, SHORT y2, SHORT rad)
*
* PreCondition: None
*
* Input: x1, y1 - coordinate position of the upper left center of the 
* 				  circle that draws the rounded corners,
*		 x2, y2 - coordinate position of the lower right center of the 
* 				  circle that draws the rounded corners,
*        rad - defines the redius of the circle,
*
* Output: For NON-Blocking configuration:
*         - Returns 0 when device is busy and the shape is not yet completely drawn.
*         - Returns 1 when the shape is completely drawn.
*         For Blocking configuration:
*         - Always return 1.
*
* Overview: Draws a beveled figure on the screen. 
*           For a pure circular object x1 = x2 and y1 = y2. 
*           For a rectangular object radius = 0.
*
* Note: none
*
********************************************************************/
WORD Bevel(SHORT x1, SHORT y1, SHORT x2, SHORT y2, SHORT rad, SHORT _lineType, BYTE _lineThickness, u16 color)
{
    SHORT       style, type, xLimit, xPos, yPos, error;
    DWORD_VAL   temp;

    temp.Val = SIN45 * rad;
    xLimit = temp.w[1] + 1;
    temp.Val = (DWORD) (ONEP25 - ((LONG) rad << 16));
    error = (SHORT) (temp.w[1]);
    yPos = rad;

    style = 0;
    type = 1;

    if(rad)
    {
        for(xPos = 0; xPos <= xLimit; xPos++)
        {
            if((++style) == _lineType)
            {
                type ^= 1;
                style = 0;
            }

            if(type)
            {
                Lcd_SetPoint(x2 + xPos, y1 - yPos, color);         // 1st quadrant
                Lcd_SetPoint(x2 + yPos, y1 - xPos, color);
                Lcd_SetPoint(x2 + xPos, y2 + yPos, color);         // 2nd quadrant
                Lcd_SetPoint(x2 + yPos, y2 + xPos, color);
                Lcd_SetPoint(x1 - xPos, y2 + yPos, color);         // 3rd quadrant
                Lcd_SetPoint(x1 - yPos, y2 + xPos, color);
                Lcd_SetPoint(x1 - yPos, y1 - xPos, color);         // 4th quadrant
                Lcd_SetPoint(x1 - xPos, y1 - yPos, color);

                if(_lineThickness)
                {
                    Lcd_SetPoint(x2 + xPos, y1 - yPos - 1, color); // 1st quadrant
                    Lcd_SetPoint(x2 + xPos, y1 - yPos + 1, color);
                    Lcd_SetPoint(x2 + yPos + 1, y1 - xPos, color);
                    Lcd_SetPoint(x2 + yPos - 1, y1 - xPos, color);
                    Lcd_SetPoint(x2 + xPos, y2 + yPos - 1, color); // 2nd quadrant
                    Lcd_SetPoint(x2 + xPos, y2 + yPos + 1, color);
                    Lcd_SetPoint(x2 + yPos + 1, y2 + xPos, color);
                    Lcd_SetPoint(x2 + yPos - 1, y2 + xPos, color);
                    Lcd_SetPoint(x1 - xPos, y2 + yPos - 1, color); // 3rd quadrant
                    Lcd_SetPoint(x1 - xPos, y2 + yPos + 1, color);
                    Lcd_SetPoint(x1 - yPos + 1, y2 + xPos, color);
                    Lcd_SetPoint(x1 - yPos - 1, y2 + xPos, color);
                    Lcd_SetPoint(x1 - yPos + 1, y1 - xPos, color); // 4th quadrant
                    Lcd_SetPoint(x1 - yPos - 1, y1 - xPos, color);
                    Lcd_SetPoint(x1 - xPos, y1 - yPos + 1, color);
                    Lcd_SetPoint(x1 - xPos, y1 - yPos - 1, color);
                }
            }

            if(error > 0)
            {
                yPos--;
                error += 5 + ((xPos - yPos) << 1);
            }
            else
                error += 3 + (xPos << 1);
        }
    }
    // Must use lines here since this can also be used to draw focus of round buttons
    if(x2 - x1)
    {
        while(!Line(x1, y1 - rad, x2, y1 - rad, _lineType, _lineThickness, color));

        // draw top
    }

    if(y2 - y1)
    {
        while(!Line(x1 - rad, y1, x1 - rad, y2, _lineType, _lineThickness, color));

        // draw left
    }

    if((x2 - x1) || (y2 - y1))
    {
        while(!Line(x2 + rad, y1, x2 + rad, y2, _lineType, _lineThickness, color));

        // draw right
        while(!Line(x1, y2 + rad, x2, y2 + rad, _lineType, _lineThickness, color));

        // draw bottom
    }

    return (1);
}

/*********************************************************************
* Function: WORD FillBevel(SHORT x1, SHORT y1, SHORT x2, SHORT y2, SHORT rad)
*
* PreCondition: None
*
* Input: x1, y1 - coordinate position of the upper left center of the 
* 				  circle that draws the rounded corners,
*		 x2, y2 - coordinate position of the lower right center of the 
* 				  circle that draws the rounded corners,
*        rad - defines the redius of the circle,
*
* Output: For NON-Blocking configuration:
*         - Returns 0 when device is busy and the shape is not yet completely drawn.
*         - Returns 1 when the shape is completely drawn.
*         For Blocking configuration:
*         - Always return 1.
*
* Overview: Draws a filled beveled figure on the screen. 
*           For a filled circular object x1 = x2 and y1 = y2. 
*           For a filled rectangular object radius = 0.
*
* Note: none
*
********************************************************************/
WORD FillBevel(SHORT x1, SHORT y1, SHORT x2, SHORT y2, SHORT rad, u16 color)
{
    #ifndef USE_NONBLOCKING_CONFIG

    SHORT       yLimit, xPos, yPos, err;
    SHORT       xCur, yCur, yNew;
    DWORD_VAL   temp;

    // note that octants here is defined as:
    // from yPos=-radius, xPos=0 in the clockwise direction octant 1 to 8 are labeled
    // assumes an origin at 0,0. Quadrants are defined in the same manner
    if(rad)
    {
        temp.Val = SIN45 * rad;
        yLimit = temp.w[1];
        temp.Val = (DWORD) (ONEP25 - ((LONG) rad << 16));
        err = (SHORT) (temp.w[1]);
        xPos = rad;
        yPos = 0;

        xCur = xPos;
        yCur = yPos;
        yNew = yPos;

        while(yPos <= yLimit)
        {

            // Drawing of the rounded panel is done only when there is a change in the
            // x direction. Bars are drawn to be efficient.
            // detect changes in the x position. Every change will mean a bar will be drawn
            // to cover the previous area. y1New records the last position of y before the
            // change in x position.
            // y1New records the last y position
            yNew = yPos;

            if(err > 0)
            {
                xPos--;
                err += 5 + ((yPos - xPos) << 1);
            }
            else
                err += 3 + (yPos << 1);
            yPos++;

            if(xCur != xPos)
            {

                // 6th octant to 3rd octant
                Bar(x1 - xCur, y2 + yCur, x2 + xCur, y2 + yNew, color);

                // 5th octant to 4th octant
                Bar(x1 - yNew, y2 + xPos, x2 + yNew, y2 + xCur, color);

                // 8th octant to 1st octant
                Bar(x1 - yNew, y1 - xCur, x2 + yNew, y1 - xPos, color);

                // 7th octant to 2nd octant
                Bar(x1 - xCur, y1 - yNew, x2 + xCur, y1 - yCur, color);

                // update current values
                xCur = xPos;
                yCur = yPos;
            }
        }
    }

    // this covers both filled rounded object and filled rectangle.
    if((x2 - x1) || (y2 - y1))
        Bar(x1 - rad, y1, x2 + rad, y2, color);
    return (1);
    #else

    typedef enum
    {
        BEGIN,
        CHECK,
        Q8TOQ1,
        Q7TOQ2,
        Q6TOQ3,
        Q5TOQ4,
        WAITFORDONE,
        FACE
    } FILLCIRCLE_STATES;

    DWORD_VAL temp;
    static LONG err;
    static SHORT yLimit, xPos, yPos;
    static SHORT xCur, yCur, yNew;

    static FILLCIRCLE_STATES state = BEGIN;

    while(1)
    {
        switch(state)
        {
            case BEGIN:
                if(!rad)
                {   // no radius object is a filled rectangle
                    state = FACE;
                    break;
                }

                // compute variables
                temp.Val = SIN45 * rad;
                yLimit = temp.w[1];
                temp.Val = (DWORD) (ONEP25 - ((LONG) rad << 16));
                err = (SHORT) (temp.w[1]);
                xPos = rad;
                yPos = 0;
                xCur = xPos;
                yCur = yPos;
                yNew = yPos;
                state = CHECK;

            case CHECK:
                bevel_fill_check : if(yPos > yLimit)
                {
                    state = FACE;
                    break;
                }

                // y1New records the last y position
                yNew = yPos;

                // calculate the next value of x and y
                if(err > 0)
                {
                    xPos--;
                    err += 5 + ((yPos - xPos) << 1);
                }
                else
                    err += 3 + (yPos << 1);
                yPos++;
                state = Q6TOQ3;

            case Q6TOQ3:
                if(xCur != xPos)
                {

                    // 6th octant to 3rd octant
                    if(Bar(x1 - xCur, y2 + yCur, x2 + xCur, y2 + yNew, color) == 0)
                        return (0);
                    state = Q5TOQ4;
                    break;
                }

                state = CHECK;
                goto bevel_fill_check;

            case Q5TOQ4:

                // 5th octant to 4th octant
                if(Bar(x1 - yNew, y2 + xPos, x2 + yNew, y2 + xCur, color) == 0)
                    return (0);
                state = Q8TOQ1;
                break;

            case Q8TOQ1:

                // 8th octant to 1st octant
                if(Bar(x1 - yNew, y1 - xCur, x2 + yNew, y1 - xPos, color) == 0)
                    return (0);
                state = Q7TOQ2;
                break;

            case Q7TOQ2:

                // 7th octant to 2nd octant
                if(Bar(x1 - xCur, y1 - yNew, x2 + xCur, y1 - yCur, color) == 0)
                    return (0);

                // update current values
                xCur = xPos;
                yCur = yPos;
                state = CHECK;
                break;

            case FACE:
                if((x2 - x1) || (y2 - y1))
                {
                    if(Bar(x1 - rad, y1, x2 + rad, y2, color) == 0)
                        return (0);
                    state = WAITFORDONE;
                }
                else
                {
                    state = BEGIN;
                    return (1);
                }

            case WAITFORDONE:
                state = BEGIN;
                return (1);
        }           // end of switch
    }               // end of while
    #endif // end of USE_NONBLOCKING_CONFIG
}


/*********************************************************************
* Function: WORD Arc(SHORT xL, SHORT yT, SHORT xR, SHORT yB, SHORT r1, SHORT r2, BYTE octant);
*
* PreCondition: none
*
* Input: xL, yT - location of the upper left center in the x,y coordinate
*		 xR, yB - location of the lower right left center in the x,y coordinate
*		 r1, r2 - the two concentric circle radii, r1 as the radius 
*				  of the smaller circle and and r2 as the radius of the 
*				  larger circle.
*		 octant - bitmask of the octant that will be drawn.
*				  Moving in a clockwise direction from x = 0, y = +radius
*                 bit0 : first octant 	bit4 : fifth octant
*                 bit1 : second octant  bit5 : sixth octant
*                 bit2 : third octant   bit6 : seventh octant
*                 bit3 : fourth octant  bit7 : eigth octant
*
* Output: For NON-Blocking configuration:
*         - Returns 0 when device is busy and the shape is not yet completely drawn.
*         - Returns 1 when the shape is completely drawn.
*         For Blocking configuration:
*         - Always return 1.
*
* Side Effects: none
*
* Overview: Draws the octant arc of a beveled figure with given centers, radii
*			and octant mask. When r1 is zero and r2 has some value, a filled 
*			circle is drawn; when the radii have values, an arc of
*			thickness (r2-r1) is drawn; when octant = 0xFF, a full ring 
*			is drawn. When r1 and r2 are zero, a rectangular object is drawn, where
*			xL, yT specifies the left top corner; xR, yB specifies the right bottom
*			corner.
*
* Note: none
*
********************************************************************/
WORD Arc(SHORT xL, SHORT yT, SHORT xR, SHORT yB, SHORT r1, SHORT r2, BYTE octant, u16 color)
{

    // this is using a variant of the Midpoint (Bresenham's) Algorithm
    #ifndef USE_NONBLOCKING_CONFIG

    SHORT       y1Limit, y2Limit;
    SHORT       x1, x2, y1, y2;
    SHORT       err1, err2;
    SHORT       x1Cur, y1Cur, y1New;
    SHORT       x2Cur, y2Cur, y2New;
    DWORD_VAL   temp;

    temp.Val = SIN45 * r1;
    y1Limit = temp.w[1];
    temp.Val = SIN45 * r2;
    y2Limit = temp.w[1];

    temp.Val = (DWORD) (ONEP25 - ((LONG) r1 << 16));
    err1 = (SHORT) (temp.w[1]);

    temp.Val = (DWORD) (ONEP25 - ((LONG) r2 << 16));
    err2 = (SHORT) (temp.w[1]);

    x1 = r1;
    x2 = r2;
    y1 = 0;
    y2 = 0;

    x1Cur = x1;
    y1Cur = y1;
    y1New = y1;
    x2Cur = x2;
    y2Cur = y2;
    y2New = y2;

    while(y2 <= y2Limit)
    {   // just watch for y2 limit since outer circle
        // will have greater value.
        // Drawing of the rounded panel is done only when there is a change in the
        // x direction. Bars are drawn to be efficient.
        // detect changes in the x position. Every change will mean a bar will be drawn
        // to cover the previous area. y1New records the last position of y before the
        // change in x position.
        // y1New & y2New records the last y positions, must remember this to
        // draw the correct bars (non-overlapping).
        y1New = y1;
        y2New = y2;

        if(y1 <= y1Limit)
        {
            if(err1 > 0)
            {
                x1--;
                err1 += 5;
                err1 += (y1 - x1) << 1;
            }
            else
            {
                err1 += 3;
                err1 += y1 << 1;
            }

            y1++;
        }
        else
        {
            y1++;
            if(x1 < y1)
                x1 = y1;
        }

        if(err2 > 0)
        {
            x2--;
            err2 += 5;
            err2 += (y2 - x2) << 1;
        }
        else
        {
            err2 += 3;
            err2 += y2 << 1;
        }

        y2++;

        if((x1Cur != x1) || (x2Cur != x2))
        {
            if(octant & 0x01)
            {
                Bar(xR + y2Cur, yT - x2Cur, xR + y1New, yT - x1Cur, color);    // 1st octant
            }

            if(octant & 0x02)
            {
                Bar(xR + x1Cur, yT - y1New, xR + x2Cur, yT - y2Cur, color);    // 2nd octant
            }

            if(octant & 0x04)
            {
                Bar(xR + x1Cur, yB + y1Cur, xR + x2Cur, yB + y2New, color);    // 3rd octant
            }

            if(octant & 0x08)
            {
                Bar(xR + y1Cur, yB + x1Cur, xR + y2New, yB + x2Cur, color);    // 4th octant
            }

            if(octant & 0x10)
            {
                Bar(xL - y1New, yB + x1Cur, xL - y2Cur, yB + x2Cur, color);    // 5th octant
            }

            if(octant & 0x20)
            {
                Bar(xL - x2Cur, yB + y2Cur, xL - x1Cur, yB + y1New, color);    // 6th octant
            }

            if(octant & 0x40)
            {
                Bar(xL - x2Cur, yT - y2New, xL - x1Cur, yT - y1Cur, color);    // 7th octant
            }

            if(octant & 0x80)
            {
                Bar(xL - y2New, yT - x2Cur, xL - y1Cur, yT - x1Cur, color);    // 8th octant
            }

            // update current values
            x1Cur = x1;
            y1Cur = y1;
            x2Cur = x2;
            y2Cur = y2;
        }
    }                           // end of while loop

    // draw the width and height
    if((xR - xL) || (yB - yT))
    {

        // draw right
        if(octant & 0x02)
        {
            Bar(xR + r1, yT, xR + r2, (yB + yT) >> 1, color);
        }

        if(octant & 0x04)
        {
            Bar(xR + r1, ((yB + yT) >> 1), xR + r2, yB, color);
        }

        // draw bottom
        if(octant & 0x10)
        {
            Bar(xL, yB + r1, ((xR + xL) >> 1), yB + r2, color);
        }

        if(octant & 0x08)
        {
            Bar(((xR + xL) >> 1), yB + r1, xR, yB + r2, color);
        }

        if(xR - xL)
        {

            // draw top
            if(octant & 0x80)
            {
                Bar(xL, yT - r2, ((xR + xL) >> 1), yT - r1, color);
            }

            if(octant & 0x01)
            {
                Bar(((xR + xL) >> 1), yT - r2, xR, yT - r1, color);
            }
        }

        if(yT - yB)
        {

            // draw left
            if(octant & 0x40)
            {
                Bar(xL - r2, yT, xL - r1, ((yB + yT) >> 1), color);
            }

            if(octant & 0x20)
            {
                Bar(xL - r2, ((yB + yT) >> 1), xL - r1, yB, color);
            }
        }
    }

    return (1);
    #else

    typedef enum
    {
        BEGIN,
        QUAD11,
        BARRIGHT1,
        QUAD12,
        BARRIGHT2,
        QUAD21,
        BARLEFT1,
        QUAD22,
        BARLEFT2,
        QUAD31,
        BARTOP1,
        QUAD32,
        BARTOP2,
        QUAD41,
        BARBOTTOM1,
        QUAD42,
        BARBOTTOM2,
        CHECK,
    } OCTANTARC_STATES;

    DWORD_VAL temp;

    //	LONG temp1;
    static SHORT y1Limit, y2Limit;
    static SHORT x1, x2, y1, y2;
    static SHORT err1, err2;
    static SHORT x1Cur, y1Cur, y1New;
    static SHORT x2Cur, y2Cur, y2New;
    static OCTANTARC_STATES state = BEGIN;

    while(1)
    {
        switch(state)
        {
            case BEGIN:
                temp.Val = SIN45 * r1;
                y1Limit = temp.w[1];
                temp.Val = SIN45 * r2;
                y2Limit = temp.w[1];

                temp.Val = (DWORD) (ONEP25 - ((LONG) r1 << 16));
                err1 = (SHORT) (temp.w[1]);

                temp.Val = (DWORD) (ONEP25 - ((LONG) r2 << 16));
                err2 = (SHORT) (temp.w[1]);

                x1 = r1;
                x2 = r2;
                y1 = 0;
                y2 = 0;

                x1Cur = x1;
                y1Cur = y1;
                y1New = y1;
                x2Cur = x2;
                y2Cur = y2;
                y2New = y2;
                state = CHECK;

            case CHECK:
                arc_check_state : if(y2 > y2Limit)
                {
                    state = BARRIGHT1;
                    goto arc_draw_width_height_state;
                }

                // y1New & y2New records the last y positions
                y1New = y1;
                y2New = y2;

                if(y1 <= y1Limit)
                {
                    if(err1 > 0)
                    {
                        x1--;
                        err1 += 5;
                        err1 += (y1 - x1) << 1;
                    }
                    else
                    {
                        err1 += 3;
                        err1 += y1 << 1;
                    }

                    y1++;
                }
                else
                {
                    y1++;
                    if(x1 < y1)
                        x1 = y1;
                }

                if(err2 > 0)
                {
                    x2--;
                    err2 += 5;
                    err2 += (y2 - x2) << 1;
                }
                else
                {
                    err2 += 3;
                    err2 += y2 << 1;
                }

                y2++;

                state = QUAD11;
                break;

            case QUAD11:
                if((x1Cur != x1) || (x2Cur != x2))
                {

                    // 1st octant
                    if(octant & 0x01)
                    {
                        if(Bar(xR + y2Cur, yT - x2Cur, xR + y1New, yT - x1Cur, color) == 0)
                            return (0);
                    }
                }
                else
                {
                    state = CHECK;
                    goto arc_check_state;
                }

                state = QUAD12;
                break;

            case QUAD12:

                // 2nd octant
                if(octant & 0x02)
                {
                    if(Bar(xR + x1Cur, yT - y1New, xR + x2Cur, yT - y2Cur, color) == 0)
                        return (0);
                }

                state = QUAD21;
                break;

            case QUAD21:

                // 3rd octant
                if(octant & 0x04)
                {
                    if(Bar(xR + x1Cur, yB + y1Cur, xR + x2Cur, yB + y2New, color) == 0)
                        return (0);
                }

                state = QUAD22;
                break;

            case QUAD22:

                // 4th octant
                if(octant & 0x08)
                {
                    if(Bar(xR + y1Cur, yB + x1Cur, xR + y2New, yB + x2Cur, color) == 0)
                        return (0);
                }

                state = QUAD31;
                break;

            case QUAD31:

                // 5th octant
                if(octant & 0x10)
                {
                    if(Bar(xL - y1New, yB + x1Cur, xL - y2Cur, yB + x2Cur, color) == 0)
                        return (0);
                }

                state = QUAD32;
                break;

            case QUAD32:

                // 6th octant
                if(octant & 0x20)
                {
                    if(Bar(xL - x2Cur, yB + y2Cur, xL - x1Cur, yB + y1New, color) == 0)
                        return (0);
                }

                state = QUAD41;
                break;

            case QUAD41:

                // 7th octant
                if(octant & 0x40)
                {
                    if(Bar(xL - x2Cur, yT - y2New, xL - x1Cur, yT - y1Cur, color) == 0)
                        return (0);
                }

                state = QUAD42;
                break;

            case QUAD42:

                // 8th octant
                if(octant & 0x80)
                {
                    if(Bar(xL - y2New, yT - x2Cur, xL - y1Cur, yT - x1Cur, color) == 0)
                        return (0);
                }

                // update current values
                x1Cur = x1;
                y1Cur = y1;
                x2Cur = x2;
                y2Cur = y2;
                state = CHECK;
                break;

            case BARRIGHT1:     // draw upper right
                arc_draw_width_height_state : if((xR - xL) || (yB - yT))
                {

                    // draw right
                    if(octant & 0x02)
                    {
                        if(Bar(xR + r1, yT, xR + r2, (yB + yT) >> 1, color) == 0)
                            return (0);
                    }
                }
                else
                {
                    state = BEGIN;
                    return (1);
                }

                state = BARRIGHT2;
                break;

            case BARRIGHT2:     // draw lower right
                if(octant & 0x04)
                {
                    if(Bar(xR + r1, ((yB + yT) >> 1), xR + r2, yB, color) == 0)
                        return (0);
                }

                state = BARBOTTOM1;
                break;

            case BARBOTTOM1:    // draw left bottom
                // draw bottom
                if(octant & 0x10)
                {
                    if(Bar(xL, yB + r1, ((xR + xL) >> 1), yB + r2, color) == 0)
                        return (0);
                }

                state = BARBOTTOM2;
                break;

            case BARBOTTOM2:    // draw right bottom
                if(octant & 0x08)
                {
                    if(Bar(((xR + xL) >> 1), yB + r1, xR, yB + r2, color) == 0)
                        return (0);
                }

                state = BARTOP1;
                break;

            case BARTOP1:       // draw left top
                if(xR - xL)
                {

                    // draw top
                    if(octant & 0x80)
                    {
                        if(Bar(xL, yT - r2, ((xR + xL) >> 1), yT - r1, color) == 0)
                            return (0);
                    }

                    state = BARTOP2;
                }
                else
                    state = BARLEFT1;   // no width go directly to height bar
                break;

            case BARTOP2:               // draw right top
                if(octant & 0x01)
                {
                    if(Bar(((xR + xL) >> 1), yT - r2, xR, yT - r1, color) == 0)
                        return (0);
                }

                state = BARLEFT1;
                break;

            case BARLEFT1:              // draw upper left
                if(yT - yB)
                {

                    // draw left
                    if(octant & 0x40)
                    {
                        if(Bar(xL - r2, yT, xL - r1, ((yB + yT) >> 1), color) == 0)
                            return (0);
                    }

                    state = BARLEFT2;
                }
                else
                {
                    state = BEGIN;      // no height go back to BEGIN
                    return (1);
                }

                break;

            case BARLEFT2:              // draw lower left
                if(octant & 0x20)
                {
                    if(Bar(xL - r2, ((yB + yT) >> 1), xL - r1, yB, color) == 0)
                        return (0);
                }

                state = BEGIN;
                return (1);
        }                               // end of switch
    }   // end of while
    #endif // USE_NONBLOCKING_CONFIG
}