#include "stm32f10x.h"

u16 Lcd_Color565(u32 RGB);  // RGB��ɫתΪ16λ(565)
typedef union
{
  u16 U16;
  u8 U8[2];
}ColorTypeDef;

void Lcd_Text(u16 x, u16 y, u8 *str, u16 len,u16 Color, u16 bkColor);
void Lcd_Line(u16 x0, u16 y0, u16 x1, u16 y1,u16 color);  // ����
void Lcd_Circle(u16 cx,u16 cy,u16 r,u16 color,u8 fill);  // ��԰
void Lcd_Rectangle(u16 x0, u16 y0, u16 x1, u16 y1,u16 color,u8 fill); // Slower than Lcd_ColorBox
void Lcd_Square(u16 x0, u16 y0, u16 width, u16 color,u8 fill);  // ��������
void Lcd_ClearCharBox(u16 x,u16 y,u16 color);
void Get320240PictureCode(u8* pBuffer,u32 BufferCounter,u32 BaseAddr);

void Lcd_FastRectangle(u16 x0, u16 y0, u16 x1, u16 y1,u16 color,u8 fill); // Faster than Lcd_Rectangle
void Lcd_FastSquare(u16 x0, u16 y0, u16 width, u16 color,u8 fill); // Faster than Lcd_Rectangle
void Lcd_FastClearCharBox(u16 x,u16 y,u16 color);

void DispPic320_240(const unsigned char *str);
void DispPic(u16 x0, u16 y0, const unsigned char *str);