bool Old_TouchableMenuItems;
bool Old_SingleClickMenu;

void Check_SettingsItems_Touch(u16 TouchX, u16 TouchY)
{
  u8 i;
  for (i = 0; i < 10; i++) {
    if (TouchX >= 10 && TouchX <= 275 && TouchY >= 20*i+30 && TouchY <= 20*i+30+20) {    
      while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) { GlobalMenuInterrupt(); } // Loop while touch screen is touched
  
      if (CurrentSelected == i || SingleClickMenu)
      {
        CurrentSelected = i;
        DoAction_SettingsMenu(); // Menu item was already selected, so execute!
        break;
      } else {
        CurrentSelected = i;
        break;
      }
    }
  }
}


void Settings (void)
{
  BreakNow = 0;

  CurrentSelected = 3;
  OldSelected = 3;

  Old_TouchableMenuItems = TouchableMenuItems;
  Old_SingleClickMenu = SingleClickMenu;

  MenuPage = 0;
  ChangeMenuTitle("Settings", 8);
  sprintf(buffer, "Touchable Menu Items: %0.1d", TouchableMenuItems);
  ChangeMenuItem(0, buffer, 23);
  sprintf(buffer, "Single Click Menu: %0.1d", SingleClickMenu);
  ChangeMenuItem(1, buffer, 20);
  ChangeMenuItem(2, "", 0);
  ChangeMenuItem(3, "Back", 4);
  ChangeMenuItem(4, "", 0);
  ChangeMenuItem(5, "", 0);
  ChangeMenuItem(6, "", 0);
  ChangeMenuItem(7, "", 0);
  ChangeMenuItem(8, "", 0);
  ChangeMenuItem(9, "", 0);
  DrawMenuItems();
 
while (!BreakNow) 
 {
  GlobalMenuInterrupt();

  while ((GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) && !BreakNow)
    {   
      GlobalMenuInterrupt();
    
       Touch_screenToDisplay();
       TouchX = displayPoint.x;
       TouchY = displayPoint.y; 
       
       if (TouchableMenuItems) { Check_SettingsItems_Touch(TouchX, TouchY); }
       
       if (ButtonPressed(0, TouchX, TouchY)) { 
         DrawButton(0, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }
         if (CurrentSelected > 0) {CurrentSelected--;} else { CurrentSelected = 9; }       
         DrawButton(0, 0, "", 0);
       }
  
       if (ButtonPressed(1, TouchX, TouchY)) { 
         DrawButton(1, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }        
         if (CurrentSelected < 9) {CurrentSelected++;} else { CurrentSelected = 0; }        
         DrawButton(1, 0, "", 0);        
       }
   
       if (ButtonPressed(2, TouchX, TouchY)) { 
         DrawButton(2, BTN_PRESSED, "OK", 2);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }    
         DrawButton(2, 0, "OK", 2);  // Draw the normal (un-pressed) button
         DoAction_SettingsMenu();     
       }
    }   
  }
}

void DoAction_SettingsMenu(void)
{
         switch (MenuPage) {        
         case 0:  // MenuPage 6 = Confirmation
           if (CurrentSelected == 0)
           {
             TouchableMenuItems = !TouchableMenuItems;                       
             sprintf(buffer, "Touchable Menu Items: %0.1d", TouchableMenuItems);
             ChangeMenuItem(0, buffer, 23);
             DrawMenuItems();
           }
       
           if (CurrentSelected == 1)
           {
             int test;
             SingleClickMenu = !SingleClickMenu;
             sprintf(buffer, "Single Click Menu: %0.1d", SingleClickMenu);
             ChangeMenuItem(1, buffer, 20);
             DrawMenuItems();
           }       
       
           if (CurrentSelected == 3) { 
             CurrentSelected = 7;
             OldSelected = 7;  
             if (Old_TouchableMenuItems != TouchableMenuItems || Old_SingleClickMenu != SingleClickMenu)
             {
               Lcd_Text(10+4, 20*6+30+3, "Saving Settings...", 18, WHITE, BLACK);  
               SaveSettingsToFlash();
             }
             BreakNow = 1;
             break; 
           }
         }
}     