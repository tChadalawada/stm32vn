  u8 Hour, Minutes, Seconds = 0;
  // MenuPage 0 = Hour (Tenth)
  // MenuPage 1 = Hour (Ones)
  // MenuPage 2 = Minutes (Tenth)
  // MenuPage 3 = Minutes (Ones)
  // MenuPage 4 = Seconds (Tenth)
  // MenuPage 5 = Seconds (Ones)
  // MenuPage 6 = Confirmation


void Check_ClockItems_Touch(u16 TouchX, u16 TouchY)
{
  u8 i;
  for (i = 0; i < 10; i++) {
    if (TouchX >= 10 && TouchX <= 275 && TouchY >= 20*i+30 && TouchY <= 20*i+30+20) {    
      while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) { GlobalMenuInterrupt(); } // Loop while touch screen is touched
  
      if (CurrentSelected == i || SingleClickMenu)
      {
        CurrentSelected = i;
        DoAction_ClockMenu(); // Menu item was already selected, so execute!
        break;
      } else {
        CurrentSelected = i;
        break;
      }
    }
  }
}


void SetClock (void)
{
  BreakNow = 0;

  CurrentSelected = 0;
  OldSelected = 0;

  MenuPage = 0;
  ChangeMenuTitle("Hour (Tenth)", 12);
  ChangeMenuItem(0, "0x", 2);
  ChangeMenuItem(1, "1x", 2);
  ChangeMenuItem(2, "2x", 2);
  ChangeMenuItem(3, "", 0);
  ChangeMenuItem(4, "", 0);
  ChangeMenuItem(5, "", 0);
  ChangeMenuItem(6, "", 0);
  ChangeMenuItem(7, "", 0);
  ChangeMenuItem(8, "", 0);
  ChangeMenuItem(9, "", 0);
  DrawMenuItems();
 
while (!BreakNow) 
 {
  GlobalMenuInterrupt();

  while ((GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) && !BreakNow)
    {   
      GlobalMenuInterrupt();
    
       Touch_screenToDisplay();
       TouchX = displayPoint.x;
       TouchY = displayPoint.y; 
       
       if (TouchableMenuItems) { Check_ClockItems_Touch(TouchX, TouchY); }
       
       if (ButtonPressed(0, TouchX, TouchY)) { 
         DrawButton(0, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }
         if (CurrentSelected > 0) {CurrentSelected--;} else { CurrentSelected = 9; }       
         DrawButton(0, 0, "", 0);
       }
  
       if (ButtonPressed(1, TouchX, TouchY)) { 
         DrawButton(1, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }        
         if (CurrentSelected < 9) {CurrentSelected++;} else { CurrentSelected = 0; }        
         DrawButton(1, 0, "", 0);        
       }
   
       if (ButtonPressed(2, TouchX, TouchY)) { 
         DrawButton(2, BTN_PRESSED, "OK", 2);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }    
         DrawButton(2, 0, "OK", 2);  // Draw the normal (un-pressed) button
         DoAction_ClockMenu();     
       }
    }   
  }
}

void DoAction_ClockMenu(void)
{
         switch (MenuPage) {
         case 0:  // MenuPage 0 = Hour (Tenth)
           if (CurrentSelected > 2) { break; }
           Hour = CurrentSelected*10;
           MenuPage = 1;
           CurrentSelected = 0;
           OldSelected = 0;
           ChangeMenuTitle("Hour (Ones)", 11);
           ChangeMenuItem(0, "x0", 2);
           ChangeMenuItem(1, "x1", 2);
           ChangeMenuItem(2, "x2", 2);
           ChangeMenuItem(3, "x3", 2);
           ChangeMenuItem(4, "x4", 2);
           ChangeMenuItem(5, "x5", 2);
           ChangeMenuItem(6, "x6", 2);
           ChangeMenuItem(7, "x7", 2);
           ChangeMenuItem(8, "x8", 2);
           ChangeMenuItem(9, "x9", 2);
           DrawMenuItems();
           break; 
       
         case 1:  // MenuPage 1 = Hour (Ones)
           Hour = Hour + CurrentSelected;
           if (Hour > 24) { // Hour not valid
             MenuPage = 0;
             CurrentSelected = 0;
             OldSelected = 0;
             ChangeMenuTitle("Hour (Tenth)", 12);
             ChangeMenuItem(0, "0x", 2);
             ChangeMenuItem(1, "1x", 2);
             ChangeMenuItem(2, "2x", 2);
             ChangeMenuItem(3, "", 0);
             ChangeMenuItem(4, "", 0);
             ChangeMenuItem(5, "", 0);
             ChangeMenuItem(6, "", 0);
             ChangeMenuItem(7, "", 0);
             ChangeMenuItem(8, "", 0);
             ChangeMenuItem(9, "", 0);
             DrawMenuItems();
             break;  
           }
           MenuPage = 2;
           CurrentSelected = 0;
           OldSelected = 0;         
           ChangeMenuTitle("Minutes (Tenth)", 15);
           ChangeMenuItem(0, "0x", 2);
           ChangeMenuItem(1, "1x", 2);
           ChangeMenuItem(2, "2x", 2);
           ChangeMenuItem(3, "3x", 2);
           ChangeMenuItem(4, "4x", 2);
           ChangeMenuItem(5, "5x", 2);
           ChangeMenuItem(6, "", 0);
           ChangeMenuItem(7, "", 0);
           ChangeMenuItem(8, "", 0);
           ChangeMenuItem(9, "", 0);
           DrawMenuItems();
           break;     

         case 2:  // MenuPage 2 = Minutes (Tenth)
           if (CurrentSelected > 5) { break; }
           Minutes = CurrentSelected*10;
           MenuPage = 3;
           CurrentSelected = 0;
           OldSelected = 0;       
           ChangeMenuTitle("Minutes (Ones)", 14);
           ChangeMenuItem(0, "x0", 2);
           ChangeMenuItem(1, "x1", 2);
           ChangeMenuItem(2, "x2", 2);
           ChangeMenuItem(3, "x3", 2);
           ChangeMenuItem(4, "x4", 2);
           ChangeMenuItem(5, "x5", 2);
           ChangeMenuItem(6, "x6", 2);
           ChangeMenuItem(7, "x7", 2);
           ChangeMenuItem(8, "x8", 2);
           ChangeMenuItem(9, "x9", 2);
           DrawMenuItems();
           break;         

         case 3:  // MenuPage 3 = Minutes (Ones)
           Minutes = Minutes + CurrentSelected;
           MenuPage = 4;
           CurrentSelected = 0;
           OldSelected = 0;         
           ChangeMenuTitle("Seconds (Tenth)", 15);
           ChangeMenuItem(0, "0x", 2);
           ChangeMenuItem(1, "1x", 2);
           ChangeMenuItem(2, "2x", 2);
           ChangeMenuItem(3, "3x", 2);
           ChangeMenuItem(4, "4x", 2);
           ChangeMenuItem(5, "5x", 2);
           ChangeMenuItem(6, "", 0);
           ChangeMenuItem(7, "", 0);
           ChangeMenuItem(8, "", 0);
           ChangeMenuItem(9, "", 0);
           DrawMenuItems();
           break;    

         case 4:  // MenuPage 4 = Seconds (Tenth)
           if (CurrentSelected > 5) { break; }
           Seconds = CurrentSelected*10;
           MenuPage = 5;
           CurrentSelected = 0;
           OldSelected = 0;       
           ChangeMenuTitle("Seconds (Ones)", 14);
           ChangeMenuItem(0, "x0", 2);
           ChangeMenuItem(1, "x1", 2);
           ChangeMenuItem(2, "x2", 2);
           ChangeMenuItem(3, "x3", 2);
           ChangeMenuItem(4, "x4", 2);
           ChangeMenuItem(5, "x5", 2);
           ChangeMenuItem(6, "x6", 2);
           ChangeMenuItem(7, "x7", 2);
           ChangeMenuItem(8, "x8", 2);
           ChangeMenuItem(9, "x9", 2);
           DrawMenuItems();
           break;         

         case 5:  // MenuPage 5 = Seconds (Ones)
           Seconds = Seconds + CurrentSelected;
           MenuPage = 6;
           CurrentSelected = 3;
           OldSelected = 3;         
           ChangeMenuTitle("Set Clock", 9);           
           sprintf(buffer, "%0.2d:%0.2d:%0.2d", Hour, Minutes, Seconds);  
           ChangeMenuItem(0, "So the time is:", 15);           
           ChangeMenuItem(1, buffer, 8);
           ChangeMenuItem(2, "", 0);         
           ChangeMenuItem(3, "Yes", 3);
           ChangeMenuItem(4, "No", 2);         
           ChangeMenuItem(5, "", 0);
           ChangeMenuItem(6, "", 0);
           ChangeMenuItem(7, "", 0);
           ChangeMenuItem(8, "", 0);
           ChangeMenuItem(9, "", 0);
           DrawMenuItems();
           break;  
         
         case 6:  // MenuPage 6 = Confirmation
           if (CurrentSelected == 3)
           {
             Lcd_Text(10+4, 20*6+30+3, "Setting Clock...", 16, WHITE, BLACK);  
             Time_Adjust((Hour*3600 + Minutes*60 + Seconds));
             CurrentSelected = 6;
             OldSelected = 6; 
             BreakNow = 1;
             break;
           }
       
           if (CurrentSelected == 4) { 
             CurrentSelected = 6;
             OldSelected = 6;   
             BreakNow = 1;
             break; 
           }
           break;   
         }
}     