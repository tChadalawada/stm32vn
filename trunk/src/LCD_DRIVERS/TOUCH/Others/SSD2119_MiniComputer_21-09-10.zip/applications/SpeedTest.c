void SpeedTest(void)
{ 
  char buffer[10];
  int i;

  // Line Test
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,220,319,239,RED,1);

  i = 0;
  TimingDelay = 10;  
  while(TimingDelay > 0) {
    Lcd_Line(i+2,i+4,i+6,i+10, RED); 
    i++;
  }
  sprintf(buffer, "Lcd_Line (10ms): %d", i);
  Lcd_Text(8,222,buffer,17+3,WHITE,RED);
  Delay(5000);
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,220,319,239,RED,1);
  
  i = 0;
  TimingDelay = 10;
  while(TimingDelay > 0) {
    Line(i+2,i+4,i+6,i+10, SOLID_LINE, NORMAL_LINE, RED); 
    i++;
  }
  sprintf(buffer, "Line (10ms): %d", i);
  Lcd_Text(8,222,buffer,13+3,WHITE,RED);
  Delay(5000);
  // End of Line Test

  // Circle Test
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,220,319,239,RED,1);

  i = 0;
  TimingDelay = 100;  
  while(TimingDelay > 0) {
    Lcd_Circle(i+20,i+20, 10+i, RED, 0); 
    i++;
  }
  sprintf(buffer, "Non-Filled Lcd_Circle (100ms): %d", i);
  Lcd_Text(8,222,buffer,31+2,WHITE,RED);
  Delay(5000);
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,220,319,239,RED,1);
  
  i = 0;
  TimingDelay = 100;
  while(TimingDelay > 0) {
    Circle(i+20,i+20, 10+i, SOLID_LINE, NORMAL_LINE, RED); 
    i++;
  }
  sprintf(buffer, "Circle(100ms): %d", i);
  Lcd_Text(8,222,buffer,15+2,WHITE,RED);
  Delay(5000);
  // End of Circle Test

  // Circle Speed Test
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,220,319,239,RED,1);

  i = 0;
  TimingDelay = 1000;  
  while(TimingDelay > 0) {
    Lcd_Circle(i+20,i+20, 10+i, RED, 1); 
    i++;
  }
  sprintf(buffer, "Filled Lcd_Circle (1000ms): %d", i);
  Lcd_Text(8,222,buffer,28+2,WHITE,RED);
  Delay(5000);
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,220,319,239,RED,1);
  
  i = 0;
  TimingDelay = 1000;
  while(TimingDelay > 0) {
    FillCircle(i+20,i+20, 10+i, RED); 
    i++;
  }
  sprintf(buffer, "FillCircle (1000ms): %d", i);
  Lcd_Text(8,222,buffer,21+2,WHITE,RED);
  Delay(5000);
  // End of Circle Test

  // Rectangle Test
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,220,319,239,RED,1);

  i = 0;
  TimingDelay = 100;  
  while(TimingDelay > 0) {
    Lcd_FastRectangle(i+20,i+10,i+50,i+30, RED, 0); 
    i++;
  }
  sprintf(buffer, "Lcd_FastRectangle (100ms): %d", i);
  Lcd_Text(8,222,buffer,27+2,WHITE,RED);
  Delay(5000);
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,220,319,239,RED,1);
  
  i = 0;
  TimingDelay = 100;
  while(TimingDelay > 0) {
    Rectangle(i+20,i+10,i+50,i+30, SOLID_LINE, NORMAL_LINE, RED); 
    i++;
  }
  sprintf(buffer, "Rectangle (100ms): %d", i);
  Lcd_Text(8,222,buffer,19+2,WHITE,RED);
  Delay(5000);
  // End of Rectangle Test


}