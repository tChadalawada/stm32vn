bool SDCardInitialized;
u8 SDitemCount; // Items count in root (files and folders)
u8 SDcontentPages; // Count of Pages needed to show SD content
u8 i;


void Check_SDCardItems_Touch(u16 TouchX, u16 TouchY)
{
  u8 i;
  for (i = 0; i < 10; i++) {
    if (TouchX >= 10 && TouchX <= 275 && TouchY >= 20*i+30 && TouchY <= 20*i+30+20) {    
      while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) { GlobalMenuInterrupt(); } // Loop while touch screen is touched
  
      if (CurrentSelected == i || SingleClickMenu)
      {
        CurrentSelected = i;
        DoAction_SDCardMenu(); // Menu item was already selected, so execute!
        break;
      } else {
        CurrentSelected = i;
        break;
      }
    }
  }
}

void ReDraw_SDMenu(void)
{
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,0,319,20,RED,1);
  DrawMenuTitle();

  Rectangle(3, 25, 275, 235, DASHED_LINE, THICK_LINE, WHITE);
    
  DrawMenuItems();

  Lcd_FastRectangle(280, 20, 319, 239, RED, 1); 
  CreateButton(0, 285, 30, 310, 50, 10, 0, "", 0); // Up button
  CreateButton(1, 285, 200, 310, 220, 10, 0, "", 0); // Down button
  CreateButton(2, 285, 110, 310, 133, 0, 0, "OK", 2); // OK button
}


void SDCard (void)
{
  BreakNow = 0;

  CurrentSelected = 9;
  OldSelected = 9;

  MenuPage = 0;
  ChangeMenuTitle("SD Card", 7);
  ChangeMenuItem(0, "Initializing SD Card ", 20);
  ChangeMenuItem(1, "", 0);
  ChangeMenuItem(2, "", 0);
  ChangeMenuItem(3, "", 0);
  ChangeMenuItem(4, "", 0);
  ChangeMenuItem(5, "", 0);
  ChangeMenuItem(6, "", 0);
  ChangeMenuItem(7, "", 0);
  ChangeMenuItem(8, "", 0);
  ChangeMenuItem(9, "Back", 4);
  DrawMenuItems();

  /* Initialize efsl */
  if(efs_init(&efs,0)!=0){
    ChangeMenuItem(1, "Error Initializing SD Card", 26);
    SDCardInitialized = 0;
  } else {
  
    ls_openDir(&list, &efs.myFs, "/img/");    
  
    i = 0;
    SDitemCount = 0; // Items count in root (files and folders)
    SDcontentPages = 1; // Count of Pages needed to show SD content    
    while (ls_getNext(&list) == 0)
    {
      i++;
      SDitemCount++;    
      if (i == 9) {
        SDcontentPages++;
        i = 1;
      }              
    }
    ChangeMenuItem(1, "SD Card Initialized", 19);
    ChangeMenuItem(3, "Show content of SD card", 23);

    SDCardInitialized = 1; 
  }
  TP_Init(); // Remember to initialize Touch Panel again after communicating with the SD card
  DrawMenuItems();
 
while (!BreakNow) 
 {
  GlobalMenuInterrupt();

  while ((GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) && !BreakNow)
    {   
      GlobalMenuInterrupt();
    
       Touch_screenToDisplay();
       TouchX = displayPoint.x;
       TouchY = displayPoint.y; 
       
       if (TouchableMenuItems) { Check_SDCardItems_Touch(TouchX, TouchY); }
       
       if (ButtonPressed(0, TouchX, TouchY)) { 
         DrawButton(0, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }
         if (CurrentSelected > 0) {CurrentSelected--;} else { CurrentSelected = 9; }       
         DrawButton(0, 0, "", 0);
       }
  
       if (ButtonPressed(1, TouchX, TouchY)) { 
         DrawButton(1, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }        
         if (CurrentSelected < 9) {CurrentSelected++;} else { CurrentSelected = 0; }        
         DrawButton(1, 0, "", 0);        
       }
   
       if (ButtonPressed(2, TouchX, TouchY)) { 
         DrawButton(2, BTN_PRESSED, "OK", 2);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }    
         DrawButton(2, 0, "OK", 2);  // Draw the normal (un-pressed) button
         DoAction_SDCardMenu();     
       }
    }   
  }
}

void DoAction_SDCardMenu(void)
{
         switch (MenuPage) {        
         case 0:     
           if (CurrentSelected == 3 && SDCardInitialized)
           {       
             if (SDcontentPages > 1) {           
               CurrentSelected = 8; // Highlight Next
               OldSelected = 8;  
             } else {
               CurrentSelected = 9; // Highlight Back, because Next isn't there
               OldSelected = 9;  
             }             

             MenuPage = 1;
             sprintf(buffer,"Page 1/%i", SDcontentPages);
             ChangeMenuTitle(buffer, 8);
             PrintFilesFrom(0);
           
             if (SDcontentPages > 1) {
               ChangeMenuItem(8, "Next", 4);
             }           
             ChangeMenuItem(9, "Back", 4);           
           

             DrawMenuItems();

             break;  
           }
       
           if (CurrentSelected == 9)
           { 
             if (SDCardInitialized)
             {
               /* Close filesystem */
               fs_umount(&efs.myFs);
             }
           
             CurrentSelected = 0;
             OldSelected = 0;   
             BreakNow = 1;
             break; 
           }   

         default:   
           if (CurrentSelected < 8)
           {
             if (menuItems_length[CurrentSelected] >= 10 && menuItems[CurrentSelected][8] == 'B' && menuItems[CurrentSelected][9] == 'I' && menuItems[CurrentSelected][10] == 'N')  // The file type is BIN
               {
                 ShowFile(CurrentSelected);
                 ReDraw_SDMenu(); 
               }                     
             if (menuItems_length[CurrentSelected] >= 10 && menuItems[CurrentSelected][8] == 'M' && menuItems[CurrentSelected][9] == 'I' && menuItems[CurrentSelected][10] == 'D')  // The file type is MID (Midi)
               {
                 PlaySound(CurrentSelected);
                 ReDraw_SDMenu(); 
               }              
             if (menuItems_length[CurrentSelected] >= 10 && menuItems[CurrentSelected][8] == 'M' && menuItems[CurrentSelected][9] == 'P' && menuItems[CurrentSelected][10] == '3')  // The file type is MP3
               {
                 PlaySound(CurrentSelected);
                 ReDraw_SDMenu(); 
               }    
             if (menuItems_length[CurrentSelected] >= 10 && menuItems[CurrentSelected][8] == 'W' && menuItems[CurrentSelected][9] == 'A' && menuItems[CurrentSelected][10] == 'V')  // The file type is WAV
               {
                 PlaySound(CurrentSelected);
                 ReDraw_SDMenu(); 
               }             
             // Code here for pressing on file or folder
             break;
           }
       
           if (CurrentSelected == 8 && MenuPage+1 <= SDcontentPages)
           {             
             MenuPage = MenuPage+1;
             sprintf(buffer,"Page %i/%i", MenuPage, SDcontentPages);
             ChangeMenuTitle(buffer, 8);
             PrintFilesFrom((MenuPage-1)*7);  
           
             if (MenuPage+1 <= SDcontentPages) {
               ChangeMenuItem(8, "Next", 4);
             } else {
               CurrentSelected = 9;
               OldSelected = 9;  
             }            
             ChangeMenuItem(9, "Back", 4);           
                       
             DrawMenuItems();
             break;  
           }
      
           if (CurrentSelected == 9 && MenuPage > 1)
           {   
             MenuPage = MenuPage-1;
             sprintf(buffer,"Page %i/%i", MenuPage, SDcontentPages);
             ChangeMenuTitle(buffer, 8);
             PrintFilesFrom((MenuPage-1)*7);  
           
             if (MenuPage+1 <= SDcontentPages) {
               ChangeMenuItem(8, "Next", 4);
             } else {
               CurrentSelected = 9;
               OldSelected = 9;  
             }             
             ChangeMenuItem(9, "Back", 4);           
           
             DrawMenuItems();
             break;  
           }
            
           if (CurrentSelected == 9 && MenuPage == 1)
           {         
             MenuPage = 0;
             ChangeMenuTitle("SD Card", 7);
             ChangeMenuItem(0, "Initializing SD Card", 20);
             ChangeMenuItem(2, "", 0);
             ChangeMenuItem(3, "", 0);
             if(!SDCardInitialized){
               ChangeMenuItem(1, "Error Initializing SD Card", 26);
               SDCardInitialized = 0;
             } else {
               ChangeMenuItem(1, "SD Card Initialized", 19);
               ChangeMenuItem(3, "Show content of SD card", 23);
               SDCardInitialized = 1; 
             }             
             ChangeMenuItem(4, "", 0);
             ChangeMenuItem(5, "", 0);
             ChangeMenuItem(6, "", 0);
             ChangeMenuItem(7, "", 0);
             ChangeMenuItem(8, "", 0);
             ChangeMenuItem(9, "Back", 4);
             DrawMenuItems();
             break; 
           }  
         }
}     

void PrintFilesFrom(u8 startFrom)
{
  ChangeMenuItem(0, "", 0);
  ChangeMenuItem(1, "", 0);   
  ChangeMenuItem(2, "", 0);
  ChangeMenuItem(3, "", 0);   
  ChangeMenuItem(4, "", 0);
  ChangeMenuItem(5, "", 0);   
  ChangeMenuItem(6, "", 0);
  ChangeMenuItem(7, "", 0);   
  ChangeMenuItem(8, "", 0);
  ChangeMenuItem(9, "", 0);

  if(efs_init(&efs,0)!=0){
    ChangeMenuTitle("SD Card - Error", 15);
    ChangeMenuItem(0, "SD Card was removed!", 20);
    ChangeMenuItem(1, "Returning to main menu", 22);
    DrawMenuItems();
  
    Delay(1000);
  
    fs_umount(&efs.myFs); 
    TP_Init(); // Remember to initialize Touch Panel again after communicating with the SD card
    CurrentSelected = 0;
    OldSelected = 0;   
    BreakNow = 1;
  } else {
           
    // Open the directory
    ls_openDir(&list, &efs.myFs, "/img/");
    if (ls_getNext(&list) == 0) { // There are files to show
      if (startFrom > 0) {
        for (i = 0; i < startFrom; i++) {
          ls_getNext(&list); // Get next item until we come to startFrom
        }
      }
      for (i = 0; i <= 7; i++) {
        ChangeMenuItem(i, list.currentEntry.FileName, LIST_MAXLENFILENAME-1);
        if (ls_getNext(&list) != 0) { break; }
      }
    }
           
    TP_Init(); // Remember to initialize Touch Panel again after communicating with the SD card
  }
}

void ShowFile(u8 currentItem)
{
  bool ReturnToList = 0;
  unsigned char filename[16];
  if(efs_init(&efs,0)!=0){
    ChangeMenuTitle("SD Card - Error", 15);
    ChangeMenuItem(0, "SD Card was removed!", 20);
    ChangeMenuItem(1, "Returning to main menu", 22);
    DrawMenuItems();
  
    Delay(1000);
  
    fs_umount(&efs.myFs); 
    TP_Init(); // Remember to initialize Touch Panel again after communicating with the SD card
    CurrentSelected = 0;
    OldSelected = 0;   
    BreakNow = 1;
  } else {
  
    u8 i2 = 4;
    for (i = 0; i < LIST_MAXLENFILENAME-3; i++)
    {
      if (menuItems[currentItem][i] != 32) {
        filename[i2] = menuItems[currentItem][i];
        i2++;
      }
    }
    filename[0] = 'i';
    filename[1] = 'm';
    filename[2] = 'g';
    filename[3] = '/';
    filename[i2-1] = 46; // Add a dot
    filename[i2] = menuItems[currentItem][i-1];
    filename[i2+1] = menuItems[currentItem][i];
    filename[i2+2] = menuItems[currentItem][i+1];
        
    Lcd_Clear(BLACK);
    Lcd_Text(200,220,filename, 15, WHITE, BLACK);
    if (DispPic_SD_Fast(0,0,filename) != 0) {
      //Lcd_Text(0,10,"Error loading image",19,BLACK,WHITE);
      ReturnToList = 1;
    }
  }

  TP_Init(); // Remember to initialize Touch Panel again after communicating with the SD card

  while (!ReturnToList) {
    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
    {
      while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) { }      
      ReturnToList = 1;
      break;// Exit the image show and redraw the SD card menu     
    }
  }        
}

void PlaySound(u8 currentItem)
{
  bool ReturnToList = 0;
  unsigned char filename[16];
  if(efs_init(&efs,0)!=0){
    ChangeMenuTitle("SD Card - Error", 15);
    ChangeMenuItem(0, "SD Card was removed!", 20);
    ChangeMenuItem(1, "Returning to main menu", 22);
    DrawMenuItems();
  
    Delay(1000);
  
    fs_umount(&efs.myFs); 
    TP_Init(); // Remember to initialize Touch Panel again after communicating with the SD card
    CurrentSelected = 0;
    OldSelected = 0;   
    BreakNow = 1;
  } else {
  
    u8 i2 = 4;
    for (i = 0; i < LIST_MAXLENFILENAME-3; i++)
    {
      if (menuItems[currentItem][i] != 32) {
        filename[i2] = menuItems[currentItem][i];
        i2++;
      }
    }
    filename[0] = 'i';
    filename[1] = 'm';
    filename[2] = 'g';
    filename[3] = '/';
    filename[i2-1] = 46; // Add a dot
    filename[i2] = menuItems[currentItem][i-1];
    filename[i2+1] = menuItems[currentItem][i];
    filename[i2+2] = menuItems[currentItem][i+1];
        
    Lcd_Clear(BLACK);
    Lcd_Text(192,220,filename, 16, WHITE, BLACK);

    VS1053_Configuration();
    VS1053_Init(SM_SDISHARE | SM_SDINEW); // sets sci_mode register, SM_SDISHARE, 
                                                                 // SM_SDINEW.  pg 25, 26
    VS1053_Write(VS_CLOCKF, 0xE000); // SC_MULT = 7, SC_ADD = 0
    VS1053_SetVolume(100);

    unsigned int e,i;
    u32 current_pos;
    current_pos = 0;
    unsigned char sound_buffer[500];    

    // Open file for reading
    if (file_fopen(&file,&efs.myFs,filename,'r')!=0){
      return(-1); // Error
    } else {
      while((e=file_read(&file,500,sound_buffer))) {
        for (i = 0; i < e; i++) {
          VS1053_SendStreamByte(sound_buffer[i]);   
          if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
          {
            while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) { }      
            ReturnToList = 1;
            break;// Exit the image show and redraw the SD card menu     
          }        
        }
        //current_pos = current_pos + e;
        //sprintf(buffer, "Playing: %7.0d", current_pos);
        //Lcd_Text(192,200, buffer, 16, WHITE, BLACK);

      }
      // Close file
      file_fclose(&file);
    }
  }

  TP_Init(); // Remember to initialize Touch Panel again after communicating with the SD card      
}