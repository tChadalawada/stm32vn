
void Check_AboutItems_Touch(u16 TouchX, u16 TouchY)
{
  u8 i;
  for (i = 0; i < 10; i++) {
    if (TouchX >= 10 && TouchX <= 275 && TouchY >= 20*i+30 && TouchY <= 20*i+30+20) {    
      while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) { GlobalMenuInterrupt(); } // Loop while touch screen is touched
  
      if (CurrentSelected == i || SingleClickMenu)
      {
        CurrentSelected = i;
        DoAction_AboutMenu(); // Menu item was already selected, so execute!
        break;
      } else {
        CurrentSelected = i;
        break;
      }
    }
  }
}


void About (void)
{
  BreakNow = 0;

  CurrentSelected = 9;
  OldSelected = 9;

  MenuPage = 0;
  ChangeMenuTitle("About", 5);
  ChangeMenuItem(0, "Mini Computer - TKJ Electronics", 31);
  ChangeMenuItem(1, "Made by Thomas Jespersen", 24);
  ChangeMenuItem(2, "Marts 2010", 10);
  ChangeMenuItem(3, "", 0);
  sprintf(buffer, "Software Version: %0.2f", Version);
  ChangeMenuItem(4, buffer, 22);
  sprintf(buffer, "Serial: %0.2X%0.2X%0.2X%0.2X%0.2X%0.2X%0.2X%0.2X", Serial[0],Serial[1],Serial[2],Serial[3],Serial[4],Serial[5],Serial[6],Serial[7]);
  ChangeMenuItem(5, buffer, 24);
  ChangeMenuItem(6, "", 0);
  ChangeMenuItem(7, "", 0);
  ChangeMenuItem(8, "Specifications", 14);
  ChangeMenuItem(9, "Back", 4);
  DrawMenuItems();
 
while (!BreakNow) 
 {
  GlobalMenuInterrupt();

  while ((GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) && !BreakNow)
    {   
      GlobalMenuInterrupt();
    
       Touch_screenToDisplay();
       TouchX = displayPoint.x;
       TouchY = displayPoint.y; 
       
       if (TouchableMenuItems) { Check_AboutItems_Touch(TouchX, TouchY); }
       
       if (ButtonPressed(0, TouchX, TouchY)) { 
         DrawButton(0, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }
         if (CurrentSelected > 0) {CurrentSelected--;} else { CurrentSelected = 9; }       
         DrawButton(0, 0, "", 0);
       }
  
       if (ButtonPressed(1, TouchX, TouchY)) { 
         DrawButton(1, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }        
         if (CurrentSelected < 9) {CurrentSelected++;} else { CurrentSelected = 0; }        
         DrawButton(1, 0, "", 0);        
       }
   
       if (ButtonPressed(2, TouchX, TouchY)) { 
         DrawButton(2, BTN_PRESSED, "OK", 2);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }    
         DrawButton(2, 0, "OK", 2);  // Draw the normal (un-pressed) button
         DoAction_AboutMenu();     
       }
    }   
  }
}

void DoAction_AboutMenu(void)
{
         switch (MenuPage) {        
         case 0:
           if (CurrentSelected == 8)
           {
             CurrentSelected = 9;
             OldSelected = 9;  
           
             MenuPage = 1;
             ChangeMenuTitle("About -> Specifications", 23);
             ChangeMenuItem(0, "Processor: STM32F103RET6", 24);
             ChangeMenuItem(1, "Clock Frequency: 72MHz (8MHz)", 29);
             ChangeMenuItem(2, "", 0);
             ChangeMenuItem(3, "", 0);
             ChangeMenuItem(4, "Factory Date:", 13);  
             sprintf(buffer, "%0.2X/%0.2X %0.2X%0.2X - %0.2X:%0.2X:%0.2X GMT+1", FactoryDate[0],FactoryDate[1],FactoryDate[2],FactoryDate[3],FactoryDate[4],FactoryDate[5],FactoryDate[6]);
             ChangeMenuItem(5, buffer, 27);                       
             ChangeMenuItem(6, "", 0);
             ChangeMenuItem(7, "", 0);
             ChangeMenuItem(8, "", 0);           
             ChangeMenuItem(9, "Back", 4);
             DrawMenuItems();
             break;           
           }
       
           if (CurrentSelected == 9)
           { 
             CurrentSelected = 0;
             OldSelected = 0;   
             BreakNow = 1;
             break; 
           }
   
       
         case 1:             
           if (CurrentSelected == 9)
           { 
             CurrentSelected = 9;
             OldSelected = 9;   
           
             MenuPage = 0;
             ChangeMenuTitle("About", 5);
             ChangeMenuItem(0, "Mini Computer - TKJ Electronics", 31);
             ChangeMenuItem(1, "Made by Thomas Jespersen", 24);
             ChangeMenuItem(2, "Marts 2010", 10);
             ChangeMenuItem(3, "", 0);
             sprintf(buffer, "Software Version: %0.2f", Version);
             ChangeMenuItem(4, buffer, 22);
             sprintf(buffer, "Serial: %0.2X%0.2X%0.2X%0.2X%0.2X%0.2X%0.2X%0.2X", Serial[0],Serial[1],Serial[2],Serial[3],Serial[4],Serial[5],Serial[6],Serial[7]);
             ChangeMenuItem(5, buffer, 24);
             ChangeMenuItem(6, "", 0);
             ChangeMenuItem(7, "", 0);
             ChangeMenuItem(8, "Specifications", 14);
             ChangeMenuItem(9, "Back", 4);
             DrawMenuItems();
             break; 
           }       
         }
}     