#include "stm32f10x.h"
#include <efs.h>
#include <ls.h>
#include <stdio.h>
#include <string.h>

typedef union
{
  u16 U16;
  u8 U8[2];
}Two8BitTo16Bit;

signed char DispPic_SD(u16 x0, u16 y0, char* filename2);
signed char DispPic240_320_SD(File* file2,FileSystem *fs2,char* filename2);
signed char DispPic240_320_SD_Fast(File* file2,FileSystem *fs2,char* filename2);  // This is using a larger buffer, so it uses more RAM!