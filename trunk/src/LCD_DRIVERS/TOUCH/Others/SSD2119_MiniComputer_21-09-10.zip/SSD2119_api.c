#include "stm32f10x.h"
#include "SSD2119.h"
#include "SSD2119_api.h"


/****************************************************************************
* ��    �ƣ�Lcd_CmpColor()
* ��    �ܣ��ж���ɫֵ�Ƿ�һ�¡�
* ��ڲ�����color1		��ɫֵ1
*		        color2		��ɫֵ2
* ���ڲ���������1��ʾ��ͬ������0��ʾ����ͬ��
* ˵    ����
****************************************************************************/
#define  Lcd_CmpColor(color1, color2)	( (color1&0x01) == (color2&0x01) )


/****************************************************************************
* ��    �ƣ�u16 Lcd_Color565(u32 RGB)
* ��    �ܣ���RGB��ɫת��Ϊ16λ��ɫ��
* ��ڲ�����RGB  ��ɫֵ
* ���ڲ���������16λRGB��ɫֵ��
* ˵    ����
* ���÷�����i=Lcd_Color565(0xafafaf);
****************************************************************************/
u16 Lcd_Color565(u32 RGB)
{
  u8  r, g, b;

  b = ( RGB >> (0+3) ) & 0x1f;		// ȡBɫ�ĸ�5λ
  g = ( RGB >> (8+2) ) & 0x3f;		// ȡGɫ�ĸ�6λ
  r = ( RGB >> (16+3)) & 0x1f;		// ȡRɫ�ĸ�5λ
   
  return( (r<<11) + (g<<5) + (b<<0) );		
}

/****************************************************************************
* ��    �ƣ�void Lcd_Text(u16 x, u16 y, u8 *str, u16 len,u16 Color, u16 bkColor)
* ��    �ܣ���ָ��������ʾ�ַ���
* ��ڲ�����x      ������
*           y      ������
*           *str   �ַ���
*           len    �ַ�������
*           Color  �ַ���ɫ
*           bkColor�ַ�������ɫ
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_Text(0,0,"0123456789",10,0x0000,0xffff);
****************************************************************************/
void Lcd_Text(u16 x, u16 y, u8 *str, u16 len,u16 Color, u16 bkColor)
{
  u8 i;
  
  for (i=0;i<len;i++)
  {
    Lcd_PutChar((x+8*i),y,*str++,Color,bkColor);
  }
}

/****************************************************************************
* ��    �ƣ�void Lcd_Line(u16 x0, u16 y0, u16 x1, u16 y1,u16 color)
* ��    �ܣ���ָ�����껭ֱ��
* ��ڲ�����x0     A��������
*           y0     A��������
*           x1     B��������
*           y1     B��������
*           color  ����ɫ
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_Line(0,0,240,320,0x0000);
****************************************************************************/
void Lcd_Line(u16 x0, u16 y0, u16 x1, u16 y1,u16 color)
{
 	u16 x,y;
 	u16 dx;// = abs(x1 - x0);
 	u16 dy;// = abs(y1 - y0);

	if(y0==y1)
	{
		if(x0<=x1)
		{
			x=x0;
		}
		else
		{
			x=x1;
			x1=x0;
		}
  		while(x <= x1)
  		{
   			Lcd_SetPoint(x,y0,color);
   			x++;
  		}
  		return;
	}
	else if(y0>y1)
	{
		dy=y0-y1;
	}
	else
	{
		dy=y1-y0;
	}
 
 	if(x0==x1)
	{
		if(y0<=y1)
		{
			y=y0;
		}
		else
		{
			y=y1;
			y1=y0;
		}
  		while(y <= y1)
  		{
   			Lcd_SetPoint(x0,y,color);
   			y++;
  		}
  		return;
	}
	else if(x0 > x1)
 	{
		dx=x0-x1;
  		x = x1;
  		x1 = x0;
  		y = y1;
  		y1 = y0;
 	}
 	else
 	{
		dx=x1-x0;
  		x = x0;
  		y = y0;
 	}

 	if(dx == dy)
 	{
  		while(x <= x1)
  		{

   			x++;
			if(y>y1)
			{
				y--;
			}
			else
			{
   				y++;
			}
   			Lcd_SetPoint(x,y,color);
  		}
 	}
 	else
 	{
 		Lcd_SetPoint(x, y, color);
  		if(y < y1)
  		{
   			if(dx > dy)
   			{
    			s16 p = dy * 2 - dx;
    			s16 twoDy = 2 * dy;
    			s16 twoDyMinusDx = 2 * (dy - dx);
    			while(x < x1)
    			{
     				x++;
     				if(p < 0)
     				{
      					p += twoDy;
     				}
     				else
     				{
      					y++;
      					p += twoDyMinusDx;
     				}
     				Lcd_SetPoint(x, y,color);
    			}
   			}
   			else
   			{
    			s16 p = dx * 2 - dy;
    			s16 twoDx = 2 * dx;
    			s16 twoDxMinusDy = 2 * (dx - dy);
    			while(y < y1)
    			{
     				y++;
     				if(p < 0)
     				{
      					p += twoDx;
     				}
     				else
     				{
      					x++;
      					p+= twoDxMinusDy;
     				}
     				Lcd_SetPoint(x, y, color);
    			}
   			}
  		}
  		else
  		{
   			if(dx > dy)
   			{
    			s16 p = dy * 2 - dx;
    			s16 twoDy = 2 * dy;
	    		s16 twoDyMinusDx = 2 * (dy - dx);
    			while(x < x1)
    			{
     				x++;
     				if(p < 0)
	     			{
    	  				p += twoDy;
     				}
     				else
     				{
      					y--;
	      				p += twoDyMinusDx;
    	 			}
     				Lcd_SetPoint(x, y,color);
    			}
   			}
	   		else
   			{
    			s16 p = dx * 2 - dy;
    			s16 twoDx = 2 * dx;
	    		s16 twoDxMinusDy = 2 * (dx - dy);
    			while(y1 < y)
    			{
     				y--;
     				if(p < 0)
	     			{
    	  				p += twoDx;
     				}
     				else
     				{
      					x++;
	      				p+= twoDxMinusDy;
    	 			}
     				Lcd_SetPoint(x, y,color);
    			}
   			}
  		}
 	}
}

/****************************************************************************
* ��    �ƣ�void Lcd_Circle(u16 cx,u16 cy,u16 r,u16 color,u8 fill)
* ��    �ܣ���ָ�����껭Բ�������
* ��ڲ�����
* ���ڲ�����
* ˵    ����
* ���÷�����
****************************************************************************/
void Lcd_Circle(u16 cx,u16 cy,u16 r,u16 color,u8 fill)
{
	u16 x,y;
	s16 delta,tmp;
	x=0;
	y=r;
	delta=3-(r<<1);

	while(y>x)
	{
		if(fill)
		{
			Lcd_Line(cx+x,cy+y,cx-x,cy+y,color);
			Lcd_Line(cx+x,cy-y,cx-x,cy-y,color);
			Lcd_Line(cx+y,cy+x,cx-y,cy+x,color);
			Lcd_Line(cx+y,cy-x,cx-y,cy-x,color);
		}
		else
		{
			Lcd_SetPoint(cx+x,cy+y,color);
			Lcd_SetPoint(cx-x,cy+y,color);
			Lcd_SetPoint(cx+x,cy-y,color);
			Lcd_SetPoint(cx-x,cy-y,color);
			Lcd_SetPoint(cx+y,cy+x,color);
			Lcd_SetPoint(cx-y,cy+x,color);
			Lcd_SetPoint(cx+y,cy-x,color);
			Lcd_SetPoint(cx-y,cy-x,color);
		}
		x++;
		if(delta>=0)
		{
			y--;
			tmp=(x<<2);
			tmp-=(y<<2);
			delta+=(tmp+10);
		}
		else
		{
			delta+=((x<<2)+6);
		}
	}
}

/****************************************************************************
* ��    �ƣ�void Lcd_Rectangle(u16 x0, u16 y0, u16 x1, u16 y1,u16 color,u8 fill)
* ��    �ܣ���ָ�����򻭾��Σ��������ɫ
* ��ڲ�����
* ���ڲ�����
* ˵    ����
* ���÷�����
****************************************************************************/
void Lcd_Rectangle(u16 x0, u16 y0, u16 x1, u16 y1,u16 color,u8 fill)
{
	if(fill)
	{
		u16 i;
		if(x0>x1)
		{
			i=x1;
			x1=x0;
		}
		else
		{
			i=x0;
		}
		for(;i<=x1;i++)
		{
			Lcd_Line(i,y0,i,y1,color);
		}
		return;
	}
	Lcd_Line(x0,y0,x0,y1,color);
	Lcd_Line(x0,y1,x1,y1,color);
	Lcd_Line(x1,y1,x1,y0,color);
	Lcd_Line(x1,y0,x0,y0,color);
}

/****************************************************************************
* ��    �ƣ�void  Lcd_Square(u16 x0, u16 y0, u16 with, u16 color,u8 fill)
* ��    �ܣ���ָ�����������Σ��������ɫ
* ��ڲ�����
* ���ڲ�����
* ˵    ����
* ���÷�����
****************************************************************************/
void  Lcd_Square(u16 x0, u16 y0, u16 width, u16 color,u8 fill)
{
	Lcd_Rectangle(x0, y0, x0+width, y0+width, color,fill);
}

void Lcd_ClearCharBox(u16 x,u16 y,u16 color)
{
	Lcd_Rectangle(x*8,y*16,x*8+8,y*16+16,color,TRUE); 
}

void Lcd_FastRectangle(u16 x0, u16 y0, u16 x1, u16 y1,u16 color,u8 fill)
{
  u32  i;
  u32  difference;
  Lcd_Line(x0,y0,x0,y1,color);
  Lcd_Line(x0,y1,x1,y1,color);
  Lcd_Line(x1,y1,x1,y0,color);
  Lcd_Line(x1,y0,x0,y0,color);
  difference = x1-x0;
if(fill) {
while (y0<=y1) {
  Lcd_SetCursor(x0, y0);
  Lcd_WR_Start();
  for(i=0;i<=difference;i++) {  //Write all pixels to ram, and then update display (fast)
    Lcd_WriteData(color);
    Clr_nWr
    Set_nWr;
  } 
  y0++;
  Lcd_WR_End();
}
}
}

void  Lcd_FastSquare(u16 x0, u16 y0, u16 width, u16 color,u8 fill)
{
	Lcd_FastRectangle(x0, y0, x0+width, y0+width, color,fill);
}

void Lcd_FastClearCharBox(u16 x,u16 y,u16 color)
{
	Lcd_FastRectangle(x*8,y*16,x*8+8,y*16+16,color,TRUE); 
}

void DispPic320_240(const unsigned char *str)
{

	u32 temp;
	ColorTypeDef color;
	Lcd_SetCursor(0x00, 0x0000);
	//Lcd_WriteReg(0x0050,0x00);//ˮƽ GRAM��ʼλ��
	//Lcd_WriteReg(0x0051,239);//ˮƽGRAM��ֹλ��
	//Lcd_WriteReg(0x0052,0);//��ֱGRAM��ʼλ��
	//Lcd_WriteReg(0x0053,319);//��ֱGRAM��ֹλ��   
	Lcd_WR_Start();
	//Set_Rs;
  
	for (temp = 2; temp < 320*240 + 2; temp++)
	{  
		color.U8[1] =*(unsigned short *)(&str[ 2 * temp]);
		color.U8[0]=*(unsigned short *)(&str[ 2 * temp+1]);
		//DataToWrite(i);
	
		Lcd_WriteData(color.U16);
		Clr_nWr;
		Set_nWr;
	}
Lcd_WR_End();

//==============================  
}

void DispPic(u16 x0, u16 y0, const unsigned char *str)
{

	u32 temp;
    u32  i;
    u32 difference;
    
    u16 x1;
    u16 y1;
    u16 imageWidth;
    u16 imageHeight;
    
    ColorTypeDef color;
    
    color.U8[1] =*(unsigned short *)(&str[ 0]);
	color.U8[0]=*(unsigned short *)(&str[ 1]);
    imageWidth = color.U16;
    x1 = imageWidth + x0;

    color.U8[1] =*(unsigned short *)(&str[ 2]);
	color.U8[0]=*(unsigned short *)(&str[ 3]);
    imageHeight = color.U16;
    y1 = imageHeight + y0;

    temp = 2;
    difference = x1-x0;
    while (y0<=y1-1) {
      Lcd_SetCursor(x0, y0);
      Lcd_WR_Start();
      for(i=0;i<=imageWidth-1;i++) {  //Write all pixels to ram, and then update display (fast)
        color.U8[1] =*(unsigned short *)(&str[ 2 * temp]);
	    color.U8[0]=*(unsigned short *)(&str[ 2 * temp+1]);
        Lcd_WriteData(color.U16);
        Clr_nWr
        Set_nWr;
        
        temp++;
      } 
      y0++;
      Lcd_WR_End();
    }

//==============================  
}