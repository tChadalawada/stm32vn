// Menu variables
u8 CurrentSelected, OldSelected = 0;
u8 MenuPage = 0;
bool HoldForRecalibrate = 0;
unsigned char menuTitle[25];
u8 menuTitle_length;
unsigned char menuItems[10][31];
u8 menuItems_length[10];

bool BreakNow = 0;

void Standby(void)
{
  bool BreakNow = 0;
  Lcd_Clear(BLACK);

  while (!BreakNow)
  {
    if (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
    {
      TimingDelay = 1000; // Set ms counter to 1000 to check if the hold is 1 second long

      while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
      {    
        if (TimingDelay == 0) { BreakNow = 1; break; } // Leave the standby routine
      }
      TimingDelay = 0;
    }
  }
}


void GlobalMenuInterrupt(void)
{
    /* If 1s has paased */
    if (TimeDisplay == 1)
    {
      /* Display current time */
      Time_Display(200,3,WHITE,RED,RTC_GetCounter());
    }

    if (OldSelected != CurrentSelected)
    {
      Lcd_FastRectangle(10,20*OldSelected+30,268,20*OldSelected+30+20, BLACK, 1);
      Lcd_Text(10+4, 20*OldSelected+30+3, &menuItems[OldSelected], menuItems_length[OldSelected], WHITE, BLACK);
      Lcd_FastRectangle(10,20*CurrentSelected+30,268,20*CurrentSelected+30+20, WHITE, 1);
      Lcd_Text(10+4, 20*CurrentSelected+30+3, &menuItems[CurrentSelected], menuItems_length[CurrentSelected], BLACK, WHITE);
      OldSelected = CurrentSelected;
    }
}

void ChangeMenuTitle(unsigned char *NewmenuTitle, u8 NewmenuTitle_length)
{
  u8 i;
  for (i = 0; i < NewmenuTitle_length; i++)
  {
    menuTitle[i] = *NewmenuTitle++;
  }
  menuTitle_length = NewmenuTitle_length;

  DrawMenuTitle();
} 

void ChangeMenuItem(u8 itemID, unsigned char *menuItem, u8 menuItem_length)
{
  u8 i;
  for (i = 0; i < menuItem_length; i++)
  {
    menuItems[itemID][i] = *menuItem++;
  }
  menuItems_length[itemID] = menuItem_length;
} 

void DrawMenuTitle(void)
{
  Lcd_FastRectangle(0,0,200,20,RED,1);
  Lcd_Text(4,3,&menuTitle, menuTitle_length, WHITE,RED);
}

void DrawMenuItems(void)
{
  u8 i;

  for (i = 0; i < 10; i++) 
  { 
    Lcd_FastRectangle(10,20*i+30,268,20*i+30+20, BLACK, 1);
    Lcd_Text(10+4, 20*i+30+3, &menuItems[i], menuItems_length[i], WHITE, BLACK);
  }

  Lcd_FastRectangle(10,20*CurrentSelected+30,268,20*CurrentSelected+30+20, WHITE, 1);
  Lcd_Text(10+4, 20*CurrentSelected+30+3, &menuItems[CurrentSelected], menuItems_length[CurrentSelected], BLACK, WHITE);
}

void Check_MainItems_Touch(u16 TouchX, u16 TouchY)
{
  u8 i;
  bool BreakNow = 0;
  for (i = 0; i < 10; i++) {
    if (TouchX >= 10 && TouchX <= 275 && TouchY >= 20*i+30 && TouchY <= 20*i+30+20) {   
      Touch_screenToDisplay();
      TouchX = displayPoint.x;
      TouchY = displayPoint.y;   
      if (!(TouchX >= 10 && TouchX <= 275 && TouchY >= 20*i+30 && TouchY <= 20*i+30+20)) { BreakNow = 1; }
  
      while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) {
        GlobalMenuInterrupt();  // Loop while touch screen is touched
        if (TimingDelay == 0 && HoldForRecalibrate) {
          TimingDelay = 3000;
          Lcd_Clear(BLACK);
          Lcd_Text(20,110, "Hold for 3 seconds to Recalibrate",33,WHITE,BLACK);
          while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
          { 
            if (TimingDelay == 0) {
              Touch_ReCalibrate();  // Disable Touch Screen  
              BreakNow = 1;            
              break;
            }           
          }                       
          Draw_MainMenu();
          TimingDelay = 0;
          HoldForRecalibrate = 0;
          BreakNow = 1;   
        }
      }
   
      if (BreakNow) { break; }
       
      if (CurrentSelected == i || SingleClickMenu)
      {
        CurrentSelected = i;
        DoAction_MainMenu(); // Menu item was already selected, so execute!
        break;
      } else {
        CurrentSelected = i;
        break;
      }
    }
  }
}

void Draw_MainMenu(void)
{
  Lcd_Clear(BLACK);
  Lcd_FastRectangle(0,0,319,20,RED,1);
  DrawMenuTitle();

  Rectangle(3, 25, 275, 235, DASHED_LINE, THICK_LINE, WHITE);
  
  MenuPage = 0;
  ChangeMenuTitle("Menu 1/2", 8);
  ChangeMenuItem(0, "About", 5);  
  ChangeMenuItem(1, "Run Speed Test", 14);  
  ChangeMenuItem(2, "SD Card", 7);
  ChangeMenuItem(3, "Menu 4", 6);
  ChangeMenuItem(4, "Menu 5", 6);
  ChangeMenuItem(5, "Standby", 7);
  ChangeMenuItem(6, "Set Clock", 9);     
  ChangeMenuItem(7, "Settings", 8);
  ChangeMenuItem(8, "Recalibrate Touch Screen", 24);
  ChangeMenuItem(9, "Next Page", 9);     
  DrawMenuItems();

  Lcd_FastRectangle(280, 20, 319, 239, RED, 1); 
  CreateButton(0, 285, 30, 310, 50, 10, 0, "", 0); // Up button
  CreateButton(1, 285, 200, 310, 220, 10, 0, "", 0); // Down button
  CreateButton(2, 285, 110, 310, 133, 0, 0, "OK", 2); // OK button
}

void MainMenu(void)
{
 
  Draw_MainMenu();

   while (1) 
   {
     TimingDelay = 0;
     HoldForRecalibrate = 0;
     GlobalMenuInterrupt();
 
     while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
     {   
       GlobalMenuInterrupt();
     
       // Touch Screen calibration security - if touch screen isn't calibrated probably, hold screen to recalibrate!
       if (!HoldForRecalibrate) {
         TimingDelay = 5000; // Set this to check if hold for 3 seconds
         HoldForRecalibrate = 1;
       }
     
       if (TimingDelay == 0 && HoldForRecalibrate) {
         TimingDelay = 3000;
         Lcd_Clear(BLACK);
         Lcd_Text(20,110, "Hold for 3 seconds to Recalibrate",33,WHITE,BLACK);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0)
         { 
           if (TimingDelay == 0) {
             Touch_ReCalibrate();  // Disable Touch Screen             
             break;
           }           
         }                       
         Draw_MainMenu();
         TimingDelay = 0;
         HoldForRecalibrate = 0;
       }
       // Touch Screen calibration security end

       Touch_screenToDisplay();
       TouchX = displayPoint.x;
       TouchY = displayPoint.y; 
   
       if (TouchableMenuItems) { Check_MainItems_Touch(TouchX, TouchY); }
       
       if (ButtonPressed(0, TouchX, TouchY)) { 
         DrawButton(0, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }
         if (CurrentSelected > 0) {CurrentSelected--;} else { CurrentSelected = 9; }       
         DrawButton(0, 0, "", 0);
       }
  
       if (ButtonPressed(1, TouchX, TouchY)) { 
         DrawButton(1, BTN_PRESSED, "", 0);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }        
         if (CurrentSelected < 9) {CurrentSelected++;} else { CurrentSelected = 0; }        
         DrawButton(1, 0, "", 0);        
       }
   
       if (ButtonPressed(2, TouchX, TouchY)) { 
         DrawButton(2, BTN_PRESSED, "OK", 2);
         while (GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0) == 0) 
         {
           GlobalMenuInterrupt();
         }    
         DrawButton(2, 0, "OK", 2);  // Draw the normal (un-pressed) button
         DoAction_MainMenu();         
       }     
     }
   }
}  


void DoAction_MainMenu(void)
{
         switch (MenuPage) {
         case 0:
           if (CurrentSelected == 0) {
             About();  // Start About application
             MenuPage = 0;
             ChangeMenuTitle("Menu 1/2", 8);
             ChangeMenuItem(0, "About", 5);  
             ChangeMenuItem(1, "Run Speed Test", 14);  
             ChangeMenuItem(2, "SD Card", 7);
             ChangeMenuItem(3, "Menu 4", 6);
             ChangeMenuItem(4, "Menu 5", 6);
             ChangeMenuItem(5, "Standby", 7);
             ChangeMenuItem(6, "Set Clock", 9);     
             ChangeMenuItem(7, "Settings", 8);
             ChangeMenuItem(8, "Recalibrate Touch Screen", 24);
             ChangeMenuItem(9, "Next Page", 9);     
             DrawMenuItems();
           }
       
           if (CurrentSelected == 1) {
             SpeedTest();  // Start Speed Test application
             MainMenu();
           }
       
           if (CurrentSelected == 2) {
             SDCard();  // Start SD Card application
             MainMenu();
           }       
       
           if (CurrentSelected == 5) {
             Standby();  // Standby
             MainMenu();
           }           
       
           if (CurrentSelected == 6) {
             SetClock();  // Start Set Clock application
             MainMenu();
           }       
       
           if (CurrentSelected == 7) {
             Settings();  // Start Settings application
             MainMenu();
           }   
       
           if (CurrentSelected == 8) {
             Touch_ReCalibrate();  // ReCalibrate Touch Screen
             MainMenu();
           }      
     
           if (CurrentSelected == 9) {
             ChangeMenuTitle("Menu 2/2", 8);
             ChangeMenuItem(0, "Menu 11", 7);
             ChangeMenuItem(1, "Menu 12", 7);
             ChangeMenuItem(2, "Menu 13", 7);
             ChangeMenuItem(3, "Menu 14", 7);
             ChangeMenuItem(4, "Menu 15", 7);
             ChangeMenuItem(5, "Menu 16", 7);
             ChangeMenuItem(6, "Menu 17", 7);
             ChangeMenuItem(7, "Menu 18", 7);     
             ChangeMenuItem(8, "Menu 19", 7);
             ChangeMenuItem(9, "Previous Page", 13);     
             DrawMenuItems();
             MenuPage++;    
             break;           
           }
       
         case 1:                  
           if (CurrentSelected == 9) {
             ChangeMenuTitle("Menu 1/2", 8);
             ChangeMenuItem(0, "About", 5);
             ChangeMenuItem(1, "Run Speed Test", 14);             
             ChangeMenuItem(2, "SD Card", 7);
             ChangeMenuItem(3, "Menu 4", 6);
             ChangeMenuItem(4, "Menu 5", 6);
             ChangeMenuItem(5, "Standby", 7);
             ChangeMenuItem(6, "Set Clock", 9);     
             ChangeMenuItem(7, "Settings", 8);
             ChangeMenuItem(8, "Recalibrate Touch Screen", 24);
             ChangeMenuItem(9, "Next Page", 9);     
             DrawMenuItems();
             MenuPage--; 
             break;          
           }      
         }
}     