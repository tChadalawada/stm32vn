// Remember to change the stm32f10x_conf.h to include the peripherals you need
/* Exported types ------------------------------------------------------------*/

/* Includes ------------------------------------------------------------------*/
#include <efs.h>
#include <ls.h>
#include <stdio.h>
#include <string.h>
#include "stm32f10x.h"
#include "SSD2119.h"
#include "SSD2119_api.h"
#include "SSD2119_api_sd.h"
#include "ads7843drv.h"
#include "SSD2119_touch.h"
#include "MicrochipGraphics.h"
#include "MicrochipButton.h"
#include "BootLogo.h"
#include "VS1053.h"

#define RED  	0xf800
#define GREEN	0x07e0
#define BLUE 	0x001f
#define WHITE	0xffff
#define BLACK	0x0000
#define YELLOW   0xFFE0

/* Private typedef -----------------------------------------------------------*/
/* Private define ------------------------------------------------------------*/

// RTC Definitions
//#define RTCClockOutput_Enable  /* RTC Clock/64 is output on tamper pin(PC.13) */
#define RTC_Default_Hour 0
#define RTC_Default_Min 0
#define RTC_Default_Sec 0

void RTC_Configuration(void);
void RTC_Clock_Setup(void);

__IO u8 TimeDisplay = 0;
void Time_Adjust(uint32_t seconds);
void Time_Display(u16 x, u16 y, u16 frontColor, u16 backColor, uint32_t TimeVar);
// RTC Definitions End

/* Private macro -------------------------------------------------------------*/
/* Private variables ---------------------------------------------------------*/
ErrorStatus HSEStartUpStatus;

/* Private function prototypes -----------------------------------------------*/
void RCC_Configuration(void);
void GPIO_Configuration(void);
void NVIC_Configuration(void);

static __IO uint32_t TimingDelay;
void Delay(__IO uint32_t nTime);

#ifdef __GNUC__
/* With GCC/RAISONANCE, small printf (option LD Linker->Libraries->Small printf
   set to 'Yes') calls __io_putchar() */
  #define PUTCHAR_PROTOTYPE int __io_putchar(int ch)
#else
  #define PUTCHAR_PROTOTYPE int fputc(int ch, FILE *f)
#endif /* __GNUC__ */


// SD card variables
EmbeddedFileSystem efs;
DirList list;
EmbeddedFile file_r;
File file;

int TouchX, TouchY;

unsigned char  buffer[40];

/* Private function prototypes -----------------------------------------------*/

  
/* Private functions ---------------------------------------------------------*/

// Changeable settings
#define SETTINGSSAVED 0x1234
#define SETTINGSSAVED_ADDR 0x7F800
#define TOUCHABLEMENUITEMS_ADDR 0x7F802
bool TouchableMenuItems;
#define SINGLECLICKMENU_ADDR 0x7F804
bool SingleClickMenu;

const float Version = 0.30;  // This isn't volatile, which means it can't be found as normal text in final hex file
volatile const u8 Serial[8] = "********"; // This is here to make it easier find, search after 2A2A2A2A2A2A2A2A in hex file
volatile const u8 FactoryDate[7] = "+++++++"; // The representation in HEX is: 1st byte=date, 2nd byte=month, 3rd byte=year msb, 4th byte=year lsb, 5th byte=hour, 6th byte=minutes, 7th byte=seconds
                                              // To find it in the HEX file, search after 2B2B2B2B2B2B2B


#include "MainMenu.c" // The code for the Main Menu
// Application Includements
#include "applications/SpeedTest.c"
#include "applications/SetClock.c"
#include "applications/Settings.c"
#include "applications/About.c"
#include "applications/SDCard.c"
// Application Includements end





/*******************************************************************************
* Function Name  : main
* Description    : Main program
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
int main(void)
{
  /* System clocks configuration ---------------------------------------------*/
  RCC_Configuration();

  /* NVIC configuration ------------------------------------------------------*/
  NVIC_Configuration();

  /* GPIO configuration ------------------------------------------------------*/
  GPIO_Configuration(); 

  /* Setup SysTick Timer for 1 msec interrupts  */               
  if (SysTick_Config(SystemFrequency / 1000))
  { 
    /* Capture error */ 
    while (1);
  }
 
  Lcd_Configuration();
  Lcd_Initializtion();
  
  Lcd_Clear(BLACK);
  DispPic(0,60,BootLogo); 
  RTC_Clock_Setup();  // RTC Clock setup is placed here because it takes about 1-2 seconds if it isn't setup already

  // Load settings from FLASH if they are there
  if ((*(__IO uint16_t*)(SETTINGSSAVED_ADDR)) != SETTINGSSAVED) {  
    TouchableMenuItems = 1;
    SingleClickMenu = 0;   
  } else {
    TouchableMenuItems = ((*(__IO uint16_t*)(TOUCHABLEMENUITEMS_ADDR)) & 1);
    SingleClickMenu = ((*(__IO uint16_t*)(SINGLECLICKMENU_ADDR)) & 1); 
  }

  TP_Init();
  Touch_Calibrate(0);  // Calibrate Touch Screen

while(1) 
  { MainMenu(); }
}
  

void SaveSettingsToFlash(void)
{
  /* Unlock the Flash */
  FLASH_Unlock();
  FLASH_ErasePage(SETTINGSSAVED_ADDR);

  // Touch Settings Save
  uint16_t *ptr; // Create a pointer
  ptr = &matrix; // Set the pointer to the adress of the MATRIX variable

 
  int i;
  for (i = 0; i < sizeof(MATRIX)/2; i++) {
    FLASH_ProgramHalfWord(MATRIX_FLASH_ADDR+(i*2), *ptr);
    ptr++;
  }

  if (TouchScreenIScalibrated) {
    FLASH_ProgramHalfWord(MATRIX_OPTION_FLASH_ADDR, MATRIX_SAVED_TO_FLASH);  // Set the calibration flag = Touch Screen is calibrated
  } else {
    FLASH_ProgramHalfWord(MATRIX_OPTION_FLASH_ADDR, 0xFFFF);  // Clear the calibration flag = Touch Screen is not calibrated
  }


  // User-interface Settings Save
  FLASH_ProgramHalfWord(TOUCHABLEMENUITEMS_ADDR, 0x0000 + TouchableMenuItems);
  FLASH_ProgramHalfWord(SINGLECLICKMENU_ADDR, 0x0000 + SingleClickMenu);  
  FLASH_ProgramHalfWord(SETTINGSSAVED_ADDR, SETTINGSSAVED); 

  FLASH_Lock();
}

/*******************************************************************************
* Function Name  : RCC_Configuration
* Description    : Configures the different system clocks.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RCC_Configuration(void)
   {
   /* RCC system reset(for debug purpose) */
   RCC_DeInit();

   /* Enable HSE */
   RCC_HSEConfig(RCC_HSE_ON);

   /* Wait till HSE is ready */
   HSEStartUpStatus = RCC_WaitForHSEStartUp();

   if(HSEStartUpStatus == SUCCESS)
      {
      /* Enable Prefetch Buffer */
      FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

      /* Flash 2 wait state */
      FLASH_SetLatency(FLASH_Latency_2);

      /* HCLK = SYSCLK */
      RCC_HCLKConfig(RCC_SYSCLK_Div1); 

      /* PCLK2 = HCLK */
      RCC_PCLK2Config(RCC_HCLK_Div1); 

      /* PCLK1 = HCLK/2 */
      RCC_PCLK1Config(RCC_HCLK_Div2);

      /* PLLCLK = 8MHz * 9 = 72 MHz */
      RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

      /* Enable PLL */ 
      RCC_PLLCmd(ENABLE);

      /* Wait till PLL is ready */
      while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
         {;}

      /* Select PLL as system clock source */
      RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

      /* Wait till PLL is used as system clock source */
      while(RCC_GetSYSCLKSource() != 0x08)
         {;}
      }

   /* Enable peripheral clocks --------------------------------------------------*/
   /* Enable GPIOA, GPIOB, GPIOC, GPIOD, GPIOE, GPIOF, GPIOG and AFIO clocks */
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB |RCC_APB2Periph_GPIOC 
         | RCC_APB2Periph_GPIOD | RCC_APB2Periph_GPIOE | RCC_APB2Periph_GPIOF | RCC_APB2Periph_GPIOG 
         | RCC_APB2Periph_AFIO, ENABLE);
   }


/*******************************************************************************
* Function Name  : GPIO_Configuration
* Description    : Configures the different GPIO ports.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void GPIO_Configuration(void)
{
  GPIO_InitTypeDef GPIO_InitStructure;

  // GPIO Speed valid for all further GPIO configurations
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;

}


/*******************************************************************************
* Function Name  : NVIC_Configuration
* Description    : Configures Vector Table base location.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void NVIC_Configuration(void)
{
#ifdef  VECT_TAB_RAM  
  /* Set the Vector Table base location at 0x20000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_RAM, 0x0); 
#else  /* VECT_TAB_FLASH  */
  /* Set the Vector Table base location at 0x08000000 */ 
  NVIC_SetVectorTable(NVIC_VectTab_FLASH, 0x0);   
#endif

  NVIC_InitTypeDef NVIC_InitStructure;

  /* Configure one bit for preemption priority */
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_1);

  /* Enable the RTC Interrupt */
  NVIC_InitStructure.NVIC_IRQChannel = RTC_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
  NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
  NVIC_Init(&NVIC_InitStructure);
}

/**
  * @brief  Configures the RTC.
  * @param  None
  * @retval None
  */
void RTC_Configuration(void)
{
  /* Enable PWR and BKP clocks */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

  /* Allow access to BKP Domain */
  PWR_BackupAccessCmd(ENABLE);

  /* Reset Backup Domain */
  BKP_DeInit();

  /* Enable LSE */
  RCC_LSEConfig(RCC_LSE_ON);
  /* Wait till LSE is ready */
  while (RCC_GetFlagStatus(RCC_FLAG_LSERDY) == RESET)
  {}

  /* Select LSE as RTC Clock Source */
  RCC_RTCCLKConfig(RCC_RTCCLKSource_LSE);

  /* Enable RTC Clock */
  RCC_RTCCLKCmd(ENABLE);

  /* Wait for RTC registers synchronization */
  RTC_WaitForSynchro();

  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();

  /* Enable the RTC Second */
  RTC_ITConfig(RTC_IT_SEC, ENABLE);

  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();

  /* Set RTC prescaler: set RTC period to 1sec */
  RTC_SetPrescaler(32767); /* RTC period = RTCCLK/RTC_PR = (32.768 KHz)/(32767+1) */

  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();
}

void RTC_Clock_Setup(void)
{
  if (BKP_ReadBackupRegister(BKP_DR1) != 0xA5A5)
  {
    /* Backup data register value is not correct or not yet programmed (when
       the first time the program is executed) */

    //printf("\r\n\n RTC not yet configured....");
    //Lcd_Text(0,0,"RTC not yet configured....",26,WHITE,BLACK);
  
    //printf("\r\n RTC configured....");
    //Lcd_Text(0,20,"RTC configured....",18,WHITE,BLACK);

    /* Adjust time by values entred by the user on the hyperterminal */
    Time_Adjust((RTC_Default_Hour*3600 + RTC_Default_Min*60 + RTC_Default_Sec));    
  }
  else
  {
    /* Check if the Power On Reset flag is set */
    if (RCC_GetFlagStatus(RCC_FLAG_PORRST) != RESET)
    {
      //printf("\r\n\n Power On Reset occurred....");
      //Lcd_Text(0,40,"Power On Reset occurred....",27,WHITE,BLACK);
    }
    /* Check if the Pin Reset flag is set */
    else if (RCC_GetFlagStatus(RCC_FLAG_PINRST) != RESET)
    {
      //printf("\r\n\n External Reset occurred....");
      //Lcd_Text(0,60,"External Reset occurred....",27,WHITE,BLACK);
    }

    //printf("\r\n No need to configure RTC....");
    //Lcd_Text(0,80,"No need to configure RTC....",28,WHITE,BLACK);
    /* Wait for RTC registers synchronization */
    RTC_WaitForSynchro();

    /* Enable the RTC Second */
    RTC_ITConfig(RTC_IT_SEC, ENABLE);
    /* Wait until last write operation on RTC registers has finished */
    RTC_WaitForLastTask();

    Delay(1000);
  }

#ifdef RTCClockOutput_Enable
  /* Enable PWR and BKP clocks */
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_PWR | RCC_APB1Periph_BKP, ENABLE);

  /* Allow access to BKP Domain */
  PWR_BackupAccessCmd(ENABLE);

  /* Disable the Tamper Pin */
  BKP_TamperPinCmd(DISABLE); /* To output RTCCLK/64 on Tamper pin, the tamper
                                 functionality must be disabled */

  /* Enable RTC Clock Output on Tamper Pin */
  BKP_RTCOutputConfig(BKP_RTCOutputSource_CalibClock);
#endif

  /* Clear reset flags */
  RCC_ClearFlag();
}

/**
  * @brief  Adjusts time.
  * @param  None
  * @retval None
  */
void Time_Adjust(uint32_t seconds)
{
  seconds = seconds + 1; // Take care of the one second used in the RTC Setup process

  /* RTC Configuration */
  RTC_Configuration();
  
  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();
  /* Change the current time */
  RTC_SetCounter(seconds);
  /* Wait until last write operation on RTC registers has finished */
  RTC_WaitForLastTask();

  BKP_WriteBackupRegister(BKP_DR1, 0xA5A5);
}

/**
  * @brief  Displays the current time.
  * @param  TimeVar: RTC counter value.
  * @retval None
  */
void Time_Display(u16 x, u16 y, u16 frontColor, u16 backColor, uint32_t TimeVar)
{
  char buffer[20];
  uint32_t THH = 0, TMM = 0, TSS = 0;

  /* Compute  hours */
  THH = TimeVar / 3600;
  /* Compute minutes */
  TMM = (TimeVar % 3600) / 60;
  /* Compute seconds */
  TSS = (TimeVar % 3600) % 60;

  sprintf(buffer, "Time: %0.2d:%0.2d:%0.2d", THH, TMM, TSS);
  Lcd_Text(x,y,buffer,14,frontColor,backColor);
}




void Delay(__IO uint32_t nTime)
{ 
  TimingDelay = nTime;

  while(TimingDelay != 0);
}

/**
  * @brief  Decrements the TimingDelay variable.
  * @param  None
  * @retval None
  */
void TimingDelay_Decrement(void)
{
  if (TimingDelay != 0x00)
  { 
    TimingDelay--;
  }
}





#ifdef  DEBUG
/*******************************************************************************
* Function Name  : assert_failed
* Description    : Reports the name of the source file and the source line number
*                  where the assert error has occurred.
* Input          : - file: pointer to the source file name
*                  - line: assert error line source number
* Output         : None
* Return         : None
*******************************************************************************/
void assert_failed(u8* file, u32 line)
{ 
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}
#endif

/******************* (C) COPYRIGHT 2007 STMicroelectronics *****END OF FILE****/
