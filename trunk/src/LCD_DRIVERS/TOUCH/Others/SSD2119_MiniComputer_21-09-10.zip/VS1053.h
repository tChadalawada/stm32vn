#include "stm32f10x.h"



//Opcode
#define VS_READ                        (0x03)
#define VS_WRITE                       (0x02)
//SCI_MODE register defines (p. 26 datasheet)
#define SM_DIFF      0
#define SM_SETTOZERO    1
#define SM_RESET    4
#define SM_OUTOFWAV    8
#define SM_PDOWN    16
#define SM_TESTS    32
#define  SM_STREAM    64
#define SM_PLUSV    128
#define  SM_DACT      256
#define  SM_SDIORD    512
#define  SM_SDISHARE    1024
#define  SM_SDINEW    2048
#define  SM_ADPCM    4096
#define  SM_ADPCM_HP  8192  
//Register
#define VS_MODE                        (0x00)   //Mode control
#define VS_STATUS                      (0x01)   //Status
#define VS_BASS                        (0x02)   //Built-in bass/treble enhancer
#define VS_CLOCKF                      (0x03)   //Clock freq + multiplier
#define VS1033_SC_MUL_2X               (0x4000)
#define VS1033_SC_MUL_3X               (0x8000)
#define VS1033_SC_MUL_4X               (0xC000)
#define VS1053_SC_MUL_2X               (0x2000)
#define VS1053_SC_MUL_3X               (0x6000)
#define VS1053_SC_MUL_4X               (0xA000)
#define VS_DECODETIME                  (0x04)   //Decode time in seconds
#define VS_AUDATA                      (0x05)   //Misc. audio data
#define VS_WRAM                        (0x06)   //RAM write/read
#define VS_WRAMADDR                    (0x07)   //Base address for RAM write/read
#define VS_HDAT0                       (0x08)   //Stream header data 0
#define VS_HDAT1                       (0x09)   //Stream header data 1
#define VS_AIADDR                      (0x0A)   //Start address of application
#define VS_VOL                         (0x0B)   //Volume control
//RAM Data
#define VS_RAM_ENDFILLBYTE             (0x1E06)  //End fill byte

#define VS1053_CS_HIGH  GPIO_SetBits(GPIOA,GPIO_Pin_2); Delay(1);
#define VS1053_CS_LOW   GPIO_ResetBits(GPIOA,GPIO_Pin_2); Delay(1);

#define VS1053_CLK_HIGH  GPIO_SetBits(GPIOA,GPIO_Pin_9); // CLK
#define VS1053_CLK_LOW   GPIO_ResetBits(GPIOA,GPIO_Pin_9); // CLK
#define VS1053_SDI_HIGH  GPIO_SetBits(GPIOA,GPIO_Pin_10); // MISO <- SO
#define VS1053_SDI_LOW   GPIO_ResetBits(GPIOA,GPIO_Pin_10); // MISO <- SO
#define VS1053_SDO_HIGH  GPIO_SetBits(GPIOA,GPIO_Pin_11); // MOSI -> SI
#define VS1053_SDO_LOW   GPIO_ResetBits(GPIOA,GPIO_Pin_11); // MOSI -> SI



void VS1053_Delayus(vu32 nCount);
void VS1053_Configuration(void);
void VS1053_GPIO_Configuration(void);

unsigned char VS1053_SendByte(unsigned char dt);

unsigned short int VS1053_Read(unsigned char address);
void VS1053_Write(unsigned char address, unsigned short int data);

void VS1053_SetVolume(u8 vol); //0 - 100%
void VS1053_Volume(int vol);

void VS1053_sineTest(unsigned char pitch);
void VS1053_StopsineTest(void);

void VS1053_SendStreamByte(u8 stream);
void VS1053_SendStream(u16 stream);

void VS1053_Bass(void);
void VS1053_SetTreblefreq(int freq); //1000 - 15000Hz
int VS1053_GetTreblefreq(void);
void VS1053_SetTrebleamp(int amp); //-8 - 7dB
int VS1053_GetTrebleamp(void);
void VS1053_SetBassfreq(int freq); //20 - 150Hz
int VS1053_GetBassfreq(void);
void VS1053_SetBassamp(int amp); //0 - 15dB
int VS1053_GetBassamp(void);
