#include "stm32f10x.h"
#include "MicrochipGraphics.h"
#include "MicrochipButton.h"


// My commands (Thomas Jespersen)
void DrawButton(u8 buttonID, u16 buttonState, u8 *pText, u8 textLength)
{ 
  #if buttonID <= MaxButtons
    if ((buttonState & BTN_DISABLED)) {
      buttons[buttonID].enabled = 0;
    } else {
      buttons[buttonID].enabled = 1;
    }
    BtnDraw(buttons[buttonID].left, buttons[buttonID].top, buttons[buttonID].right, buttons[buttonID].bottom, buttons[buttonID].radius, buttonState, pText, textLength);
  #else
    #error "The buttonID exceeds the limit of buttons (MaxButtons)"
  #endif
}

void CreateButton(u8 buttonID, u16 left, u16 top, u16 right, u16 bottom, u16 radius, u16 buttonState, u8 *pText, u8 textLength)
{
  #if buttonID <= MaxButtons
    buttons[buttonID].left = left;
    buttons[buttonID].top = top;
    buttons[buttonID].right = right;
    buttons[buttonID].bottom = bottom;
    buttons[buttonID].radius = radius;
    DrawButton(buttonID, buttonState, pText, textLength);
  #else
    #error "The buttonID exceeds the limit of buttons (MaxButtons)"
  #endif
}

u8 ButtonPressed(u8 buttonID, u16 TouchX, u16 TouchY)
{
  #if buttonID <= MaxButtons
    if (buttons[buttonID].enabled == 0) { return 0; }
    if (TouchX >= buttons[buttonID].left && TouchX <= buttons[buttonID].right && TouchY >= buttons[buttonID].top && TouchY <= buttons[buttonID].bottom) { 
      return 1;  // Button pressed
    } else {
      return 0;  // Button not pressed
    }
  #else
    #error "The buttonID exceeds the limit of buttons (MaxButtons)"
  #endif
}  
// My commands end (Thomas Jespersen)




/*********************************************************************
* Function: WORD BtnDraw(BUTTON *pB)
*
*
* Notes: This is the state machine to draw the button.
*
********************************************************************/
WORD BtnDraw(SHORT left, SHORT top, SHORT right, SHORT bottom, SHORT radius, SHORT buttonState, u8 *pText, u8 textLength)
{
    typedef enum
    {
        REMOVE,
        BEVEL_DRAW,
        RNDBUTTON_DRAW,
        TEXT_DRAW,
            #ifdef USE_BUTTON_MULTI_LINE
        CHECK_TEXT_DRAW,
            #endif
        TEXT_DRAW_RUN,
        FOCUS_DRAW,
    } BTN_DRAW_STATES;

    static BTN_DRAW_STATES state = REMOVE;
    static SHORT width, height;

        #ifdef USE_BUTTON_MULTI_LINE
    static SHORT charCtr = 0, lineCtr = 0;
    SHORT textWidth;
    XCHAR ch = 0;
        #endif
    WORD faceClr, embossLtClr, embossDkClr, xText, yText;
    u16 temp_color;


    switch(state)
    {
        case REMOVE:

            if((buttonState & BTN_HIDE))
            {                       // Hide the button (remove from screen)
                if(!Bar(left, top, right, bottom, CommonBkColor))
                {
                    return (0);
                }

                return (1);
            }

            /* Note: that width and height adjustment considers the following assumptions:
					1. if circular width = height = radius*2
					2. if vertical capsule width = radius*2
					3. if horizontal capsule height = radius*2
					4. radius must be less than or equal to width if height is greater than width
					5. radius must be less than or equal to height if width is greater than height
					6. if button is cornered, radius must be zero
			*/
            radius = radius;    // get radius
            width = (right - left) - (radius * 2);  // get width
            height = (bottom - top) - (radius * 2); // get height
            state = BEVEL_DRAW;

        case BEVEL_DRAW:
            if(!(buttonState & BTN_DISABLED))
            {
                if((buttonState & BTN_PRESSED))
                {
                    embossDkClr = EmbossLtColor;
                    embossLtClr = EmbossDkColor;
                    faceClr = Color1;
                }
                else
                {
                    embossLtClr = EmbossLtColor;
                    embossDkClr = EmbossDkColor;
                    faceClr = Color0;
                }
            }
            else
            {
                embossLtClr = EmbossLtColor;
                embossDkClr = EmbossDkColor;
                faceClr = ColorDisabled;
            }

            // This should be send to GOLPanelDrawTsk - see bottom
            if(!GOLPanelDrawTsk
            (
                left + radius,
                top + radius,
                right - radius,
                bottom - radius,
                radius,
                faceClr,
                embossLtClr,
                embossDkClr,
                //pB->pBitmap,
                GOL_EMBOSS_SIZE
            ))
            {
                return (0);
            }
            
            state = RNDBUTTON_DRAW;

        case RNDBUTTON_DRAW:
                #ifdef USE_BUTTON_MULTI_LINE
            state = CHECK_TEXT_DRAW;
                #else
            state = TEXT_DRAW;
                #endif
                #ifdef USE_BUTTON_MULTI_LINE

        case CHECK_TEXT_DRAW:
            if(pText != NULL)
            {
                if(!(buttonState & BTN_DISABLED))
                {
                    if((buttonState & BTN_PRESSED))
                    {
                        temp_color = TextColor1;
                    }
                    else
                    {
                         temp_color = TextColor0;
                    }
                }
                else
                {
                     temp_color = TextColorDisabled;
                }

                lineCtr = 0;
                charCtr = 0;
                state = TEXT_DRAW;
            }
            else
            {
                state = FOCUS_DRAW;
                goto rnd_button_draw_focus;
            }

        case TEXT_DRAW:
            button_draw_set_text_position : 
            textWidth = textLength*8;

            // check text alignment
            if((buttonState & BTN_TEXTRIGHT))
            {
                xText = right - (textWidth + GOL_EMBOSS_SIZE + 2);
            }
            else if((buttonState & BTN_TEXTLEFT))
            {
                xText = left + GOL_EMBOSS_SIZE + 2;
            }
            else
            {

                // centered	text in x direction
                xText = (left + right - textWidth) >> 1;
            }

            if(buttonState & BTN_TEXTTOP))
            {
                yText = top + GOL_EMBOSS_SIZE + (lineCtr * 16); // 16 is text height
            }
            else if((buttonState & BTN_TEXTBOTTOM))
            {
                yText = bottom - (GOL_EMBOSS_SIZE + 16) + (lineCtr * 16);
            }
            else
            {

                // centered	text in y direction
                yText = ((bottom + top - 16) >> 1) + (lineCtr * 16);
            }

            //MoveTo(xText, yText);
            state = TEXT_DRAW_RUN;            

        case TEXT_DRAW_RUN:
            Lcd_Text(xText, yText, pText, textLength, temp_color, faceClr);
            /*ch = *(pCurLine + charCtr);

            // output one character at time until a newline character or a NULL character is sampled
            while((0x0000 != ch) && (0x000A != ch))
            {
                if(!OutChar(ch))
                    return (0);                     // render the character
                charCtr++;                          // update to next character
                ch = *(pCurLine + charCtr);
            }

            // pCurText is updated for the next line
            if(ch == 0x000A)
            {                                       // new line character
                pCurLine = pCurLine + charCtr + 1;  // go to first char of next line
                lineCtr++;                          // update line counter
                charCtr = 0;                        // reset char counter
                goto button_draw_set_text_position; // continue to next line
            }

            // end of text string is reached no more lines to display
            else
            {
                SetClip(CLIP_DISABLE);              // remove clipping
                state = FOCUS_DRAW;                 // go back to IDLE state
            }*/

                #else

        case TEXT_DRAW:
            if(pText != 0)
            {
                if(!(buttonState &  BTN_DISABLED))
                {
                    if((buttonState & BTN_PRESSED))
                    {
                        temp_color = TextColor1;
                    }
                    else
                    {
                        temp_color = TextColor0;
                    }
                }
                else
                {
                    temp_color = TextColorDisabled;
                }


                // check text alignment
                if((buttonState & BTN_TEXTRIGHT))
                {
                    xText = right - ((8*textLength) + GOL_EMBOSS_SIZE + 2);
                }
                else if((buttonState &BTN_TEXTLEFT))
                {
                    xText = left + GOL_EMBOSS_SIZE + 2;
                }
                else
                {

                    // centered	text in x direction
                    xText = (left + right - (8*textLength)) >> 1;
                }

                if((buttonState & BTN_TEXTTOP))
                {
                    yText = top + GOL_EMBOSS_SIZE + 2;
                }
                else if((buttonState & BTN_TEXTBOTTOM))
                {
                    yText = bottom - (16 + GOL_EMBOSS_SIZE);
                }
                else
                {

                    // centered	text in y direction
                    yText = (bottom + top - 16) >> 1;
                }

                //MoveTo(xText, yText);
                
                state = TEXT_DRAW_RUN;           
            }
            else
            {
                state = FOCUS_DRAW;
                goto rnd_button_draw_focus;
            }

        case TEXT_DRAW_RUN:
            Lcd_Text(xText, yText, pText, textLength, temp_color, faceClr);
            state = FOCUS_DRAW;
                #endif // #ifdef USE_BUTTON_MULTI_LINE

        case FOCUS_DRAW:
            rnd_button_draw_focus : 

            if((buttonState & BTN_FOCUSED))
            {
                if((buttonState & BTN_PRESSED))
                {
                    temp_color = TextColor1;
                }
                else
                {
                    temp_color = TextColor0;
                }

                // check if the object has rounded corners or not
                if(!radius)
                {
                    if
                    (
                        !Rectangle
                            (
                                left + GOL_EMBOSS_SIZE + 2,
                                top + GOL_EMBOSS_SIZE + 2,
                                right - GOL_EMBOSS_SIZE - 2,
                                bottom - GOL_EMBOSS_SIZE - 2,
                                SOLID_LINE,
                                FOCUS_LINE,
                                temp_color
                            )
                    )
                    {
                        return (0);
                    }
                }
                else
                {

                    // original center is still the same, but radius is reduced
                    if
                    (
                        !Bevel
                            (
                                left + radius,
                                top + radius,
                                right - radius,
                                bottom - radius,
                                radius - 2 - GOL_EMBOSS_SIZE,
                                SOLID_LINE,
                                FOCUS_LINE,
                                temp_color
                            )
                    )
                    {
                        return (0);
                    }
                }

            }

            state = REMOVE;
            return (1);
    }

    return (1);
}

//#endif //#if defined (USE_BUTTON) || defined (USE_BUTTON_MULTI_LINE)








/*********************************************************************
* Function: WORD GOLPanelDrawTsk(void) 
*
* PreCondition: parameters must be set with
*               GOLRndPanelDraw(x,y,radius,width,height,faceClr,embossLtClr,
*								embossDkClr,pBitmap,embossSize)
*
* Input: None
*
* Output: Output: non-zero if drawing is completed
*
* Overview: draws a rounded panel on screen. Must be called repeatedly. Drawing is done
*           when it returns non-zero. 
*
* Note: none
*
********************************************************************/
/*SHORT   _rpnlX1,        // Center x position of upper left corner
_rpnlY1,                // Center y position of upper left corner
_rpnlX2,                // Center x position of lower right corner
_rpnlY2,                // Center y position of lower right corner
_rpnlR;                 // radius
WORD    _rpnlFaceColor, // face color
_rpnlEmbossLtColor,     // emboss light color
_rpnlEmbossDkColor,     // emboss dark color
_rpnlEmbossSize;        // emboss size
void    *_pRpnlBitmap = NULL;
*/
WORD GOLPanelDrawTsk(SHORT _rpnlX1, SHORT _rpnlY1, SHORT _rpnlX2, SHORT _rpnlY2, SHORT _rpnlR, WORD _rpnlFaceColor, WORD _rpnlEmbossLtColor, WORD _rpnlEmbossDkColor, WORD _rpnlEmbossSize)
{
    //#define SIN45 46341
        #ifndef USE_NONBLOCKING_CONFIG

    WORD    counter;

    if(_rpnlR)
    {

        // draw upper left portion of the embossed area
        Arc(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR - _rpnlEmbossSize, _rpnlR, 0xE1, _rpnlEmbossLtColor);

        // draw lower right portion of the embossed area
        Arc(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR - _rpnlEmbossSize, _rpnlR, 0x1E, _rpnlEmbossDkColor);
    }
    else
    {

        // object is rectangular panel draw the embossed areas
        counter = 1;
        while(counter < _rpnlEmbossSize)
        {
            Bar(_rpnlX1 + counter, _rpnlY1 + counter, _rpnlX2 - counter, _rpnlY1 + counter, _rpnlEmbossLtColor);    // draw top
            Bar(_rpnlX1 + counter, _rpnlY1 + counter, _rpnlX1 + counter, _rpnlY2 - counter, _rpnlEmbossLtColor);    // draw left
            counter++;
        }

        counter = 1;
        while(counter < _rpnlEmbossSize)
        {
            Bar(_rpnlX1 + counter, _rpnlY2 - counter, _rpnlX2 - counter, _rpnlY2 - counter, _rpnlEmbossDkColor);    // draw bottom
            Bar(_rpnlX2 - counter, _rpnlY1 + counter, _rpnlX2 - counter, _rpnlY2 - counter, _rpnlEmbossDkColor);    // draw right	
            counter++;
        }
    }

    // draw the face color
    if(_rpnlR)
        FillBevel(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR - _rpnlEmbossSize, _rpnlFaceColor);
    else
        Bar(_rpnlX1 + _rpnlEmbossSize, _rpnlY1 + _rpnlEmbossSize, _rpnlX2 - _rpnlEmbossSize, _rpnlY2 - _rpnlEmbossSize, _rpnlFaceColor);

            #if (COLOR_DEPTH == 1)
    if(_rpnlFaceColor == BLACK)
    {
        if(_rpnlR)
            Bevel(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR - (_rpnlEmbossSize - 1), NORMAL_LINE, SOLID_LINE, WHITE);
        else
            Bevel
            (
                _rpnlX1 + (_rpnlEmbossSize - 1),
                _rpnlY1 + (_rpnlEmbossSize - 1),
                _rpnlX2 - (_rpnlEmbossSize - 1),
                _rpnlY2 - (_rpnlEmbossSize - 1),
                0,
                NORMAL_LINE,
                SOLID_LINE,
                WHITE
            );
    }

            #endif

    // draw bitmap
    /*if(_pRpnlBitmap != NULL)
    {
        PutImage
        (
            (((_rpnlX2 + _rpnlX1) - (GetImageWidth((void *)_pRpnlBitmap))) >> 1) + 1,
            (((_rpnlY2 + _rpnlY1) - (GetImageHeight((void *)_pRpnlBitmap))) >> 1) + 1,
            _pRpnlBitmap,
            IMAGE_NORMAL
        );
    }*/

    // check if we need to draw the frame
    /*if
    (
        (_pRpnlBitmap == NULL) ||
        (
            ((_rpnlX2 - _rpnlX1 + _rpnlR) >= GetImageWidth((void *)_pRpnlBitmap)) &&
            ((_rpnlY2 - _rpnlY1 + _rpnlR) >= GetImageHeight((void *)_pRpnlBitmap))
        )
    )*/
    {

        // draw the outline
        Bevel(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR, NORMAL_LINE, SOLID_LINE, _rpnlEmbossDkColor);
    }

    return (1);

        #else

    typedef enum
    {
        BEGIN,
        ARC1,
        DRAW_EMBOSS1,
        DRAW_EMBOSS2,
        DRAW_EMBOSS3,
        DRAW_EMBOSS4,
        DRAW_FACECOLOR,
                #if (COLOR_DEPTH == 1)
        DRAW_INNERFRAME,
                #endif
        DRAW_FRAME,
        DRAW_IMAGE,
    } ROUND_PANEL_DRAW_STATES;

    static ROUND_PANEL_DRAW_STATES state = BEGIN;
    static WORD counter;

    while(1)
    {
        switch(state)
        {
            case BEGIN:
                if(_rpnlR)
                {

                    // draw upper left portion of the embossed area
                    if(!Arc(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR - _rpnlEmbossSize, _rpnlR, 0xE1, _rpnlEmbossLtColor))
                        return (0);
                    state = ARC1;
                }
                else
                {
                    state = DRAW_EMBOSS1;
                    counter = 1;
                    goto rnd_panel_draw_emboss;
                }

            case ARC1:

                // draw upper left portion of the embossed area
                if(!Arc(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR - _rpnlEmbossSize, _rpnlR, 0x1E, _rpnlEmbossDkColor))
                    return (0);
                state = DRAW_FACECOLOR;
                goto rnd_panel_draw_facecolor;

            // now draw the upper portion of the embossed area
            case DRAW_EMBOSS1:
                rnd_panel_draw_emboss :
                while(counter < _rpnlEmbossSize)
                {

                    // draw top
                    if(!Bar(_rpnlX1 + counter, _rpnlY1 + counter, _rpnlX2 - counter, _rpnlY1 + counter, _rpnlEmbossLtColor))
                    {
                        return (0);
                    }

                    counter++;
                }

                counter = 1;
                state = DRAW_EMBOSS2;
                break;

            case DRAW_EMBOSS2:
                while(counter < _rpnlEmbossSize)
                {

                    // draw left   	
                    if(!Bar(_rpnlX1 + counter, _rpnlY1 + counter, _rpnlX1 + counter, _rpnlY2 - counter, _rpnlEmbossLtColor))
                    {
                        return (0);
                    }

                    counter++;
                }

                counter = 1;
                state = DRAW_EMBOSS3;
                break;

            // now draw the lower portion of the embossed area
            case DRAW_EMBOSS3:                
                while(counter < _rpnlEmbossSize)
                {

                    // draw bottom
                    if(!Bar(_rpnlX1 + counter, _rpnlY2 - counter, _rpnlX2 - counter, _rpnlY2 - counter, _rpnlEmbossDkColor))
                    {
                        return (0);
                    }

                    counter++;
                }

                counter = 1;
                state = DRAW_EMBOSS4;
                break;

            case DRAW_EMBOSS4:
                while(counter < _rpnlEmbossSize)
                {

                    // draw right	   	
                    if(!Bar(_rpnlX2 - counter, _rpnlY1 + counter, _rpnlX2 - counter, _rpnlY2 - counter, _rpnlEmbossDkColor))
                    {
                        return (0);
                    }

                    counter++;
                }

                state = DRAW_FACECOLOR;
                break;

            // draw the face color
            case DRAW_FACECOLOR:
                rnd_panel_draw_facecolor :
                if(_rpnlR)
                {
                    if(!FillBevel(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR - _rpnlEmbossSize, _rpnlFaceColor))
                        return (0);
                }
                else
                {
                    if
                    (
                        !Bar
                            (
                                _rpnlX1 + _rpnlEmbossSize,
                                _rpnlY1 + _rpnlEmbossSize,
                                _rpnlX2 - _rpnlEmbossSize,
                                _rpnlY2 - _rpnlEmbossSize,
                                _rpnlFaceColor
                            )
                    )
                    {
                        return (0);
                    }
                }

                state = DRAW_IMAGE;
                break;

            case DRAW_IMAGE:
                if(_pRpnlBitmap != NULL)
                {
                    /*if
                    (
                        !PutImage
                            (
                                ((_rpnlX2 + _rpnlX1 - GetImageWidth((void *)_pRpnlBitmap)) >> 1) + 1,
                                ((_rpnlY2 + _rpnlY1 - GetImageHeight((void *)_pRpnlBitmap)) >> 1) + 1,
                                _pRpnlBitmap,
                                IMAGE_NORMAL
                            )
                    )
                    {
                        return (0);
                    }*/
                }

                        #if (COLOR_DEPTH == 1)
                state = DRAW_INNERFRAME;
                break;
                        #else
                state = DRAW_FRAME;
                        #endif
                break;

                        #if (COLOR_DEPTH == 1)

            case DRAW_INNERFRAME:
                if(_rpnlFaceColor == BLACK)
                {
					if(_rpnlR)
					{
                        if(!Bevel(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR - (_rpnlEmbossSize - 1), NORMAL_LINE, SOLID_LINE, WHITE))
                        {
                            return (0);
                        }    
					}
					else
    				{
					    if(!Bevel(  _rpnlX1 + (_rpnlEmbossSize - 1),
                                    _rpnlY1 + (_rpnlEmbossSize - 1),
                                    _rpnlX2 - (_rpnlEmbossSize - 1),
                                    _rpnlY2 - (_rpnlEmbossSize - 1),
                                    0, 
                                    NORMAL_LINE,
                                    SOLID_LINE,
                                    WHITE))
				        {
							return (0);
						}
					}
                }

                state = DRAW_FRAME;
                break;
                        #endif

            case DRAW_FRAME:

                // check if we need to draw the frame
                /*if
                (
                    (_pRpnlBitmap == NULL) ||
                    (
                        ((_rpnlX2 - _rpnlX1 + _rpnlR) >= GetImageWidth((void *)_pRpnlBitmap)) &&
                        ((_rpnlY2 - _rpnlY1 + _rpnlR) >= GetImageHeight((void *)_pRpnlBitmap))
                    )
                )
                {

                    // draw the outline frame
                            #if (COLOR_DEPTH == 1)
                    SetColor(WHITE);
                            #else
                    SetColor(_rpnlEmbossDkColor);
                            #endif
                    if(!Bevel(_rpnlX1, _rpnlY1, _rpnlX2, _rpnlY2, _rpnlR))
                    {
                        return (0);
                    }
                }*/

                state = BEGIN;
                return (1);
        }   // end of switch
    }       // end of while
        #endif //#ifndef USE_NONBLOCKING_CONFIG
}


