void GPIO_Blink(void);

int main(void)
{

    //automatically added by CoIDE
	GPIO_Blink();

	while(1)
    {
    }
}

