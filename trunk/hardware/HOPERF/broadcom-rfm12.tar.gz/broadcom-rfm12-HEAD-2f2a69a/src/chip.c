/*
 * rfm12.c - GPIO interface driver for RFM12 low-cost FSK transmitter
 *
 * Copyright (C) 2008,2009 Stefan Siegl <stesie@brokenpipe.de>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <linux/spinlock.h>
#include "rfm12.h"

static spinlock_t chip_lock; // = SPIN_LOCK_UNLOCKED;

static enum {
	CHIP_IDLE,
	CHIP_RX,
	CHIP_RX_WAIT_LEN_2,
	CHIP_RX_DATA,

	CHIP_TX,
	CHIP_TX_PREAMBLE_1,
	CHIP_TX_PREAMBLE_2,
	CHIP_TX_PREFIX_1,
	CHIP_TX_PREFIX_2,
	CHIP_TX_SIZE_HI,
	CHIP_TX_SIZE_LO,
	CHIP_TX_DATA,
	CHIP_TX_DATAEND,
	CHIP_TX_SUFFIX_1,
	CHIP_TX_SUFFIX_2,
	CHIP_TX_END,

} chip_status;			/* Locked by chip_lock. */

static struct sk_buff *rx_packet, *tx_packet;
static int packet_len;
static int packet_index;
static int routed_packet;



static u16
chip_trans (u16 word)
{
	u16 inword;

	set_cs (0);
	inword = spi_trx_word (word);
	set_cs (1);
	spi_delay ();

	if (word == 0) {
		DEBUG (MODULE_NAME ": status: 0x%04x\n", inword);

		if (inword & 0x2000)
			printk (KERN_INFO MODULE_NAME ": aieee! fifo over- or "
				"underrun.\n");
	}

	return inword;
}

static inline u16
chip_trans_lock (u16 word)
{
	unsigned long flags;

	spin_lock_irqsave (&chip_lock, flags);
	u16 r = chip_trans (word);
	spin_unlock_irqrestore (&chip_lock, flags);

	return r;
}


void
chip_setbandwidth(u8 bandwidth, u8 gain, u8 drssi)
{
	chip_trans_lock (0x9400 | ((bandwidth & 7) << 5)
			 | ((gain & 3) << 3) | (drssi & 7));
}


void
chip_setfreq(u16 freq)
{	
	if (freq < 96)		/* 430,2400MHz */
		freq = 96;

	else if (freq > 3903)	/* 439,7575MHz */
		freq = 3903;

	chip_trans_lock (0xA000 | freq);
}


void
chip_setbaud(u16 baud)
{
	if (baud < 663)
		return;

	/* Baudrate = 344827,58621 / (R + 1) / (1 + CS * 7) */
	if (baud < 5400)
		chip_trans_lock(0xC680 | ((43104 / baud) - 1));
	else
		chip_trans_lock(0xC600 | ((344828UL / baud) - 1));
}


void
chip_setpower(u8 power, u8 mod)
{	
	chip_trans_lock (0x9800 | (power & 7) | ((mod & 15) << 4));
}


void
chip_init (void)
{
	spin_lock_init (&chip_lock);

	chip_trans (0xC0E0);	/* AVR CLK: 10MHz */
	chip_trans (0x80D7);	/* Enable FIFO */
	chip_trans (0xC2AB);	/* Data Filter: internal */
	chip_trans (0xCA81);	/* Set FIFO mode */
	chip_trans (0xE000);	/* disable wakeuptimer */
	chip_trans (0xC800);	/* disable low duty cycle */
	chip_trans (0xC4F7);	/* autotuning: -10kHz...+7,5kHz */
	chip_trans (0x0000);

	chip_setfreq (RFM12FREQ (433.92));
	chip_setbandwidth (5, 1, 4);
	chip_setbaud (8620);
	chip_setpower (0, 2);
}


void
chip_log_status (void)
{
	chip_trans_lock (0x0000);
}


/* Restart RX, chip_lock must be held. */
void
chip_rxstart (void)
{
	chip_trans (0x82C8);	/* RX on */
	chip_trans (0xCA81);	/* set FIFO mode */
	chip_trans (0xCA83);	/* enable FIFO */

	chip_status = CHIP_RX;
}


/* Start TX, chip_lock must be held. */
static void
chip_txstart (void)
{
	chip_trans (0x8238);	/* TX on */
	chip_status = CHIP_TX;
}


/* Interrupt handler. */
void
chip_handler (void)
{
	int byte;

	spin_lock (&chip_lock);

	switch (chip_status) {
	case CHIP_RX:
		byte = chip_trans (0xB000) & 0xFF;

		routed_packet = (byte & 0x80) != 0;
		packet_len = (byte & 0x7F) << 8;
		chip_status ++;
		break;

	case CHIP_RX_WAIT_LEN_2:
		packet_len |= (chip_trans (0xB000) & 0xFF);
		DEBUG (MODULE_NAME ": RX: len=%d\n", packet_len);

		if (packet_len > 0 && packet_len <= 1500) {
			packet_index = 0;
			chip_status = CHIP_RX_DATA;

			if (!(rx_packet = alloc_skb (packet_len, GFP_ATOMIC)))
				chip_rxstart (); /* discard packet. */

		} else {
			/* Packet size invalid, error out. */
			chip_trans (0x0000); /* get and log status */
			chip_rxstart ();

			STATS->rx_errors ++;
			STATS->rx_length_errors ++;
		}
		break;

	case CHIP_RX_DATA:
		byte = chip_trans (0xB000) & 0xFF;
		skb_put (rx_packet, 1)[0] = byte;

		if (++ packet_index == packet_len) {
			DEBUG (MODULE_NAME ": RX: complete.\n");

			STATS->rx_packets ++;
			STATS->rx_bytes += packet_len;

			if (routed_packet) {
				DEBUG (MODULE_NAME ": discarding r'td pkt.\n");
				dev_kfree_skb_irq (rx_packet);
			}
			else
				rfm12_net_rx (rx_packet);
			rx_packet = NULL;

			if (tx_packet)
				/* send queued packet now. */
				chip_txstart ();
			else
				chip_rxstart ();
		}

		break;

	case CHIP_TX:
		STATS->tx_packets ++;

	case CHIP_TX_PREAMBLE_1:
	case CHIP_TX_PREAMBLE_2:
		chip_trans (0xB8AA);
		chip_status ++;
		break;

	case CHIP_TX_PREFIX_1:
		chip_trans (0xB82D);
		chip_status ++;
		break;

	case CHIP_TX_PREFIX_2:
		chip_trans (0xB8D4);
		chip_status ++;
		break;

	case CHIP_TX_SIZE_HI:
		chip_trans (0xB800 | ((tx_packet->len >> 8) & 0xFF));
		chip_status ++;
		break;

	case CHIP_TX_SIZE_LO:
		chip_trans (0xB800 | (tx_packet->len & 0xFF));
		chip_status ++;
		break;

	case CHIP_TX_DATA:
		STATS->tx_bytes ++;
		chip_trans (0xB800 | (tx_packet->data[0] & 0xFF));
		skb_pull (tx_packet, 1);
		if (!tx_packet->len)
			chip_status = CHIP_TX_SUFFIX_1;
		break;

	case CHIP_TX_SUFFIX_1:
	case CHIP_TX_SUFFIX_2:
		chip_trans (0xB8AA);
		chip_status ++;
		break;

	case CHIP_TX_END:
		chip_trans (0x8208); /* TX off */
		DEBUG (MODULE_NAME ": TX: complete.\n");

		dev_kfree_skb_irq (tx_packet);
		tx_packet = NULL;

		chip_rxstart ();
		rfm12_net_wake_queue ();
		break;

	default:
		chip_trans (0x0000); /* dummy read. */
	}

	spin_unlock (&chip_lock);
}


int
chip_queue_tx (struct sk_buff *skb)
{
	int ret = 0;
	unsigned long flags;

	spin_lock_irqsave (&chip_lock, flags);

	if (chip_status <= CHIP_RX) {
		/* Chip is inactive, we can transmit immediately. */
		tx_packet = skb;
		chip_txstart ();
	}

	else if (tx_packet == NULL)
		/* Chip is already active (receiving), queue packet. */
		tx_packet = skb;

	else {
		ret = 1;	/* error */
		STATS->tx_dropped ++;
	}

	spin_unlock_irqrestore (&chip_lock, flags);
	return ret;
}
