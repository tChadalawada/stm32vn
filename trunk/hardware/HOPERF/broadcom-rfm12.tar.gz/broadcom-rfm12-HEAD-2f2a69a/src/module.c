/*
 * rfm12.c - GPIO interface driver for RFM12 low-cost FSK transmitter
 *
 * Copyright (C) 2008 Stefan Siegl <stesie@brokenpipe.de>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <linux/module.h>
#include <linux/kmod.h>

#include "rfm12.h"

static struct timer_list rfm12_timer;

static void
rfm12_status_timer (void)
{
	chip_log_status ();

	/* Update timer to expire in 10 seconds. */
	del_timer (&rfm12_timer);
	rfm12_timer.expires = jiffies + 10 * HZ;
	add_timer (&rfm12_timer);
}

static int __init
rfm12_init (void)
{
	DEBUG (MODULE_NAME ": rfm12_init called.\n");

	gpio_init ();

	chip_init ();
	gpio_interrupt_enable ();

	chip_rxstart ();
	chip_log_status ();

	if (rfm12_net_register ())
		return 1;

	init_timer (&rfm12_timer);
	rfm12_timer.expires = jiffies + HZ; /* timeout after one second. */
	rfm12_timer.function = (void *) rfm12_status_timer;
	add_timer (&rfm12_timer);

	return 0;
}


static void __exit
rfm12_exit (void)
{
	DEBUG (MODULE_NAME ": rfm12_exit called.\n");

	del_timer (&rfm12_timer);
	rfm12_net_unregister ();
	gpio_exit ();
}


module_init (rfm12_init);
module_exit (rfm12_exit);

MODULE_AUTHOR ("Stefan Siegl");
MODULE_LICENSE ("GPL");
