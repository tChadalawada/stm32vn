/*
 * netdev.c - GPIO interface driver for RFM12 low-cost FSK transmitter
 *
 * Copyright (C) 2008 Stefan Siegl <stesie@brokenpipe.de>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <linux/netdevice.h>
#include <linux/if_arp.h>

#include "rfm12.h"

static int
rfm12_net_open (struct net_device *dev)
{
	netif_start_queue(dev);
        return 0;
}


static int
rfm12_net_close(struct net_device *dev)
{
        netif_stop_queue(dev);
        return 0;
}


static int
rfm12_net_xmit (struct sk_buff *skb, struct net_device *dev)
{
	DEBUG (MODULE_NAME ": TX: len=%d.\n", skb->len);

	netif_stop_queue (dev);

	if (chip_queue_tx (skb)) {
		printk (KERN_ERR MODULE_NAME ": BUG. TX ring full when "
		       "queue awake!\n");
		return 1;
	}

	return 0;
}


static struct net_device_stats *
rfm12_net_stats (struct net_device *dev)
{
	return (struct net_device_stats *) dev->priv;
}


static int
rfm12_net_init (struct net_device *dev)
{
	DEBUG (MODULE_NAME ": rfm12_net_init.\n");

	dev->hard_header_len = 0;
	dev->addr_len = 0;
	dev->mtu = 1280;

	dev->type = ARPHRD_NONE;
	dev->flags = IFF_NOARP | IFF_MULTICAST | IFF_BROADCAST;
	dev->tx_queue_len = 10;

	dev->priv = kmalloc (sizeof (struct net_device_stats), GFP_KERNEL);
	if (! dev->priv)
		return -ENOMEM;
	memset (dev->priv, 0, sizeof (struct net_device_stats));

	return 0;
}


struct net_device rfm12_dev = { 
init:            rfm12_net_init,
open:            rfm12_net_open,
stop:            rfm12_net_close,
hard_start_xmit: rfm12_net_xmit,
get_stats:       rfm12_net_stats,
};

int
rfm12_net_register (void)
{
	int result = 0;

	strcpy (rfm12_dev.name, "rfm12");
	if ((result = register_netdev (&rfm12_dev)))
		printk (MODULE_NAME ": register_netdev failed: %d\n", result);

	return result;	
}


void
rfm12_net_unregister (void)
{
	unregister_netdev (&rfm12_dev);
}


void
rfm12_net_rx (struct sk_buff *skb)
{
	skb->dev = &rfm12_dev;
	skb->mac.raw = skb->data;

	switch ((skb->data[0] & 0xF0) >> 4) {
	case 4:
		skb->protocol = __constant_htons(ETH_P_IP);
		break;
	case 6:
		skb->protocol = __constant_htons(ETH_P_IPV6);
		break;
	default:
		printk (MODULE_NAME ": rfm12_net_rx: failed to detect "
		        "protocol: 0x%02x%02x\n", skb->data[0], skb->data[1]);
		dev_kfree_skb_irq (skb);
		return;
	}

	netif_rx (skb);

	rfm12_dev.last_rx = jiffies;
}


void
rfm12_net_wake_queue (void)
{
	netif_wake_queue (&rfm12_dev);
}
