/*
 * gpio.c - GPIO interface driver for RFM12 low-cost FSK transmitter
 *
 * Copyright (C) 2008 Stefan Siegl <stesie@brokenpipe.de>
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 */

#include <linux/module.h>
#include <linux/kmod.h>

#include "rfm12.h"


static irqreturn_t
gpio_handler (int irq, void *dev_id, struct pt_regs *regs)
{
	u32 in = gpio_in () & GPIO_INT;
	/* gpio_intpolarity (GPIO_INT, in); */

	if (in) {
		/* printk (MODULE_NAME ": interrupt low->high.\n"); */
		return;		/* rfm12 interrupt pin is inverted,
				   i.e. the line has been released now. */
	}

	/* printk (MODULE_NAME ": interrupt high->low.\n"); */
	chip_handler ();
}


void
gpio_init (void)
{
	gpio_outen (GPIO_MASK, GPIO_OUTEN);
	gpio_control (GPIO_MASK, 0);

	/* pull chip-select high */
	set_cs (1);
	set_sck (0);

}


void
gpio_interrupt_enable (void)
{
	int polarity = GPIO_INT; //gpio_in () & GPIO_INT;
	gpio_intpolarity (GPIO_INT, polarity);
	gpio_intmask (GPIO_INT, GPIO_INT);

	gpio_set_irqenable (1, gpio_handler);
}


void
gpio_exit (void)
{
	gpio_intmask (GPIO_INT, 0);
	gpio_set_irqenable (0, gpio_handler);
}
