RFM70 demo for DB038 using MPLAB / HiTecC

The RFM70 is on DwarfBus C. 
Remove the two motor driver chips to avoid any interference.

http://www.voti.nl/rfm70
