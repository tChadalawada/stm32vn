//
// Hi-Tech Lite test application for DB038 board with 16F887:
// using an RFM70 transciever
//
// Loosely based on (and compatible with) on 
// the example application provided by HopeRF
//
// $Id: main-rfm70-test.c,v 1.1 2011/12/24 13:47:21 Wouter Exp $
//
// (c) Wouter van Ooijen - wouter@voti.nl
//
// Copying and distribution of this file, with or without modification,
// are permitted in any medium without royalty provided the copyright
// notice and this notice are preserved.  This file is offered as-is,
// without any warranty.
// 

#include "rfm70.h"
#include "rfm70-config.h"

#define GREEN_LED( x )		PIN_COPY( PORTD, 0, !(x) )
#define RED_LED( x )        PIN_COPY( PORTD, 1, !(x) )

#define GREEN_LED_OUT() 		TRISD0=0;
#define RED_LED_OUT()			TRISD1=0;


void main( void ){

    unsigned char n = 0;
    unsigned char transmit_led = 0;
    unsigned char receive_led = 0;
	unsigned char len, i, chksum, pipe;
	unsigned char rx_buf[ RFM70_MAX_PACKET_LEN ];
    const unsigned char tx_buf[17]={
       0x30,0x31,0x32,0x33,0x34,0x35,0x36,0x37,0x38,
       0x39,0x3a,0x3b,0x3c,0x3d,0x3e,0x3f,0x78};

    ANSEL = 0;
    ANSELH = 0;

    TRISD = 0;
    TRISE = 0;
    TRISA2 = 0;
    PIN_SET( PORTA, 2 );
    PORT_SET( PORTE, 4 );
    PORT_SET( PORTD, 0xFF );
	
	ANSEL = 0;
 	ANSELH = 0;
	WPUB = 0;	

	RED_LED_OUT();
	GREEN_LED_OUT();
	
	rfm70_init();

	while(1){
        wait_ms( 2 );

        RED_LED( transmit_led > 0 );
        if( transmit_led > 0 ){ transmit_led--; }

        GREEN_LED( receive_led > 0 );
        if( receive_led > 0 ){ receive_led--; }
       
        if( ++n > 250 ){
	       rfm70_mode_transmit();
	       rfm70_transmit_message_once( tx_buf, 17 ); 
           WAIT_US( 100 ); 	 	
           rfm70_mode_receive(); 
	       transmit_led = 20;	
           n = 0; 	
        }

        if( rfm70_receive( &pipe, &rx_buf, &len )){
	       chksum = 0;
           for(i=0;i<16;i++){
		      chksum +=rx_buf[i]; 
		   }

		   if(chksum==rx_buf[16]&&rx_buf[0]==0x30){
		      receive_led = 20;
		   }	
		   rfm70_register_write( RFM70_CMD_FLUSH_RX,0 );
   	    }
	}
}

