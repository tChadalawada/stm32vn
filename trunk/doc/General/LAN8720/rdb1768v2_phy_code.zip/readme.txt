These files are for the FreeRTOS demo for the code-red rdb1768v2 PCB.
The changed files are in FreeRTOS\Demo\CORTEX_LPC1768_GCC_RedSuite\src\webserver
emaclan8720.c should replace emac.c  This installs changed code for the new phy.
Replace EthDev_LPC17xx.h  The removes phy constants from the ethernet phy.

These change the code to work with an SMSC LAN8720 ethernet phy,
the phy on the rdb1768v2.
The older code for v1 is now called emacDP83848.c
