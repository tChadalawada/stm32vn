These files are used to support FreeRTOS v7 with the LAN8720 PHY
