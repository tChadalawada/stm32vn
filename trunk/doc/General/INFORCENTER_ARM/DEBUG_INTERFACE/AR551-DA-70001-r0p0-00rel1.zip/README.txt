ARM� Debug Interface v5
=======================

This zip file contains two documents:

   * IHI0031A_ARM_debug_interface.pdf

     This is the "ARM� Debug Interface v5 Architecture Specification,"
     covering ADIv5 version 5.0.


   * DSA09-PRDC-008772-1-0_ARM_debug_interface_v5_supplement.pdf

     This is the "ARM� Debug Interface v5 Architecture Specification ADIv5.1
     Supplement," an update to ARM� Debug Interface v5 Architecture
     Specification. It includes errata and new features for ADIv5.

     The new features described in the supplement represent a minor revision
     of the architecture specification, and hence the architecture version
     number is v5.1. The new features are backwards compatible with v5.0;
     the version documented by the "ARM� Debug Interface v5 Architecture
     Specification."

The terms "ARM Debug Interface v5" and "ADIv5" refer to the major revision of
ADI, that is, to v5.0, v5.1 or any future minor revision of ADIv5.


This notice copyright (C) 2009 ARM Limited. All rights reserved.
