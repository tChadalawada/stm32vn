/******************************************************************
*  Copyright (C) 2009 Ram Narula <ram@pluslab.com> 
*  Filename: main.cpp
*  Version: 0.31
*  Date: 06 August 2009
*  Information: http://www.xduino.com/    
******************************************************************/
/******************************************************************
*   This file is part of Xduino
*
*   Xduino is free software: you can redistribute it and/or modify
*   it under the terms of the GNU Lesser General Public License as published by
*   the Free Software Foundation, either version 3 of the License, or
*   (at your option) any later version.
*	
*   Xduino is distributed in the hope that it will be useful,
*   but WITHOUT ANY WARRANTY; without even the implied warranty of
*   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
*   GNU Lesser General Public License for more details.
*
*   You should have received a copy of the GNU Lesser General Public License
*   along with Xduino.  If not, see <http://www.gnu.org/licenses/>.
******************************************************************/
/* Xduino v0.31 */

#include "main.h"
using namespace compatArduino;

void InterruptPB9(void)
{
Serial1.printf("(interrupt 9!!! %d)\r\n",digitalRead(PB9));
}


void InterruptPB8(void)
{
Serial1.printf("(interrupt 8!!! %d)\r\n",digitalRead(PB8));
}


int LedPin = PB7;		// as labelled on ARM Cortex-M3 board



int main(void)
{

double fnumber=1234.5678;
char myinput;

	doInit(); 				//Initialize Xduino components, this line is required

	Serial1.begin(115200); 	//USART1
	
	
	Serial1.printf("Starting Xduino (v%f) example program...",XDUINO_VERSION);
	Serial1.printf("hello!! %d %d %d\r\n",1,2,3);
	Serial1.printf("The floating point number is %f \r\n",fnumber);
		
	pinMode(LedPin,OUTPUT);
	pinMode(PB1,OUTPUT);
	pinMode(PB8,INPUT);
	pinMode(PB9,INPUT);
	
	digitalWrite(PB1,HIGH);
	
	attachInterrupt(PB9,InterruptPB9,CHANGE);
	attachInterrupt(PB8,InterruptPB8,RISING);
		

while(1)
{
		if(Serial1.available())
		{
			myinput=Serial1.read();
			Serial1.printf("This system has been up for %lu milliseconds.\r\n",millis());
			
			if(myinput=='a') { digitalWrite(PB1,HIGH); }	// press a to turn PB1 to HIGH state
			if(myinput=='b') { digitalWrite(PB1,LOW); }	// press b to turn PB1 to HIGH state
			if(myinput=='n') { noInterrupts(); }			// press n to disable all existing interrupts
			if(myinput=='i') { interrupts(); }			// press i to enable all existing interrupts
			Serial1.printf("Input is %c ...\r\n",myinput);
		}
				
		for(int i=0;i<=0x0FFF;i+=0xFF)	// smoothly turn PA4 (DAC port 1) on
		{
			analogWrite(1,i);
			delay(50);
		}
  		
		for(int j=0x0FFF;j>=0;j-=0xFF)	// smoothly turn PA4 (DAC port 1) off
		{
			analogWrite(1,j);
			delay(50);
		}
		
		analogWrite(1,0xFFF);			// Turn on PA4 fully at once 
		delay(100);
		digitalWrite(LedPin,LOW); 		// Turn off PA4 fully at once 
		delay(100);
		
}	//## END while(1)

} //## END main()

