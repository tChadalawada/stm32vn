/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include <cstring>
#include "gpio/GpioPort.h"
#include "timing/MillisecondTimer.h"
#include "display/graphic/tft/ili9325/ILI9325ParallelLcdInterface262K.h"
#include "display/graphic/GraphicsLibrary.h"
#include "display/graphic/RAMFonts.h"
#include "display/graphic/RAMBitmapFont.h"
#include "string/StringUtil.h"


using namespace stm32plus;
using namespace stm32plus::display;


/*
 * ILI9325 LCD test, show a looping graphics demo
 */

class ILI9325Test {

	protected:
		ILI9325Gamma *_gamma; 									// gamma settings for the panel
		ILI9325ParallelLcdInterface262K *_lcd; 	// 262K colour interface to the ILI9325
		Fsmc8080Lcd *_fsmc; 										// FSMC driving parameters
		GraphicsLibrary *_gl; 									// graphics library attached to LCD
		Font *_font; 														// font that we'll use

		uint32_t _start;

	public:

		/*
		 * Demo setup and preparation
		 */

		void run() {

			// set up the LCD
			initLcd();

			// we want a graphics library and a font to play with
			_gl=new GraphicsLibrary(_lcd->getDisplayDeviceGraphics());
			_font=new RAMBitmapFont(Font_KYROU_9_REGULAR_8);

			// now we show the demo in an infinite loop

			for(;;)
				showDemo();
		}

		/*
		 * show the demo
		 */

		void showDemo() {
			ellipseTest();
			rectTest();
			textTest();
			clearTest();
			scrollTest();
			lineTest();
		}

		/*
		 * initialise the LCD panel
		 */

		void initLcd() {

			// we've got the backlight on PD13 and RESET on PE1
			GpioPort pe(GPIOE),pd(GPIOD);

			pe.initialise(GPIO_Speed_50MHz,GPIO_Mode_Out_PP,GPIO_Pin_1);
			pd.initialise(GPIO_Speed_50MHz,GPIO_Mode_Out_PP,GPIO_Pin_13);

			// turn on the lights
			pd.set(GPIO_Pin_13);

			// set up some gamma values for this panel
			_gamma=new ILI9325Gamma(0x0006,0x0101,0x0003,0x0106,0x0b02,0x0302,0x0707,0x0007,0x0600,0x020b);

			// set up the FSMC timing for this panel
			Fsmc8080LcdTiming fsmcTiming(2,5);

			// set up the FSMC on bank 1 with A16 as the RS line (this is compatible with 100 pin devices)
			_fsmc=new Fsmc8080Lcd(FSMC_Bank1_NORSRAM1,fsmcTiming,16,pd[11]);

			// create the LCD interface in portrait mode
			// this will power it up and do the reset sequence
			_lcd=new ILI9325ParallelLcdInterface262K(pe[1],*_fsmc,Orientation::Portrait,*_gamma);
		}


		/*
		 * Randomly place a text string around the display
		 */

		void textTest() {
			prompt("Opaque text test");

			int i;
			const char *str="The quick brown fox";
			Size size;
			Point p;

			size=_gl->measureString(*_font,str);

			for(i=0;i<3000;i++) {

				p.X=rand() % (_gl->getXmax()-size.Width);
				p.Y=rand() % (_gl->getYmax()-size.Height);

				_gl->setForeground(rand());
				_gl->moveTo(p);
				_gl->writeString(*_font,str,true);
			}
		}


		/*
		 * Show expanding filled ellipses around the screen
		 */

		void ellipseTest() {

			int16_t i,widthStep,heightStep;
			uint32_t cr;
			Point p;
			Size s;

			if(_gl->getXmax() > _gl->getYmax()) {
				widthStep=2;
				heightStep=1;
			}
			else {
				widthStep=1;
				heightStep=2;
			}

			prompt("Ellipse test");
			_gl->setBackground(0);

			for(i=0;i<100;i++) {

				p.X=_gl->getXmax()/4+(rand() % (_gl->getXmax()/2));
				p.Y=_gl->getYmax()/4+(rand() % (_gl->getYmax()/2));

				s.Width=2;
				s.Height=2;
				cr=rand();

				while(p.X-s.Width>0 && p.X+s.Width<_gl->getXmax() && p.Y-s.Height>0 && p.Y+s.Height<_gl->getYmax()) {

					_gl->setForeground(cr);
					_gl->fillEllipse(p,s);

					s.Width+=widthStep;
					s.Height+=heightStep;
				}
			}
		}


		/*
		 * Show hardware text scrolling in portrait mode
		 */

		void scrollTest() {

			int i,j,numRows;
			char buffer[100];
			Point p;

			prompt("Hardware scrolling test");

			_gl->setForeground(0xffffff);
			_gl->setBackground(0);
			_gl->clear();

			if((_lcd->getSupportedScrollDirections() & ScrollDirection::Vertical) == 0) {

				_gl->moveTo(Point(0,0));
				_gl->writeString(*_font,"Vertical scrolling not supported",false);
				MillisecondTimer::delay(2000);
				return;
			}

			numRows=((_gl->getYmax() + 1) / _font->getHeight()) / 3;
			p.X=0;

			for(i=0;i < numRows;i++) {
				strcpy(buffer,"Test row ");
				StringUtil::itoa(i,buffer+strlen(buffer),10);

				p.Y=(numRows+i)*_font->getHeight();
				_gl->moveTo(p);
				_gl->writeString(*_font,buffer,false);
			}

			for(j=0;j<15;j++) {
				numRows=(_gl->getYmax()+1)/4;
				for(i=0;i<numRows;i++) {
					_gl->scroll(ScrollDirection::Vertical,1);
					MillisecondTimer::delay(5);
				}

				for(i=0;i<numRows;i++) {
					_gl->scroll(ScrollDirection::Vertical,-1);
					MillisecondTimer::delay(5);
				}
			}
		}


		/*
		 * Show lots of random lines
		 */

		void lineTest() {

			Point p1,p2;
			int i;

			prompt("Line test");

			for(i=0;i<5000;i++) {
				p1.X=rand() % _lcd->getXmax();
				p1.Y=rand() % _lcd->getYmax();
				p2.X=rand() % _lcd->getXmax();
				p2.Y=rand() % _lcd->getYmax();

				_gl->setForeground(rand());
				_gl->drawLine(p1,p2);
			}
		}

		/*
		 * Show lots of random filled growing rectangles
		 */

		void rectTest() {

			int i,xinc,yinc;
			Rectangle rc;

			prompt("Filled rectangle test");

			for(i=0;i<100;i++) {

				rc.X=(rand() % _lcd->getXmax()/2)+_lcd->getXmax()/4;
				rc.Y=(rand() % _lcd->getXmax()/2)+_lcd->getXmax()/4;

				_gl->setForeground(rand());

				rc.Width=10;
				rc.Height=10;

				xinc=(rand() & 1) ? 1 : 2;
				yinc=xinc==1 ? 2 : 1;

				_gl->setForeground(rand());
				while(rc.X>0 && rc.Y>0 && rc.X+rc.Width<_gl->getXmax() && rc.Y+rc.Height<_gl->getYmax()) {

					_gl->fillRectangle(rc);

					rc.X-=xinc;
					rc.Y-=yinc;
					rc.Width+=xinc*2;
					rc.Height+=yinc*2;
				}
			}
		}

		/*
		 * Rapidly clear down the screen, timing how long it takes
		 */

		void clearTest() {

			int i;

			prompt("Clear screen test");

			for(i=0;i < 200;i++) {
				_gl->setBackground(rand());
				startTimer();
				_gl->clear();
				stopTimer(" to clear");
			}
		}

		/*
		 * Show a prompt and wait 2 seconds
		 */

		void prompt(const char *prompt) {

			_gl->setBackground(0);
			_gl->clear();

			_gl->moveTo(Point(0,0));
			_gl->setForeground(0xffffff);
			_gl->writeString(*_font,prompt,false);

			MillisecondTimer::delay(3000);
			_gl->clear();
		}

		/*
		 * Start a millisecond timer
		 */

		void startTimer() {
			_start=MillisecondTimer::millis();
		}

		/*
		 * Stop timer and show result
		 */

		void stopTimer(const char *prompt) {

			uint32_t duration;
			char buffer[100];

			duration=MillisecondTimer::millis() - _start;
			StringUtil::itoa(duration,buffer,10);
			strcat(buffer,"ms ");
			strcat(buffer,prompt);
			strcat(buffer,"   ");

			_gl->setForeground(0xffffff);
			_gl->moveTo(Point(0,_lcd->getYmax() - _font->getHeight()));
			_gl->writeString(*_font,buffer,true);
		}
};

/*
 * Main entry point
 */

int main() {

	// set up SysTick at 1ms resolution
	MillisecondTimer::initialise();

	ILI9325Test test;
	test.run();

	// not reached
	return 0;
}
