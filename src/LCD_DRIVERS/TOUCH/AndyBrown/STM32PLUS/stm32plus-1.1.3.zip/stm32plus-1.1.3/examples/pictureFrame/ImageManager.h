/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011,2012 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#pragma once

#include "Initialiser.h"
#include "device/BlockDevice.h"
#include "BitmapManager.h"
#include "ImageTransitionTimelineEntry.h"

#include "timing/InterruptTimer.h"
#include "fx/Timeline.h"


/*
 * Image manager class
 */

class ImageManager : public Initialiser {

	protected:
		BitmapManager& _bmManager;
		BlockDevice& _blockDevice;
		uint32_t _currentImage;
		Timer *_timerPeripheral;
		Timeline *_timeline;
		ImageTransitionTimelineEntry _imageTransition;

	protected:
		bool drawFullImage();

		static const uint32_t TRANSITION_TIME=400;

	public:
		ImageManager(LcdManager& lcdManager,BitmapManager& bmManager,BlockDevice& blockDevice);

		LcdManager& getLcdManager() {
			return _lcdManager;
		}

		Timeline& getTimeline() {
			return *_timeline;
		}

		void setCurrentImage(uint32_t imageIndex) {
			_currentImage=imageIndex;
		}

		void nextImage();
		void showImage();

		// overrides from Initialiser

		bool initialise();
};
