/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include <cstring>
#include "gpio/GpioPort.h"
#include "timing/MillisecondTimer.h"
#include "display/graphic/tft/mc2pa8201/MC2PA8201ParallelLcdInterface262K.h"
#include "display/graphic/GraphicsLibrary.h"
#include "display/graphic/RAMFonts.h"
#include "display/graphic/RAMBitmapFont.h"
#include "string/StringUtil.h"
#include "timing/PwmOutput.h"
#include "timing/Timer4.h"


using namespace stm32plus;
using namespace stm32plus::display;


/*
 * MC2PA8201 LCD test, show a looping graphics demo
 */

class MC2PA8201Test {

	protected:
		MC2PA8201Gamma *_gamma; 									// gamma settings for the panel
		MC2PA8201ParallelLcdInterface262K *_lcd; 	// 262K colour interface to the MC2PA8201
		Fsmc8080Lcd *_fsmc; 											// FSMC driving parameters
		GraphicsLibrary *_gl; 										// graphics library attached to LCD
		Font *_font; 															// font that we'll use
		PwmOutput *_backlight;
		Timer *_backlightTimer;

		uint32_t _start;

	public:

		/*
		 * Demo setup and preparation
		 */

		void run() {

			// set up the LCD
			initLcd();

			// we want a graphics library and a font to play with
			_gl=new GraphicsLibrary(_lcd->getDisplayDeviceGraphics());
			_font=new RAMBitmapFont(Font_KYROU_9_REGULAR_8);

			// now we show the demo in an infinite loop

			for(;;)
				showDemo();
		}

		/*
		 * show the demo
		 */

		void showDemo() {
			rectTest();
			ellipseTest();
			backlightTest();
			scrollTest();
			textTest();
			clearTest();
			lineTest();
		}

		/*
		 * initialise the LCD panel
		 */

		void initLcd() {

			Fsmc8080LcdTiming fsmcTiming(0,2);

			GpioPort pd(GPIOD);
			Fsmc8080Lcd *fsmc=new Fsmc8080Lcd(FSMC_Bank1_NORSRAM1,fsmcTiming,16,pd[11]);

			GpioPort pe(GPIOE);
			pe.initialise(GPIO_Speed_50MHz,GPIO_Mode_Out_PP,GPIO_Pin_1);

			// start the LCD

			_lcd=new MC2PA8201ParallelLcdInterface262K(pe[1],*fsmc,Orientation::Portrait,*_gamma);

			// lights on

			_backlightTimer=new Timer4;
			_backlight=new PwmOutput(*_backlightTimer,2,1000,100);
			_backlightTimer->enable(true);
		}


		void backlightTest() {

			int16_t width,height,i,j;

			prompt("Backlight PWM test");

			width=(_lcd->getXmax()+1)/2;
			height=(_lcd->getYmax()+1)/2;

			_gl->setForeground(0xff0000);
			_gl->fillRectangle(Rectangle(0,0,width,height));

			_gl->setForeground(0x00ff00);
			_gl->fillRectangle(Rectangle(width,0,width,height));

			_gl->setForeground(0x0000ff);
			_gl->fillRectangle(Rectangle(0,height,width-1,height-1));

			_gl->setForeground(0xffffff);
			_gl->fillRectangle(Rectangle(width,height,width-1,height-1));


			for(i=0;i<10;i++) {

				for(j=100;j>=0;j--) {
					_backlight->setDutyCycle(j);
					MillisecondTimer::delay(15);
				}
			}
			_backlight->setDutyCycle(100);
		}


		void textTest() {
			prompt("Opaque text test");

			int i;
			const char *str="The quick brown fox";
			Size size;
			Point p;

			size=_gl->measureString(*_font,str);

			for(i=0;i<3000;i++) {

				p.X=rand() % (_gl->getXmax()-size.Width);
				p.Y=rand() % (_gl->getYmax()-size.Height);

				_gl->setForeground(rand());
				_gl->moveTo(p);
				_gl->writeString(*_font,str,true);
			}
		}


		void ellipseTest() {

			int16_t i;
			Point p;
			Size s;

			prompt("Ellipse test");
			_gl->setBackground(0);

			for(i=0;i<1000;i++) {

				p.X=_gl->getXmax()/4+(rand() % (_gl->getXmax()/2));
				p.Y=_gl->getYmax()/4+(rand() % (_gl->getYmax()/2));

				if(p.X<_gl->getXmax()/2)
					s.Width=rand() % p.X;
				else
					s.Width=rand() % (_gl->getXmax()-p.X);

				if(p.Y<_gl->getYmax()/2)
					s.Height=rand() % p.Y;
				else
					s.Height=rand() % (_gl->getYmax()-p.Y);

				_gl->setForeground(rand());
				_gl->fillEllipse(p,s);
			}

			_gl->clear();

			for(i=0;i<1500;i++) {

				p.X=_gl->getXmax()/4+(rand() % (_gl->getXmax()/2));
				p.Y=_gl->getYmax()/4+(rand() % (_gl->getYmax()/2));

				if(p.X<_gl->getXmax()/2)
					s.Width=rand() % p.X;
				else
					s.Width=rand() % (_gl->getXmax()-p.X);

				if(p.Y<_gl->getYmax()/2)
					s.Height=rand() % p.Y;
				else
					s.Height=rand() % (_gl->getYmax()-p.Y);

				if(s.Height>0 && s.Width>0 && p.X+s.Width<_gl->getXmax() && p.Y+s.Height<_gl->getYmax()) {
					_gl->setForeground(rand());
					_gl->drawEllipse(p,s);
				}

				if(i % 500==0)
					_gl->clear();
			}
		}


		void scrollTest() {

			int i,j,numRows;
			char buffer[100];
			Point p;

			prompt("Hardware scrolling test");

			_gl->setForeground(0xffffff);
			_gl->setBackground(0);
			_gl->clear();

			if((_lcd->getSupportedScrollDirections() & ScrollDirection::Vertical) == 0) {

				_gl->moveTo(Point(0,0));
				_gl->writeString(*_font,"Vertical scrolling not supported",false);
				MillisecondTimer::delay(2000);
				return;
			}

			numRows=((_gl->getYmax() + 1) / _font->getHeight()) / 3;
			p.X=0;

			for(i=0;i < numRows;i++) {
				strcpy(buffer,"Test row ");
				StringUtil::itoa(i,buffer+strlen(buffer),10);

				p.Y=(numRows+i)*_font->getHeight();
				_gl->moveTo(p);
				_gl->writeString(*_font,buffer,false);
			}

			for(j=0;j<15;j++) {
				numRows=(_gl->getYmax()+1)/4;
				for(i=0;i<numRows;i++) {
					_gl->scroll(ScrollDirection::Vertical,1);
					MillisecondTimer::delay(5);
				}

				for(i=0;i<numRows;i++) {
					_gl->scroll(ScrollDirection::Vertical,-1);
					MillisecondTimer::delay(5);
				}
			}
		}


		void lineTest() {

			Point p1,p2;
			int i;

			prompt("Line test");

			for(i=0;i<5000;i++) {
				p1.X=rand() % _lcd->getXmax();
				p1.Y=rand() % _lcd->getYmax();
				p2.X=rand() % _lcd->getXmax();
				p2.Y=rand() % _lcd->getYmax();

				_gl->setForeground(rand());
				_gl->drawLine(p1,p2);
			}
		}

		void rectTest() {

			int i;
			Rectangle rc;

			prompt("Rectangle test");

			for(i=0;i<1500;i++) {

				rc.X=(rand() % _lcd->getXmax()/2);
				rc.Y=(rand() % _lcd->getXmax()/2);
				rc.Width=rand() % (_gl->getXmax()-rc.X);
				rc.Height=rand() % (_gl->getYmax()-rc.Y);

				_gl->setForeground(rand());
				_gl->fillRectangle(rc);
			}

			_gl->clear();

			for(i=0;i<1500;i++) {

				rc.X=(rand() % _lcd->getXmax()/2);
				rc.Y=(rand() % _lcd->getXmax()/2);
				rc.Width=rand() % (_gl->getXmax()-rc.X);
				rc.Height=rand() % (_gl->getYmax()-rc.Y);

				_gl->setForeground(rand());
				_gl->drawRectangle(rc);

				if(i % 500 ==0)
					_gl->clear();
			}

		}

		void clearTest() {

			int i;

			prompt("Clear screen test");

			for(i=0;i < 200;i++) {
				_gl->setBackground(rand());
				startTimer();
				_gl->clear();
				stopTimer(" to clear");
			}
		}

		void prompt(const char *prompt_) {

			_gl->setBackground(0);
			_gl->clear();

			_gl->moveTo(Point(0,0));
			_gl->setForeground(0xffffff);
			_gl->writeString(*_font,prompt_,false);

			MillisecondTimer::delay(2000);
		}

		void startTimer() {
			_start=MillisecondTimer::millis();
		}

		/*
		 * Stop timer and show result
		 */

		void stopTimer(const char *prompt) {

			uint32_t duration;
			char buffer[100];

			duration=MillisecondTimer::millis() - _start;
			StringUtil::itoa(duration,buffer,10);
			strcat(buffer,"ms ");
			strcat(buffer,prompt);
			strcat(buffer,"   ");

			_gl->setForeground(0xffffff);
			_gl->moveTo(Point(0,_lcd->getYmax() - _font->getHeight()));
			_gl->writeString(*_font,buffer,true);
		}
};


/*
 * Main entry point
 */

int main() {

	// set up SysTick at 1ms resolution
	MillisecondTimer::initialise();

	MC2PA8201Test test;
	test.run();

	// not reached
	return 0;
}
