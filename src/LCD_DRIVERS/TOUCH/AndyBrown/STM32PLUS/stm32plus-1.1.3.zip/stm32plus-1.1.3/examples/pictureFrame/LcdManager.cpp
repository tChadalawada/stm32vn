/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include "stdafx.h"
#include "LcdManager.h"
#include "display/graphic/tft/ili9325/ILI9325Gamma.h"
#include "display/graphic/tft/ili9325/ILI9325ParallelLcdInterface262K.h"
#include "display/graphic/GraphicLcdTerminal.h"
#include "display/graphic/ColourNames.h"
#include "display/graphic/RAMBitmapFont.h"
#include "display/graphic/RAMFonts.h"
#include "gpio/GpioPort.h"


/*
 * Initialiser, create the LCD object. Gamma and fsmc objects need to be in scope but
 * can be lost on the heap as they'll never be referenced again externally.
 */

bool LcdManager::initialise() {

	Fsmc8080LcdTiming fsmcTiming(2,5);

	// set up the FSMC on bank 0 with A16 as the RS line

	GpioPort pd(GPIOD);
	Fsmc8080Lcd *fsmc=new Fsmc8080Lcd(FSMC_Bank1_NORSRAM1,fsmcTiming,16,pd[11]);

	// reset on port E pin 1

	GpioPort pe(GPIOE);
	pe.initialise(GPIO_Speed_50MHz,GPIO_Mode_Out_PP,GPIO_Pin_1);

	// create the LCD object

	_lcd=new ILI9325ParallelLcdInterface262K(
			pe[1],
			*fsmc,
			Orientation::Portrait,
			*new ILI9325Gamma(0xffff,0x67f,0,0x7,0xc,0,0,0x519,0x600,9) //0x0006,0x0101,0x0003,0x0106,0x0b02,0x0302,0x0707,0x0007,0x0600,0x020b)
		);

	// create graphics library and fixed width font

	_gl=new GraphicsLibrary(_lcd->getDisplayDeviceGraphics());
	_font=new RAMBitmapFont(Font_APPLE_8);

	// clear down to black

	_gl->setBackground(ColourNames::BLACK);
	_gl->clear();

	// lights on at 100%

	_timer=new Timer4;
	_backlight=new PwmOutput(*_timer,2,1000,100);
	_timer->enable(true);

	// attach a terminal to the LCD for the initialisation sequence

	_terminal=new GraphicLcdTerminal(*_gl,*_font,ColourNames::WHITE,ColourNames::BLACK);
	return true;
}
