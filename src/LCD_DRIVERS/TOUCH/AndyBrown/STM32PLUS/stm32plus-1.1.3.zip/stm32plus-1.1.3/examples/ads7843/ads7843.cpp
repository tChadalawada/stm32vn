/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include "display/graphic/tft/ili9325/ILI9325ParallelLcdInterface64K.h"
#include "display/graphic/GraphicsLibrary.h"
#include "display/graphic/RAMFonts.h"
#include "display/graphic/RAMBitmapFont.h"
#include "gpio/GpioPort.h"
#include "display/touch/ADS7843AsyncTouchScreen.h"
#include "display/touch/PassThroughTouchScreenCalibration.h"
#include "display/touch/AveragingTouchScreenPostProcessor.h"
#include "display/touch/PassThroughTouchScreenPostProcessor.h"
#include "display/touch/ThreePointTouchScreenCalibrator.h"
#include "display/graphic/ColourNames.h"
#include "timing/PwmOutput.h"
#include "timing/Timer4.h"
#include "timing/MillisecondTimer.h"
#include "exti/Exti.h"
#include "spi/Spi1.h"
#include "string/StringUtil.h"


using namespace stm32plus;
using namespace stm32plus::display;


/*
 * ADS7843 touch screen test, implements a basic drawing application. I don't normally create
 * classes this large, honestly!
 */

class ADS7843Test : public Observer {

	protected:

		// LCD-related objects

		ILI9325Gamma *_gamma; 									// gamma settings for the panel
		ILI9325ParallelLcdInterface64K *_lcd; 	// 64K colour interface to the ILI9325
		PwmOutput *_backlight;									// backlight PWM output
		Timer *_timer;													// the timer used for the backlight PWM
		Fsmc8080Lcd *_fsmc; 										// FSMC driving parameters
		GraphicsLibrary *_gl; 									// graphics library attached to LCD
		Font *_font; 														// font that we'll use

		// touch screen related objects

		ADS7843AsyncTouchScreen *_touchScreen;	// the touch screen object
		SpiPollingWriter *_spiWriter;						// A SPI writer for talking to the touch screen
		SpiPeripheral *_spi;										// The SPI peripheral that we'll attach to the writer
		ExtiBase *_exti;												// An EXTI interrupt line for the pen IRQ
		GpioPort *_penIrqPort;									// The GPIO port corresponding to the pen IRQ

		static const int _penIrqPortIndex=6;		// we've got the pen IRQ on pin 6.

		// calibrator and error-correction post-processors

		PassThroughTouchScreenCalibration *_passThroughCalibration;
		AveragingTouchScreenPostProcessor *_averagingPostProcessor;
		PassThroughTouchScreenPostProcessor *_passThroughPostProcessor;

		// the observer implementation will set this when the interrupt fires

		volatile bool _clicked;

		// these are the variables that the graphical demo will use

		bool _fgSelected;
		bool _accurate;
		TouchScreenCalibration* _calibrationResults;
		Size _boxSize;
		RGBE _fg,_bg;
		RGBE _colours[8];
		Rectangle _selectionBoxes[7];
		Point _lastPoint;
		uint16_t _backlightPercentage;

	public:

		/*
		 * Demo setup and preparation
		 */

		void run() {

			// set up the LCD
			initLcd();

			// set up the touch screen
			initTouchScreen();

			// we want a graphics library and a font to play with
			_gl=new GraphicsLibrary(_lcd->getDisplayDeviceGraphics());
			_font=new RAMBitmapFont(Font_KYROU_9_REGULAR_8);

			// set up variables for the demo
			_fgSelected=true;
			_accurate=false;
			_calibrationResults=NULL;
			_boxSize.Width=_boxSize.Height=0;
			_backlightPercentage=100;

			_colours[0]=ColourNames::RED;
			_colours[1]=ColourNames::GREEN;
			_colours[2]=ColourNames::BLUE;
			_colours[3]=ColourNames::BLACK;
			_colours[4]=ColourNames::WHITE;
			_colours[5]=ColourNames::CYAN;
			_colours[6]=ColourNames::MAGENTA;
			_colours[7]=ColourNames::YELLOW;

			// run the demo and don't come back
			doDemo();
		}


		/*
		 * initialise the LCD panel
		 */

		void initLcd() {

			// we've got RESET on PE1
			GpioPort pe(GPIOE),pd(GPIOD);

			pe.initialise(GPIO_Speed_50MHz,GPIO_Mode_Out_PP,GPIO_Pin_1);

			// set up some gamma values for this panel
			_gamma=new ILI9325Gamma(0x0006,0x0101,0x0003,0x0106,0x0b02,0x0302,0x0707,0x0007,0x0600,0x020b);

			// set up the FSMC timing for this panel
			Fsmc8080LcdTiming fsmcTiming(2,5);

			// set up the FSMC on bank 1 with A16 as the RS line (this is compatible with 100 pin devices)
			_fsmc=new Fsmc8080Lcd(FSMC_Bank1_NORSRAM1,fsmcTiming,16,pd[11]);

			// create the LCD interface in landscape mode
			// this will power it up and do the reset sequence
			_lcd=new ILI9325ParallelLcdInterface64K(pe[1],*_fsmc,Orientation::Landscape,*_gamma);

			// turn on the backlight at 100%

			_backlightPercentage=100;
			_timer=new Timer4;
			_backlight=new PwmOutput(*_timer,2,1000,_backlightPercentage);
			_timer->enable(true);
		}


		/*
		 * initialise the touch screen
		 */

		void initTouchScreen() {

			// create the initial pass through calibration object that allows us to create
			// the touch screen object ready for calibrating for real

			_passThroughCalibration=new PassThroughTouchScreenCalibration;

			// create an averaging post-processor for use in accurate mode that
			// does 4x oversampling on the incoming data

			_averagingPostProcessor=new AveragingTouchScreenPostProcessor(4);

			// create the do-nothing post-processor that is used in non-accurate mode

			_passThroughPostProcessor=new PassThroughTouchScreenPostProcessor;

			// we've got the PENIRQ attached to GPIOB, port 6. Attach an EXTI line to it and since
			// it's active low we want to be called back via our Observer implementation when the
			// signal falls from high to low.

			_penIrqPort=new GpioPort(GPIOB);
			_exti=new Exti6(EXTI_Mode_Interrupt,EXTI_Trigger_Falling,(*_penIrqPort)[_penIrqPortIndex]);

			// we've got the SPI interface to the touchscreen wired to SPI1, and since SPI1 is the fast one on the
			// STM32 we'll divide the 72Mhz clock by the maximum of 256 instead of 128 which we'd use on SPI2.

			_spi=new Spi1(SPI_Direction_2Lines_FullDuplex,SPI_Mode_Master,SPI_BaudRatePrescaler_256,SPI_FirstBit_MSB,SPI_CPOL_Low,SPI_CPHA_1Edge);
			_spiWriter=new SpiPollingWriter(*_spi);

			// now create the touch screen, initially in non-accurate mode with some dummy calibration data because the first thing
			// we're going to do in the demo is calibrate it with the 3-point routine.

			_touchScreen=new ADS7843AsyncTouchScreen(
					*_passThroughCalibration,
					*_passThroughPostProcessor,
					*_spiWriter,(*_penIrqPort)[_penIrqPortIndex],
					*_exti
				);
		}


		/*
		 * Calibrate the touch screen using the accurate 3-point method
		 */

		void calibrate() {

			ThreePointTouchScreenCalibrator calibrator(*_gl,*_font,*_touchScreen);
			TouchScreenCalibration* newResults;

			// important preparation for calibration: we must set the screen to pass through mode
			// so that the calibrator sees raw co-ordinates and not calibrated!

			_touchScreen->setCalibration(*_passThroughCalibration);

			// calibrate the screen and get the new results. A real application can use the serialise
			// and deserialise methods of the TouchScreenCalibration base class to read/write the
			// calibration data to a persistent stream

			if(!calibrator.calibrate(newResults))
				return;

			// store the new results

			if(_calibrationResults!=NULL)
				delete _calibrationResults;

			_calibrationResults=newResults;

			// re-initialise the touch screen with the calibration data

			_touchScreen->setCalibration(*_calibrationResults);
		}


		/*
		 * Get the size of one of the menu boxes on the screen
		 */

		void calcBoxSize(const char **boxTexts,int numBoxes) {

			Size s;
			int i;

			for(i=0;i<numBoxes;i++) {
				s=_gl->measureString(*_font,boxTexts[i]);

				if(s.Width>_boxSize.Width)
					_boxSize.Width=s.Width;

				if(s.Height>_boxSize.Height)
					_boxSize.Height=s.Height;
			}

			// add on 4px for the left selection bar, 2px all around for space and 1px all around for the border
			// ignoring that the border is shared between vertical boxes :)

			_boxSize.Width+=1+4+2+2+1;
			_boxSize.Height+=1+2+2+1;
		}


		/*
		 * Draw the tools menu at the edge of the screen
		 */

		void drawTools() {

			int16_t y;
			uint16_t i;
			Point p;

			const char *boxTexts[]= {
				"","fore","back","clear","recal","accurate", ""
			};

			if(_boxSize.Width==0)
				calcBoxSize(boxTexts,sizeof(boxTexts)/sizeof(boxTexts[0]));

			// clear down

			_gl->setForeground(ColourNames::BLACK);
			_gl->fillRectangle(Rectangle(0,0,_boxSize.Width,(_boxSize.Height+2)*sizeof(boxTexts)/sizeof(boxTexts[0])));

			_gl->setForeground(ColourNames::WHITE);

			y=0;
			p.X=1+4+2;

			for(i=0;i<sizeof(boxTexts)/sizeof(boxTexts[0]);i++) {

				_selectionBoxes[i].X=0;
				_selectionBoxes[i].Y=y;
				_selectionBoxes[i].Width=_boxSize.Width;
				_selectionBoxes[i].Height=_boxSize.Height;

				_gl->drawRectangle(_selectionBoxes[i]);

				p.Y=y+1+2;
				_gl->moveTo(p);
				_gl->writeString(*_font,boxTexts[i],false);

				y+=_boxSize.Height+2;
			}

			drawSelection(_fg,1);
			drawSelection(_bg,2);

			if(_accurate)
				drawSelection(ColourNames::GREEN,5);

			drawColours();
			drawBacklight();

			// don't return until the pen is up

			while(!(*_penIrqPort)[_penIrqPortIndex].read());
		}


		/*
		 * Draw a selection (green bar) indicator in the menu box
		 */

		void drawSelection(RGBE barColour,int boxIndex) {
			_gl->setForeground(barColour);
			_gl->fillRectangle(Rectangle(1,(_boxSize.Height+2)*boxIndex+1,4,_boxSize.Height-2));
		}


		/*
		 * Draw the backlight percentage box
		 */

		void drawBacklight() {
			int width,y;
			char buffer[20];

			y=(_boxSize.Height+2)*6+1;
			width=((_boxSize.Width-2)*_backlightPercentage)/100;

			_gl->setForeground(ColourNames::BLUE);
			_gl->fillRectangle(Rectangle(1,y,width,_boxSize.Height-2));

			if(_backlightPercentage<100) {
				_gl->setForeground(ColourNames::BLACK);
				_gl->fillRectangle(Rectangle(1+width,y,_boxSize.Width-2-(1+width),_boxSize.Height-2));
			}

			strcpy(buffer,"LED: ");

			StringUtil::itoa(_backlightPercentage,buffer+5,10);
			_gl->setForeground(ColourNames::WHITE);
			_gl->moveTo(Point(1+4+2,y+1+2));
			_gl->writeString(*_font,buffer,false);

			_gl->setForeground(_fg);
		}


		/*
		 * Draw the colour stripe boxes
		 */

		void drawColours() {

			int i,numColours,width;
			Rectangle rc;

			numColours=sizeof(_colours)/sizeof(_colours[0]);
			width=(_boxSize.Width-2)/numColours;

			rc.X=1;
			rc.Y=1;
			rc.Height=_boxSize.Height-2;
			rc.Width=width;

			for(i=0;i<numColours;i++) {
				_gl->setForeground(_colours[i]);
				_gl->fillRectangle(rc);
				rc.X+=width;
			}
		}


		/*
		 * Go into a loop running the demo
		 */

		void doDemo() {

			Point p;
			int index;
			uint16_t newpercent;

			// clear down
			_gl->setBackground(ColourNames::BLACK);
			_gl->clear();

			// calibrate the screen for first use
			calibrate();

			// clear down the screen

			_fg=ColourNames::WHITE;
			_bg=ColourNames::BLACK;

			_gl->setBackground(_bg);
			_gl->clear();

			// draw the tools
			drawTools();

			// register as an observer for interrupts on the EXTI line

			_touchScreen->insertObserver(*this);

			for(;;) {

				// wait for a click

				_lastPoint.X=-1;
				for(_clicked=false;!_clicked;);

				do {

					// get click-coordinates from the panel

					if(_touchScreen->getCoordinates(p)) {

						// check if the click is in any of the menu boxes

						if(_selectionBoxes[0].containsPoint(p)) {
							index=(p.X-1)/8;
							if(index>=0 && index<=7) {
								if(_fgSelected) {
									_fg=_colours[index];
									_gl->setForeground(_fg);
								}
								else {
									_bg=_colours[index];
									_gl->setBackground(_bg);
									_gl->clear();
								}
								drawTools();
							}
						}
						else if(_selectionBoxes[1].containsPoint(p)) {
							_fgSelected=true;
						}
						else if(_selectionBoxes[2].containsPoint(p)) {
							_fgSelected=false;
						}
						else if(_selectionBoxes[3].containsPoint(p)) {
							_gl->clear();
							drawTools();
						}
						else if(_selectionBoxes[4].containsPoint(p)) {
							while(!(*_penIrqPort)[_penIrqPortIndex].read());
							calibrate();
							_gl->setBackground(_bg);
							_gl->clear();
							drawTools();
						}
						else if(_selectionBoxes[5].containsPoint(p)) {
							if(_accurate^=true)
								_touchScreen->setPostProcessor(*_averagingPostProcessor);
							else
								_touchScreen->setPostProcessor(*_passThroughPostProcessor);
							drawTools();
						}
						else if(_selectionBoxes[6].containsPoint(p)) {
							newpercent=(100*p.X-1)/(_boxSize.Width-2);
							if(newpercent!=_backlightPercentage && newpercent<=100) {
								_backlightPercentage=newpercent;
								_backlight->setDutyCycle(_backlightPercentage);
								drawBacklight();
							}
						}
						else {

							// if the click is on screen, plot it. This bounds check is necessary because
							// the touch screen can and does extend past the LCD edges.

							if(p.X>=0 && p.X<=_gl->getXmax() && p.Y>=0 && p.Y<=_gl->getYmax()) {

									if(_lastPoint.X!=-1)
										_gl->drawLine(p,_lastPoint);
								else
									_gl->plotPoint(p);

								_lastPoint=p;
							}
						}
					}

				// carry on while the pen is still down

				} while(!(*_penIrqPort)[_penIrqPortIndex].read());
			}
		}


		/*
		 * Implementation of the Observer pattern. This will be called back when the
		 * EXTI interrupt fires.
		 */

		void onNotify(
				Observable& sender __attribute__((unused)),
				ObservableEvent::E event,
				void *context __attribute__((unused))) {

			// check that the event is what we were expecting and set the clicked flag if it is

			if(event==ObservableEvent::TouchPanel_ReadyForSampling && !_clicked)
				_clicked=true;
		}
};


/*
 * Main entry point
 */

int main() {

	// set up SysTick at 1ms resolution
	MillisecondTimer::initialise();

	ADS7843Test test;
	test.run();

	// not reached
	return 0;
}
