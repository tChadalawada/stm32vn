/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include "gpio/GpioPort.h"
#include "timing/MillisecondTimer.h"

using namespace stm32plus;


/*
 * Blink class, turns an LED on and off at 1 second
 * intervals. Assumes that the LED is connected
 * through PF6.
 */

class BlinkTest {

	public:

		void run() {

			GpioPort portf(GPIOF);

			portf[6].initialise(GPIO_Speed_50MHz,GPIO_Mode_Out_PP);

			for(;;) {

				portf[6].set();
				MillisecondTimer::delay(1000);

				portf[6].reset();
				MillisecondTimer::delay(1000);
			}
		}
};


/*
 * Main entry point
 */

int main() {

	// set up SysTick at 1ms resolution
	MillisecondTimer::initialise();

	BlinkTest test;
	test.run();

	// not reached
	return 0;
}
