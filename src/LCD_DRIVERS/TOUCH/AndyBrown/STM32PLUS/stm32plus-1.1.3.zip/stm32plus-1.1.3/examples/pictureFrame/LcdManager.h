/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011,2012 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#pragma once

#include "display/graphic/parallel/ParallelDisplayDevice.h"
#include "display/graphic/gamma/DisplayDeviceGamma.h"
#include "display/Terminal.h"
#include "display/graphic/GraphicsLibrary.h"
#include "display/graphic/Font.h"
#include "timing/PwmOutput.h"
#include "timing/Timer4.h"

using namespace stm32plus;
using namespace stm32plus::display;


/*
 * Manager class for the LCD display
 */

class LcdManager {

	protected:
		ParallelDisplayDevice *_lcd;
		PwmOutput *_backlight;
		Timer *_timer;
		Terminal *_terminal;
		GraphicsLibrary *_gl;
		Font *_font;

	public:
		bool initialise();

		ParallelDisplayDevice& getLcd() const {
			return *_lcd;
		}

		GraphicsLibrary& getGraphicsLibrary() const {
			return *_gl;
		}

		Font& getFont() const {
			return *_font;
		}

		Terminal& getTerminal() const {
			return *_terminal;
		}
};
