/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include <cstring>
#include "gpio/GpioPort.h"
#include "timing/MillisecondTimer.h"
#include "display/graphic/tft/ili9481/ILI9481ParallelLcdInterface64K.h"
#include "display/graphic/GraphicsLibrary.h"
#include "display/graphic/RAMFonts.h"
#include "display/graphic/RAMBitmapFont.h"
#include "string/StringUtil.h"


using namespace stm32plus;
using namespace stm32plus::display;


/*
 * ILI9481 LCD test, show a looping graphics demo
 */

class ILI9481Test {

	protected:
		ILI9481Gamma *_gamma; 										// gamma settings for the panel
		ILI9481ParallelLcdInterface64K *_lcd; 		// 64K colour interface to the ILI9481
		Fsmc8080Lcd *_fsmc; 											// FSMC driving parameters
		GraphicsLibrary *_gl; 										// graphics library attached to LCD
		Font *_font; 															// font that we'll use

		uint32_t _start;

	public:

		/*
		 * Demo setup and preparation
		 */

		void run() {

			// set up the LCD
			initLcd();

			// we want a graphics library and a font to play with
			_gl=new GraphicsLibrary(_lcd->getDisplayDeviceGraphics());
			_font=new RAMBitmapFont(Font_KYROU_9_REGULAR_8);

			// now we show the demo in an infinite loop

			for(;;)
				showDemo();
		}

		/*
		 * show the demo
		 */

		void showDemo() {
			rectTest();
			ellipseTest();
			scrollTest();
			textTest();
			clearTest();
			lineTest();
		}

		/*
		 * initialise the LCD panel
		 */

		void initLcd() {

			Fsmc8080LcdTiming fsmcTiming(2,2);

			// set up the FSMC on bank 4 with A0 as the RS line

			GpioPort pf(GPIOF);
			Fsmc8080Lcd *fsmc=new Fsmc8080Lcd(FSMC_Bank1_NORSRAM4,fsmcTiming,0,pf[0]);

			// reset on port A pin 0

			GpioPort pa(GPIOA);
			pa.initialise(GPIO_Speed_50MHz,GPIO_Mode_Out_PP,GPIO_Pin_0);

			// start the LCD

			_gamma=new ILI9481Gamma(0,0xf3,0,0xbc,0x50,0x1f,0,7,0x7f,0x7,0xf,0);
			_lcd=new ILI9481ParallelLcdInterface64K(pa[0],*fsmc,Orientation::Portrait,*_gamma);
		}


		void textTest() {
			prompt("Opaque text test");

			int i;
			const char *str="The quick brown fox";
			Size size;
			Point p;

			size=_gl->measureString(*_font,str);

			for(i=0;i<3000;i++) {

				p.X=rand() % (_gl->getXmax()-size.Width);
				p.Y=rand() % (_gl->getYmax()-size.Height);

				_gl->setForeground(rand());
				_gl->moveTo(p);
				_gl->writeString(*_font,str,true);
			}
		}


		void ellipseTest() {

			int16_t i;
			Point p;
			Size s;

			prompt("Ellipse test");
			_gl->setBackground(0);

			for(i=0;i<1000;i++) {

				p.X=_gl->getXmax()/4+(rand() % (_gl->getXmax()/2));
				p.Y=_gl->getYmax()/4+(rand() % (_gl->getYmax()/2));

				if(p.X<_gl->getXmax()/2)
					s.Width=rand() % p.X;
				else
					s.Width=rand() % (_gl->getXmax()-p.X);

				if(p.Y<_gl->getYmax()/2)
					s.Height=rand() % p.Y;
				else
					s.Height=rand() % (_gl->getYmax()-p.Y);

				_gl->setForeground(rand());
				_gl->fillEllipse(p,s);
			}

			_gl->clear();

			for(i=0;i<1500;i++) {

				p.X=_gl->getXmax()/4+(rand() % (_gl->getXmax()/2));
				p.Y=_gl->getYmax()/4+(rand() % (_gl->getYmax()/2));

				if(p.X<_gl->getXmax()/2)
					s.Width=rand() % p.X;
				else
					s.Width=rand() % (_gl->getXmax()-p.X);

				if(p.Y<_gl->getYmax()/2)
					s.Height=rand() % p.Y;
				else
					s.Height=rand() % (_gl->getYmax()-p.Y);

				if(s.Height>0 && s.Width>0 && p.X+s.Width<_gl->getXmax() && p.Y+s.Height<_gl->getYmax()) {
					_gl->setForeground(rand());
					_gl->drawEllipse(p,s);
				}

				if(i % 500==0)
					_gl->clear();
			}
		}


		void scrollTest() {

			int i,j,numRows;
			char buffer[100];
			Point p;

			prompt("Hardware scrolling test");

			_gl->setForeground(0xffffff);
			_gl->setBackground(0);
			_gl->clear();

			if((_lcd->getSupportedScrollDirections() & ScrollDirection::Vertical) == 0) {

				_gl->moveTo(Point(0,0));
				_gl->writeString(*_font,"Vertical scrolling not supported",false);
				MillisecondTimer::delay(2000);
				return;
			}

			numRows=((_gl->getYmax() + 1) / _font->getHeight()) / 3;
			p.X=0;

			for(i=0;i < numRows;i++) {
				strcpy(buffer,"Test row ");
				StringUtil::itoa(i,buffer+strlen(buffer),10);

				p.Y=(numRows+i)*_font->getHeight();
				_gl->moveTo(p);
				_gl->writeString(*_font,buffer,false);
			}

			for(j=0;j<15;j++) {
				numRows=(_gl->getYmax()+1)/4;
				for(i=0;i<numRows;i++) {
					_gl->scroll(ScrollDirection::Vertical,1);
					MillisecondTimer::delay(5);
				}

				for(i=0;i<numRows;i++) {
					_gl->scroll(ScrollDirection::Vertical,-1);
					MillisecondTimer::delay(5);
				}
			}
		}


		void lineTest() {

			Point p1,p2;
			int i;

			prompt("Line test");

			for(i=0;i<5000;i++) {
				p1.X=rand() % _lcd->getXmax();
				p1.Y=rand() % _lcd->getYmax();
				p2.X=rand() % _lcd->getXmax();
				p2.Y=rand() % _lcd->getYmax();

				_gl->setForeground(rand());
				_gl->drawLine(p1,p2);
			}
		}

		void rectTest() {

			int i;
			Rectangle rc;

			prompt("Rectangle test");

			for(i=0;i<1500;i++) {

				rc.X=(rand() % _lcd->getXmax()/2);
				rc.Y=(rand() % _lcd->getXmax()/2);
				rc.Width=rand() % (_gl->getXmax()-rc.X);
				rc.Height=rand() % (_gl->getYmax()-rc.Y);

				_gl->setForeground(rand());
				_gl->fillRectangle(rc);
			}

			_gl->clear();

			for(i=0;i<1500;i++) {

				rc.X=(rand() % _lcd->getXmax()/2);
				rc.Y=(rand() % _lcd->getXmax()/2);
				rc.Width=rand() % (_gl->getXmax()-rc.X);
				rc.Height=rand() % (_gl->getYmax()-rc.Y);

				_gl->setForeground(rand());
				_gl->drawRectangle(rc);

				if(i % 500 ==0)
					_gl->clear();
			}

		}

		void clearTest() {

			int i;

			prompt("Clear screen test");

			for(i=0;i < 200;i++) {
				_gl->setBackground(rand());
				startTimer();
				_gl->clear();
				stopTimer(" to clear");
			}
		}

		void prompt(const char *prompt_) {

			_gl->setBackground(0);
			_gl->clear();

			_gl->moveTo(Point(0,0));
			_gl->setForeground(0xffffff);
			_gl->writeString(*_font,prompt_,false);

			MillisecondTimer::delay(2000);
		}

		void startTimer() {
			_start=MillisecondTimer::millis();
		}

		/*
		 * Stop timer and show result
		 */

		void stopTimer(const char *prompt) {

			uint32_t duration;
			char buffer[100];

			duration=MillisecondTimer::millis() - _start;
			StringUtil::itoa(duration,buffer,10);
			strcat(buffer,"ms ");
			strcat(buffer,prompt);
			strcat(buffer,"   ");

			_gl->setForeground(0xffffff);
			_gl->moveTo(Point(0,_lcd->getYmax() - _font->getHeight()));
			_gl->writeString(*_font,buffer,true);
		}
};


/*
 * Main entry point
 */

int main() {

	// set up SysTick at 1ms resolution
	MillisecondTimer::initialise();

	ILI9481Test test;
	test.run();

	// not reached
	return 0;
}
