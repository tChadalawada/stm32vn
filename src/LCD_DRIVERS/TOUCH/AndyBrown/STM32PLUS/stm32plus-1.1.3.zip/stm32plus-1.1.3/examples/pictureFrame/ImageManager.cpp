/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011,2012 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include "stdafx.h"
#include "ImageManager.h"
#include "timing/Timer3.h"


/*
 * Constructor
 */

ImageManager::ImageManager(LcdManager& lcdManager,BitmapManager& bmManager,BlockDevice& bd)
	: Initialiser(lcdManager),
	  _bmManager(bmManager),
	  _blockDevice(bd),
	  _imageTransition(_lcdManager.getLcd(),bd,TRANSITION_TIME) {

	// create the interrupt timer on channel 1, 500Hz (2ms)

	_timerPeripheral=new Timer3;

	// create the timeline for the animation

	_timeline=new Timeline(*_timerPeripheral,1,TRANSITION_TIME);

	// add the image transition entry

	_timeline->insertObserver(_imageTransition);
}


/*
 * Initialise the class
 */

bool ImageManager::initialise()
{
	_currentImage=0;

	return drawFullImage();
}


/*
 * Draw the current image in full
 */

bool ImageManager::drawFullImage() {

	uint32_t blockIndex,i;
	uint16_t blocks[512];

	// get the first block. There are two blocks per scan line.

	blockIndex=_bmManager.getFirstBlockIndex(_currentImage);

	// get the display device

	ParallelDisplayDevice& pdd=_lcdManager.getLcd();

	pdd.moveTo(0,0);
	pdd.beginWriting();

	for(i=blockIndex;i<blockIndex+640;i+=2) {

		// read the 2 blocks (one scan)

		if(!_blockDevice.readBlocks(blocks,i,2))
			return false;

		// write to the device

		pdd.writeDataBlock(blocks,240);
		pdd.writeDataBlock(&blocks[256],240);
	}

	return true;
}


/*
 * Move to the next image
 */

void ImageManager::nextImage() {

	// safety check

	if(_timeline->isRunning())
		return;

	// advance and wrap if we have to

	if(_currentImage==_bmManager.getImageCount()-1)
		_currentImage=0;
	else
		_currentImage++;

	// show the current image

	showImage();
}


/*
 * Show image with animated transition
 */

void ImageManager::showImage() {

	// set the new image

	_imageTransition.setNewImageBlockIndex(_bmManager.getFirstBlockIndex(_currentImage));

	// start the timeline

	_timeline->start();
}
