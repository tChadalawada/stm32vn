/*
 * This file is a part of the open source stm32plus library.
 * Copyright (c) 2011,2012 Andy Brown <www.andybrown.me.uk>
 * Please see website for licensing terms.
 */

#include "stdafx.h"
#include "ImageTransitionTimelineEntry.h"


/*
 * Constructor
 */

ImageTransitionTimelineEntry::ImageTransitionTimelineEntry(ParallelDisplayDevice& lcd,BlockDevice& bd,uint32_t transitionTime)
	: TimelineEntry(0,transitionTime),
	  _lcd(lcd),
		_blockDevice(bd) {

	// initialise the easing function

	_ease.setDuration(transitionTime);
	_ease.setTotalChangeInPosition(320);

	// preset for no previous image

	_blockIndex=0;
}


/**
 * We're notified that we need to do something
 */

void ImageTransitionTimelineEntry::onNotify(
		Observable& sender __attribute__((unused)),
		ObservableEvent::E event __attribute__((unused)),
		void *context) {

	int16_t newPosition,oldScrollPos,count;
	uint32_t currentTime,i,lastBlock,firstBlock;
	uint16_t blocks[512];

	// scroll the display

	currentTime=reinterpret_cast<uint32_t>(context);

	newPosition=_ease.easeOut(currentTime);
	count=newPosition-_lcd.getScrollPosition();

	if(count==0)
		return;

	oldScrollPos=_lcd.getScrollPosition();
	_lcd.scroll(ScrollDirection::Vertical,count);

	// blit in the new data

	_lcd.moveTo(0,oldScrollPos);

	firstBlock=_blockIndex+(oldScrollPos*2);
	lastBlock=_blockIndex+(oldScrollPos*2)+(count*2);

	_lcd.beginWriting();

	for(i=firstBlock;i<lastBlock;i+=2) {

		// read the 2 blocks (one scan)

		if(!_blockDevice.readBlocks(blocks,i,2))
			return;

		// write to the device

		_lcd.writeDataBlock(blocks,240);
		_lcd.writeDataBlock(&blocks[256],240);
	}

}
