#include "stm32f10x.h"

#include <string.h>
#include "fft.h"

/**
 * Complex FFT samples input.
 */
    u32 fft_output[FFT_LENGTH];

/**
 * Compute a real FFT with real or complex values. Use the ST DSP
 * library for STM32.
 * @param samples [in], the pointer to the samples in time domain
 * @param size, the size of the sample buffer
 * @return a pointer to the FFT output (real numbers only)
 */
u32* compute_fft(u32* samples, u16 size)
{

	// Performs the FFT with the ST DSP library
	#if FFT_LENGTH == 64
		cr4_fft_64_stm32(fft_output, samples, FFT_LENGTH);
	#elif FFT_LENGTH == 256
		cr4_fft_256_stm32(fft_output, samples, FFT_LENGTH);
	#elif FFT_LENGTH == 1024
		cr4_fft_1024_stm32(fft_output, samples, FFT_LENGTH);
	#else
		#error FFT is not developped for this FFT_LENGTH samples !
	#endif

	// Convert the complex values to real values
	u16 i;
	for(i=0;i<FFT_LENGTH/2;i++)
	{
		fft_output[i] = abs((s16)(fft_output[i]>>16)) + abs((s16)(0x0000FFFF&fft_output[i]));
	}

	// Returns the converted FFT output buffer
	return fft_output;
}

/**
 * Find the fundamental frequency in a spectrum.
 * @param spectrum [in], the pointer to the spectrum
 * @param sampling_rate, the sampling rate used for the spectrum
 * @return the fundamental frequency
 */
u16 fundamental_frequency(u32* sprectrum, u16 sampling_rate)
{
	// Find the maximal value
	u32 max_value = 0;
	u16 max_pos = 0;
	u16 i;
	for(i=0;i<FFT_LENGTH/2;i++)
	{
		if(sprectrum[i] > max_value)
		{
			max_value = sprectrum[i];
			max_pos = i;
		}
	}

	// Convert the spectrum index to a frequency
	return max_pos*sampling_rate/FFT_LENGTH;
}