#include "stm32f10x.h"

//Ӳ����ص��Ӻ���

#define Set_Cs  GPIO_SetBits(GPIOC,GPIO_Pin_8);
#define Clr_Cs  GPIO_ResetBits(GPIOC,GPIO_Pin_8);

#define Set_Rs  GPIO_SetBits(GPIOC,GPIO_Pin_9);
#define Clr_Rs  GPIO_ResetBits(GPIOC,GPIO_Pin_9);

#define Set_nWr GPIO_SetBits(GPIOC,GPIO_Pin_10);
#define Clr_nWr GPIO_ResetBits(GPIOC,GPIO_Pin_10);

#define Set_nRd GPIO_SetBits(GPIOC,GPIO_Pin_11);
#define Clr_nRd GPIO_ResetBits(GPIOC,GPIO_Pin_11);

#define Set_Rst GPIO_SetBits(GPIOC,GPIO_Pin_12);
#define Clr_Rst GPIO_ResetBits(GPIOC,GPIO_Pin_12);

#define Lcd_Light_ON   GPIO_SetBits(GPIOC,GPIO_Pin_13);
#define Lcd_Light_OFF  GPIO_ResetBits(GPIOC,GPIO_Pin_13);


#define nCsPin  GPIO_Pin_8
#define RsPin   GPIO_Pin_9
#define nWrPin  GPIO_Pin_10
#define nRdPin  GPIO_Pin_11
#define nRstPin GPIO_Pin_12
#define Lcd_LightPin GPIO_Pin_13


u16 CheckController(void);
void Lcd_Configuration(void);
void Lcd_Initializtion(void);
void Lcd_Reset(void);
void Lcd_WriteReg(u16 index,u16 dat);
void Lcd_SetCursor(u16 x,u16 y);
void Lcd_SetWindows(u16 StartX,u16 StartY,u16 EndX,u16 EndY);
void Lcd_DrawPicture(u16 StartX,u16 StartY,u16 EndX,u16 EndY,u16 *pic);
void Lcd_SetPoint(u16 x,u16 y,u16 point);
void Lcd_PutChar(u16 x,u16 y,u8 c,u16 charColor,u16 bkColor);
void Lcd_Clear(u16 dat);
void Lcd_Delay(u32 nCount);
void Lcd_Test(void);
u16 Lcd_GetCode(void);
void Lcd_WriteData(u16 dat);
void Lcd_WriteIndex(u16 idx);
void Lcd_WR_Start(void);
void Lcd_WR_End(void);

void Lcd_BackLight(u8 status);

u16 Lcd_BGR2RGB(u16 c);

u16 Lcd_GetPoint(u16 x,u16 y);
u16 Lcd_ReadData(void);
u16 Lcd_ReadRegister(u16 index);


