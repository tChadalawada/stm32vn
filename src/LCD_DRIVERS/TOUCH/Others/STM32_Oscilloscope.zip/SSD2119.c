#include "stm32f10x.h"
#include "SSD2119.h"
#include "SSD2119_font.h"


u16 DeviceCode;



void Lcd_Configuration(void)
{ 
	GPIO_InitTypeDef GPIO_InitStructure;
	/*������Ӧʱ�� */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC, ENABLE);  
	/*����Lcd��������Ϊ�������*/
	/*16λ���ݵ�8λ*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12|GPIO_Pin_13|GPIO_Pin_14|GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	/*16λ���ݸ�8λ*/
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5|GPIO_Pin_6|GPIO_Pin_7;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	/*���ƽ�*/
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8|GPIO_Pin_9|GPIO_Pin_10|GPIO_Pin_11|GPIO_Pin_12;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	/*�������*/
	GPIO_InitStructure.GPIO_Pin =GPIO_Pin_13;
	GPIO_Init(GPIOC, &GPIO_InitStructure);
	Lcd_Light_ON;
} 

/****************************************************************************
* ��    �ƣ�void Lcd_Initializtion()
* ��    �ܣ���ʼ�� ILI9320 ������
* ��ڲ�������
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_Initializtion();
****************************************************************************/
void Lcd_Initializtion(void)
{
  /*****************************
  **    Ӳ������˵��          **
  ** STM32         ili9320/ili9325/SSD2119    **
  ** PB8~15 <----> DB0~7      **
  ** PC0~7 <----> DB8~15      **
  ** PC11   <----> nRD        **
  ** PC9    <----> RS         **
  ** PC10   <----> nWR        **
  ** PC8    <----> nCS        **
  ** PC12   <----> nReset     **
  ** PC13   <----> BK_LED     **
  ******************************/
 	u16 i;

  	Lcd_WriteData(0xffff);
  	Set_Rst;
	Set_nWr;
	Set_Cs;
	Set_Rs;
	Set_nRd;
	Set_Rst;
    Lcd_Reset();                                        // ��λ Lcd_Reset

    Lcd_WriteReg(0x0000,0x0001);
    Lcd_Delay(10000); // 10 ms

    DeviceCode = Lcd_ReadRegister(0x0000);

    if(DeviceCode==0x9919)  // SSD2119
	{
		//*********POWER ON &RESET DISPLAY OFF
		 Lcd_WriteReg(0x28,0x0006); // VCOM OTP - Page 55-56 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x00,0x0001); // start Oscillator - Page 36 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x10,0x0000); // Sleep mode - Page 49 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x01,0x72ef); // Driver Output Control - Page 36-39 of SSD2119 datasheet

		 Lcd_WriteReg(0x02,0x0600); // LCD Driving Waveform Control - Page 40-42 of SSD2119 datasheet

		 Lcd_WriteReg(0x03,0x6a38); // Power Control 1 - Page 43-44 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x11,0x6874); // Entry Mode - Page 50-52 of SSD2119 datasheet
		
		 
		     //  RAM WRITE DATA MASK
		 Lcd_WriteReg(0x0f,0x0000); // Gate Scan Position - Page 49 of SSD2119 datasheet
		    //  RAM WRITE DATA MASK
		 Lcd_WriteReg(0x0b,0x5308); // Frame Cycle Control - Page 45 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x0c,0x0003); // Power Control 2 - Page 47 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x0d,0x000a); // Power Control 3 - Page 48 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x0e,0x2e00); // Power Control 4 - Page 48 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x1e,0x00be); // Power Control 5 - Page 53 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x25,0x8000); // Frame Frequency Control - Page 53 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x26,0x7800); // Analog setting - Page 54 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x4e,0x0000); // Ram Address Set - Page 58 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x4f,0x0000); // Ram Address Set - Page 58 of SSD2119 datasheet
		
		 Lcd_WriteReg(0x12,0x08d9); // Sleep mode - Page 49 of SSD2119 datasheet
		
		 // -----------------Adjust the Gamma Curve----//
		 Lcd_WriteReg(0x30,0x0000);	 //0007
		
		 Lcd_WriteReg(0x31,0x0104);	   //0203
		
		 Lcd_WriteReg(0x32,0x0100);		//0001

		 Lcd_WriteReg(0x33,0x0305);	  //0007

		 Lcd_WriteReg(0x34,0x0505);	  //0007
		
		 Lcd_WriteReg(0x35,0x0305);		 //0407
		
		 Lcd_WriteReg(0x36,0x0707);		 //0407
		
		 Lcd_WriteReg(0x37,0x0300);		  //0607
		
		 Lcd_WriteReg(0x3a,0x1200);		 //0106
		
		 Lcd_WriteReg(0x3b,0x0800);		 

		 Lcd_WriteReg(0x07,0x0033); // Display Control - Page 45 of SSD2119 datasheet
	}
/*
    else if(DeviceCode==0x9325||DeviceCode==0x9328)
  	  {
  		Lcd_WriteReg(0x00e7,0x0010);      
        Lcd_WriteReg(0x0000,0x0001);  			//start internal osc
        Lcd_WriteReg(0x0001,0x0100);     
        Lcd_WriteReg(0x0002,0x0700); 				//power on sequence                     
        Lcd_WriteReg(0x0003,(1<<12)|(1<<5)|(1<<4) ); 	//65K 
        Lcd_WriteReg(0x0004,0x0000);                                   
        Lcd_WriteReg(0x0008,0x0207);	           
        Lcd_WriteReg(0x0009,0x0000);         
        Lcd_WriteReg(0x000a,0x0000); 				//display setting         
        Lcd_WriteReg(0x000c,0x0001);				//display setting          
        Lcd_WriteReg(0x000d,0x0000); 				//0f3c          
        Lcd_WriteReg(0x000f,0x0000);
//Power On sequence //
        Lcd_WriteReg(0x0010,0x0000);   
        Lcd_WriteReg(0x0011,0x0007);
        Lcd_WriteReg(0x0012,0x0000);                                                                 
        Lcd_WriteReg(0x0013,0x0000);                 
        for(i=50000;i>0;i--);
		for(i=50000;i>0;i--);
        Lcd_WriteReg(0x0010,0x1590);   
        Lcd_WriteReg(0x0011,0x0227);
        for(i=50000;i>0;i--);
		for(i=50000;i>0;i--);
        Lcd_WriteReg(0x0012,0x009c);                  
        for(i=50000;i>0;i--);
		for(i=50000;i>0;i--);
        Lcd_WriteReg(0x0013,0x1900);   
        Lcd_WriteReg(0x0029,0x0023);
        Lcd_WriteReg(0x002b,0x000e);
        for(i=50000;i>0;i--);
		for(i=50000;i>0;i--);
        Lcd_WriteReg(0x0020,0x0000);                                                            
        Lcd_WriteReg(0x0021,0x0000);           
///////////////////////////////////////////////////////      
        for(i=50000;i>0;i--);
		for(i=50000;i>0;i--);
        Lcd_WriteReg(0x0030,0x0007); 
        Lcd_WriteReg(0x0031,0x0707);   
        Lcd_WriteReg(0x0032,0x0006);
        Lcd_WriteReg(0x0035,0x0704);
        Lcd_WriteReg(0x0036,0x1f04); 
        Lcd_WriteReg(0x0037,0x0004);
        Lcd_WriteReg(0x0038,0x0000);        
        Lcd_WriteReg(0x0039,0x0706);     
        Lcd_WriteReg(0x003c,0x0701);
        Lcd_WriteReg(0x003d,0x000f);
        for(i=50000;i>0;i--);
		for(i=50000;i>0;i--);
        Lcd_WriteReg(0x0050,0x0000);        
        Lcd_WriteReg(0x0051,0x00ef);   
        Lcd_WriteReg(0x0052,0x0000);     
        Lcd_WriteReg(0x0053,0x013f);
        Lcd_WriteReg(0x0060,0xa700);        
        Lcd_WriteReg(0x0061,0x0001); 
        Lcd_WriteReg(0x006a,0x0000);
        Lcd_WriteReg(0x0080,0x0000);
        Lcd_WriteReg(0x0081,0x0000);
        Lcd_WriteReg(0x0082,0x0000);
        Lcd_WriteReg(0x0083,0x0000);
        Lcd_WriteReg(0x0084,0x0000);
        Lcd_WriteReg(0x0085,0x0000);
      
        Lcd_WriteReg(0x0090,0x0010);     
        Lcd_WriteReg(0x0092,0x0000);  
        Lcd_WriteReg(0x0093,0x0003);
        Lcd_WriteReg(0x0095,0x0110);
        Lcd_WriteReg(0x0097,0x0000);        
        Lcd_WriteReg(0x0098,0x0000);  
         //display on sequence     
        Lcd_WriteReg(0x0007,0x0133);
    
        Lcd_WriteReg(0x0020,0x0000);                                                            
        Lcd_WriteReg(0x0021,0x0000);
	}
	else if(DeviceCode==0x9320)
	{
		Lcd_WriteReg(0x00,0x0000);
		Lcd_WriteReg(0x01,0x0100);	//Driver Output Contral.
		Lcd_WriteReg(0x02,0x0700);	//LCD Driver Waveform Contral.
		Lcd_WriteReg(0x03,0x1030);	//Entry Mode Set.
	
		Lcd_WriteReg(0x04,0x0000);	//Scalling Contral.
		Lcd_WriteReg(0x08,0x0202);	//Display Contral 2.(0x0207)
		Lcd_WriteReg(0x09,0x0000);	//Display Contral 3.(0x0000)
		Lcd_WriteReg(0x0a,0x0000);	//Frame Cycle Contal.(0x0000)
		Lcd_WriteReg(0x0c,(1<<0));	//Extern Display Interface Contral 1.(0x0000)
		Lcd_WriteReg(0x0d,0x0000);	//Frame Maker Position.
		Lcd_WriteReg(0x0f,0x0000);	//Extern Display Interface Contral 2.
	
		for(i=50000;i>0;i--);
		for(i=50000;i>0;i--);
		Lcd_WriteReg(0x07,0x0101);	//Display Contral.
		for(i=50000;i>0;i--);
		for(i=50000;i>0;i--);
	
		Lcd_WriteReg(0x10,(1<<12)|(0<<8)|(1<<7)|(1<<6)|(0<<4));	//Power Control 1.(0x16b0)
		Lcd_WriteReg(0x11,0x0007);								//Power Control 2.(0x0001)
		Lcd_WriteReg(0x12,(1<<8)|(1<<4)|(0<<0));					//Power Control 3.(0x0138)
		Lcd_WriteReg(0x13,0x0b00);								//Power Control 4.
		Lcd_WriteReg(0x29,0x0000);								//Power Control 7.
	
		Lcd_WriteReg(0x2b,(1<<14)|(1<<4));
		
		Lcd_WriteReg(0x50,0);		//Set X Start.
		Lcd_WriteReg(0x51,239);	//Set X End.
		Lcd_WriteReg(0x52,0);		//Set Y Start.
		Lcd_WriteReg(0x53,319);	//Set Y End.
	
		Lcd_WriteReg(0x60,0x2700);	//Driver Output Control.
		Lcd_WriteReg(0x61,0x0001);	//Driver Output Control.
		Lcd_WriteReg(0x6a,0x0000);	//Vertical Srcoll Control.
	
		Lcd_WriteReg(0x80,0x0000);	//Display Position? Partial Display 1.
		Lcd_WriteReg(0x81,0x0000);	//RAM Address Start? Partial Display 1.
		Lcd_WriteReg(0x82,0x0000);	//RAM Address End-Partial Display 1.
		Lcd_WriteReg(0x83,0x0000);	//Displsy Position? Partial Display 2.
		Lcd_WriteReg(0x84,0x0000);	//RAM Address Start? Partial Display 2.
		Lcd_WriteReg(0x85,0x0000);	//RAM Address End? Partial Display 2.
	
		Lcd_WriteReg(0x90,(0<<7)|(16<<0));	//Frame Cycle Contral.(0x0013)
		Lcd_WriteReg(0x92,0x0000);	//Panel Interface Contral 2.(0x0000)
		Lcd_WriteReg(0x93,0x0001);	//Panel Interface Contral 3.
		Lcd_WriteReg(0x95,0x0110);	//Frame Cycle Contral.(0x0110)
		Lcd_WriteReg(0x97,(0<<8));	//
		Lcd_WriteReg(0x98,0x0000);	//Frame Cycle Contral.

	
		Lcd_WriteReg(0x07,0x0173);	//(0x0173)
	}	
	else if(DeviceCode==0x9331)
	{
	 	//        POWER ON &RESET DISPLAY OFF /
		//        Start Initial Sequence      /
		Lcd_WriteReg(0x00E7, 0x1014);
		Lcd_WriteReg(0x0001, 0x0100); // set SS and SM bit   0x0100
		Lcd_WriteReg(0x0002, 0x0200); // set 1 line inversion
		Lcd_WriteReg(0x0003, 0x1030); // set GRAM write direction and BGR=1.     0x1030
		Lcd_WriteReg(0x0008, 0x0202); // set the back porch and front porch
		Lcd_WriteReg(0x0009, 0x0000); // set non-display area refresh cycle ISC[3:0]
		Lcd_WriteReg(0x000A, 0x0000); // FMARK function
		Lcd_WriteReg(0x000C, 0x0000); // RGB interface setting
		Lcd_WriteReg(0x000D, 0x0000); // Frame marker Position
		Lcd_WriteReg(0x000F, 0x0000); // RGB interface polarity
		//             Power On sequence                //
		Lcd_WriteReg(0x0010, 0x0000); // SAP, BT[3:0], AP, DSTB, SLP, STB
		Lcd_WriteReg(0x0011, 0x0007); // DC1[2:0], DC0[2:0], VC[2:0]
		Lcd_WriteReg(0x0012, 0x0000); // VREG1OUT voltage
		Lcd_WriteReg(0x0013, 0x0000); // VDV[4:0] for VCOM amplitude
		Lcd_Delay(200); // Dis-charge capacitor power voltage
		Lcd_WriteReg(0x0010, 0x1690); // SAP, BT[3:0], AP, DSTB, SLP, STB
		Lcd_WriteReg(0x0011, 0x0227); // DC1[2:0], DC0[2:0], VC[2:0]
		Lcd_Delay(50); // Delay 50ms
		Lcd_WriteReg(0x0012, 0x000C); // Internal reference voltage= Vci;
		Lcd_Delay(50); // Delay 50ms
		Lcd_WriteReg(0x0013, 0x0800); // Set VDV[4:0] for VCOM amplitude
		Lcd_WriteReg(0x0029, 0x0011); // Set VCM[5:0] for VCOMH
		Lcd_WriteReg(0x002B, 0x000B); // Set Frame Rate
		Lcd_Delay(50); // Delay 50ms
		Lcd_WriteReg(0x0020, 0x0000); // GRAM horizontal Address
		Lcd_WriteReg(0x0021, 0x0000); // GRAM Vertical Address
		// ----------- Adjust the Gamma Curve ----------//
		Lcd_WriteReg(0x0030, 0x0000);
		Lcd_WriteReg(0x0031, 0x0106);
		Lcd_WriteReg(0x0032, 0x0000);
		Lcd_WriteReg(0x0035, 0x0204);
		Lcd_WriteReg(0x0036, 0x160A);
		Lcd_WriteReg(0x0037, 0x0707);
		Lcd_WriteReg(0x0038, 0x0106);
		Lcd_WriteReg(0x0039, 0x0707);
		Lcd_WriteReg(0x003C, 0x0402);
		Lcd_WriteReg(0x003D, 0x0C0F);
		//------------------ Set GRAM area ---------------//
		Lcd_WriteReg(0x0050, 0x0000); // Horizontal GRAM Start Address
		Lcd_WriteReg(0x0051, 0x00EF); // Horizontal GRAM End Address
		Lcd_WriteReg(0x0052, 0x0000); // Vertical GRAM Start Address
		Lcd_WriteReg(0x0053, 0x013F); // Vertical GRAM Start Address
		Lcd_WriteReg(0x0060, 0x2700); // Gate Scan Line
		Lcd_WriteReg(0x0061, 0x0001); // NDL,VLE, REV
		Lcd_WriteReg(0x006A, 0x0000); // set scrolling line
		//-------------- Partial Display Control ---------//
		Lcd_WriteReg(0x0080, 0x0000);
		Lcd_WriteReg(0x0081, 0x0000);
		Lcd_WriteReg(0x0082, 0x0000);
		Lcd_WriteReg(0x0083, 0x0000);
		Lcd_WriteReg(0x0084, 0x0000);
		Lcd_WriteReg(0x0085, 0x0000);
		//-------------- Panel Control -------------------//
		Lcd_WriteReg(0x0090, 0x0010);
		Lcd_WriteReg(0x0092, 0x0600);
		Lcd_WriteReg(0x0007,0x0021);		
		Lcd_Delay(50);
		Lcd_WriteReg(0x0007,0x0061);
		Lcd_Delay(50);
		Lcd_WriteReg(0x0007,0x0133);  // 262K color and display ON
		Lcd_Delay(50);
	}
    */
	/*
	else if(DeviceCode==0x1505)
	{
// second release on 3/5  ,luminance is acceptable,water wave appear during camera preview
        Lcd_WriteReg(0x0007,0x0000);
        Lcd_Delay(5);
        Lcd_WriteReg(0x0012,0x011C);//0x011A   why need to set several times?
        Lcd_WriteReg(0x00A4,0x0001);//NVM
    //
        Lcd_WriteReg(0x0008,0x000F);
        Lcd_WriteReg(0x000A,0x0008);
        Lcd_WriteReg(0x000D,0x0008);
       
  //GAMMA CONTROL/
        Lcd_WriteReg(0x0030,0x0707);
        Lcd_WriteReg(0x0031,0x0007); //0x0707
        Lcd_WriteReg(0x0032,0x0603); 
        Lcd_WriteReg(0x0033,0x0700); 
        Lcd_WriteReg(0x0034,0x0202); 
        Lcd_WriteReg(0x0035,0x0002); //?0x0606
        Lcd_WriteReg(0x0036,0x1F0F);
        Lcd_WriteReg(0x0037,0x0707); //0x0f0f  0x0105
        Lcd_WriteReg(0x0038,0x0000); 
        Lcd_WriteReg(0x0039,0x0000); 
        Lcd_WriteReg(0x003A,0x0707); 
        Lcd_WriteReg(0x003B,0x0000); //0x0303
        Lcd_WriteReg(0x003C,0x0007); //?0x0707
        Lcd_WriteReg(0x003D,0x0000); //0x1313//0x1f08
        Lcd_Delay(5);
        Lcd_WriteReg(0x0007,0x0001);
        Lcd_WriteReg(0x0017,0x0001);   //Power supply startup enable
        Lcd_Delay(5);
  
  //power control//
        Lcd_WriteReg(0x0010,0x17A0); 
        Lcd_WriteReg(0x0011,0x0217); //reference voltage VC[2:0]   Vciout = 1.00*Vcivl
        Lcd_WriteReg(0x0012,0x011E);//0x011c  //Vreg1out = Vcilvl*1.80   is it the same as Vgama1out ?
        Lcd_WriteReg(0x0013,0x0F00); //VDV[4:0]-->VCOM Amplitude VcomL = VcomH - Vcom Ampl
        Lcd_WriteReg(0x002A,0x0000);  
        Lcd_WriteReg(0x0029,0x000A); //0x0001F  Vcomh = VCM1[4:0]*Vreg1out    gate source voltage??
        Lcd_WriteReg(0x0012,0x013E); // 0x013C  power supply on
           //Coordinates Control//
        Lcd_WriteReg(0x0050,0x0000);//0x0e00
        Lcd_WriteReg(0x0051,0x00EF); 
        Lcd_WriteReg(0x0052,0x0000); 
        Lcd_WriteReg(0x0053,0x013F); 
    //Pannel Image Control//
        Lcd_WriteReg(0x0060,0x2700); 
        Lcd_WriteReg(0x0061,0x0001); 
        Lcd_WriteReg(0x006A,0x0000); 
        Lcd_WriteReg(0x0080,0x0000); 
    //Partial Image Control//
        Lcd_WriteReg(0x0081,0x0000); 
        Lcd_WriteReg(0x0082,0x0000); 
        Lcd_WriteReg(0x0083,0x0000); 
        Lcd_WriteReg(0x0084,0x0000); 
        Lcd_WriteReg(0x0085,0x0000); 
  //Panel Interface Control//
        Lcd_WriteReg(0x0090,0x0013); //0x0010 frenqucy
        Lcd_WriteReg(0x0092,0x0300); 
        Lcd_WriteReg(0x0093,0x0005); 
        Lcd_WriteReg(0x0095,0x0000); 
        Lcd_WriteReg(0x0097,0x0000); 
        Lcd_WriteReg(0x0098,0x0000); 
  
        Lcd_WriteReg(0x0001,0x0100); 
        Lcd_WriteReg(0x0002,0x0700); 
        Lcd_WriteReg(0x0003,0x1030); 
        Lcd_WriteReg(0x0004,0x0000); 
        Lcd_WriteReg(0x000C,0x0000); 
        Lcd_WriteReg(0x000F,0x0000); 
        Lcd_WriteReg(0x0020,0x0000); 
        Lcd_WriteReg(0x0021,0x0000); 
        Lcd_WriteReg(0x0007,0x0021); 
        Lcd_Delay(20);
        Lcd_WriteReg(0x0007,0x0061); 
        Lcd_Delay(20);
        Lcd_WriteReg(0x0007,0x0173); 
        Lcd_Delay(20);
	}							 			  
	else if(DeviceCode==0x8989)
	{
		Lcd_WriteReg(0x0000,0x0001);    Lcd_Delay(50000);  //�򿪾���
    	Lcd_WriteReg(0x0003,0xA8A4);    Lcd_Delay(50000);   //0xA8A4
    	Lcd_WriteReg(0x000C,0x0000);    Lcd_Delay(50000);   
    	Lcd_WriteReg(0x000D,0x080C);    Lcd_Delay(50000);   
    	Lcd_WriteReg(0x000E,0x2B00);    Lcd_Delay(50000);   
    	Lcd_WriteReg(0x001E,0x00B0);    Lcd_Delay(50000);   
    	Lcd_WriteReg(0x0001,0x2B3F);    Lcd_Delay(50000);   //�����������320*240  0x6B3F
    	Lcd_WriteReg(0x0002,0x0600);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0010,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0011,0x6070);    Lcd_Delay(50000);        //0x4030           //�������ݸ�ʽ  16λɫ 		���� 0x6058
    	Lcd_WriteReg(0x0005,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0006,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0016,0xEF1C);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0017,0x0003);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0007,0x0233);    Lcd_Delay(50000);        //0x0233       
    	Lcd_WriteReg(0x000B,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x000F,0x0000);    Lcd_Delay(50000);        //ɨ�迪ʼ��ַ
    	Lcd_WriteReg(0x0041,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0042,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0048,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0049,0x013F);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x004A,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x004B,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0044,0xEF00);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0045,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0046,0x013F);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0030,0x0707);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0031,0x0204);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0032,0x0204);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0033,0x0502);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0034,0x0507);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0035,0x0204);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0036,0x0204);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0037,0x0502);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x003A,0x0302);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x003B,0x0302);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0023,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0024,0x0000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x0025,0x8000);    Lcd_Delay(50000);
    	Lcd_WriteReg(0x004f,0);        //����ַ0
    	Lcd_WriteReg(0x004e,0);        //����ַ0
	}  */
  for(i=50000;i>0;i--);  
}

/****************************************************************************
* ��    �ƣ�void Lcd_SetCursor(u16 x,u16 y)
* ��    �ܣ�������Ļ����
* ��ڲ�����x      ������
*           y      ������
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_SetCursor(10,10);
****************************************************************************/
__inline void Lcd_SetCursor(u16 x,u16 y)
{
	if(DeviceCode==0x8989)
	{
	 	Lcd_WriteReg(0x004e,y);        //��
    	Lcd_WriteReg(0x004f,0x13f-x);  //��
	}
	else if(DeviceCode==0x9919)
	{
		Lcd_WriteReg(0x004e,x); // ��
  		Lcd_WriteReg(0x004f,y); // ��	
	}
	else
	{
  		Lcd_WriteReg(0x0020,y); // ��
  		Lcd_WriteReg(0x0021,0x13f-x); // ��
	}
}

/****************************************************************************
* ��    �ƣ�void Lcd_SetWindows(u16 StartX,u16 StartY,u16 EndX,u16 EndY)
* ��    �ܣ����ô�������
* ��ڲ�����StartX     ����ʼ����
*           StartY     ����ʼ����
*           EndX       �н�������
*           EndY       �н�������
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_SetWindows(0,0,100,100)��
****************************************************************************/
__inline void Lcd_SetWindows(u16 StartX,u16 StartY,u16 EndX,u16 EndY)
{
  Lcd_SetCursor(StartX,StartY);
  Lcd_WriteReg(0x0050, StartX);
  Lcd_WriteReg(0x0052, StartY);
  Lcd_WriteReg(0x0051, EndX);
  Lcd_WriteReg(0x0053, EndY);
}

/****************************************************************************
* ��    �ƣ�void Lcd_Clear(u16 dat)
* ��    �ܣ�����Ļ����ָ������ɫ��������������� 0xffff
* ��ڲ�����dat      ���ֵ
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_Clear(0xffff);
****************************************************************************/
void Lcd_Clear(u16 dat)
{
  u32  i;

  Lcd_SetCursor(0x0000, 0x0000);  
  Clr_Cs; 
  Lcd_WriteIndex(0x0022); 
  Set_Rs; 
  Lcd_WriteData(dat); // Placed here for optimization: As we are putting the same color, we just need to set the color-bus once (as long it doesn't change)
  for(i=0;i<76800;i++)
  {
    //Lcd_WriteData(dat); // Removed for optimization: This isn't needed here, as we are putting the same color, so just set it at the beginning of the loop
	Clr_nWr;
	Set_nWr;
  }

  Set_Cs;
}


/****************************************************************************
* ��    �ƣ�u16 Lcd_GetPoint(u16 x,u16 y)
* ��    �ܣ���ȡָ���������ɫֵ
* ��ڲ�����x      ������
*           y      ������
* ���ڲ�������ǰ������ɫֵ
* ˵    ����
* ���÷�����i=Lcd_GetPoint(10,10);
****************************************************************************/
//u16 Lcd_GetPoint(u16 x,u16 y)
//{
//  Lcd_SetCursor(x,y);
//  return (Lcd_BGR2RGB(Lcd_ReadRegister(0x0022)));
//}

u16 Lcd_GetPoint(u16 x,u16 y)
{
  u16 temp;
  Lcd_SetCursor(x,y);
  Clr_Cs;
  Lcd_WriteIndex(0x0022);
   Clr_nRd;  
	temp = Lcd_ReadData(); //dummy
   Set_nRd;   
   Clr_nRd;  
	temp = Lcd_ReadData(); 
   Set_nRd;	
   Set_Cs;
   temp=Lcd_BGR2RGB(temp);

   return (temp);
}


/****************************************************************************
* ��    �ƣ�void Lcd_SetPoint(u16 x,u16 y,u16 point)
* ��    �ܣ���ָ�����껭��
* ��ڲ�����x      ������
*           y      ������
*           point  �����ɫ
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_SetPoint(10,10,0x0fe0);
****************************************************************************/
void Lcd_SetPoint(u16 x,u16 y,u16 point)
{
  if ( (x>320)||(y>240) ) return;
  Lcd_SetCursor(x,y);

  Clr_Cs;
  Lcd_WriteIndex(0x0022);
  Set_Rs;
  Lcd_WriteData(point);
  Clr_nWr;Set_nWr;
  Set_Cs;
}

/****************************************************************************
* ��    �ƣ�void Lcd_DrawPicture(u16 StartX,u16 StartY,u16 EndX,u16 EndY,u16 *pic)
* ��    �ܣ���ָ�����귶Χ��ʾһ��ͼƬ
* ��ڲ�����StartX     ����ʼ����
*           StartY     ����ʼ����
*           EndX       �н�������
*           EndY       �н�������
            pic        ͼƬͷָ��
* ���ڲ�������
* ˵    ����ͼƬȡģ��ʽΪˮƽɨ�裬16λ��ɫģʽ
* ���÷�����Lcd_DrawPicture(0,0,100,100,(u16*)demo);
****************************************************************************/
void Lcd_DrawPicture(u16 StartX,u16 StartY,u16 EndX,u16 EndY,u16 *pic)
{
  u16  i;
  Lcd_SetWindows(StartX,StartY,EndX,EndY);
  Lcd_SetCursor(StartX,StartY);
  
  Clr_Cs;

  Lcd_WriteIndex(0x0022);
  Set_Rs;
  for (i=0;i<(EndX*EndY);i++)
  {
      Lcd_WriteData(*pic++);
	  Clr_nWr;Set_nWr;
  }
      
  Set_Cs;
}

/****************************************************************************
* ��    �ƣ�void Lcd_PutChar(u16 x,u16 y,u8 c,u16 charColor,u16 bkColor)
* ��    �ܣ���ָ��������ʾһ��8x16�����ascii�ַ�
* ��ڲ�����x          ������
*           y          ������
*           charColor  �ַ�����ɫ
*           bkColor    �ַ�������ɫ
* ���ڲ�������
* ˵    ������ʾ��Χ�޶�Ϊ����ʾ��ascii��
* ���÷�����Lcd_PutChar(10,10,'a',0x0000,0xffff);
****************************************************************************/
void Lcd_PutChar(u16 x,u16 y,u8 c,u16 charColor,u16 bkColor)
{
  u16 i=0;
  u16 j=0;
  
  u8 tmp_char=0;

  for (i=0;i<16;i++)
  {
    tmp_char=ascii_8x16[((c-0x20)*16)+i];
    for (j=0;j<8;j++)
    {
      if ( (tmp_char >> 7-j) & 0x01 == 0x01)
        {
          Lcd_SetPoint(x+j,y+i,charColor); // �ַ���ɫ
        }
        else
        {
          Lcd_SetPoint(x+j,y+i,bkColor); // ������ɫ
        }
    }
  }
}

/****************************************************************************
* ��    �ƣ�void Lcd_Test()
* ��    �ܣ�����Һ����
* ��ڲ�������
* ���ڲ�������
* ˵    ������ʾ����������Һ�����Ƿ���������
* ���÷�����Lcd_Test();
****************************************************************************/
void Lcd_Test(void)
{
  u8  R_data,G_data,B_data,i,j;

	Lcd_SetCursor(0x00, 0x0000);
	Lcd_WriteReg(0x0050,0x00);//ˮƽ GRAM��ʼλ��
	Lcd_WriteReg(0x0051,239);//ˮƽGRAM��ֹλ��
	Lcd_WriteReg(0x0052,0);//��ֱGRAM��ʼλ��
	Lcd_WriteReg(0x0053,319);//��ֱGRAM��ֹλ��  
    Lcd_WR_Start();
    R_data=0;G_data=0;B_data=0;     
    for(j=0;j<50;j++)//��ɫ��ǿ��
    {
        for(i=0;i<240;i++)
            {R_data=i/8;Lcd_WriteData(R_data<<11|G_data<<5|B_data);
			Clr_nWr;Set_nWr;}
    }
    R_data=0x1f;G_data=0x3f;B_data=0x1f;
    for(j=0;j<50;j++)
    {
        for(i=0;i<240;i++)
            {
            G_data=0x3f-(i/4);
            B_data=0x1f-(i/8);
            Lcd_WriteData(R_data<<11|G_data<<5|B_data);
			Clr_nWr;
			Set_nWr;
			}
    }
//----------------------------------
    R_data=0;G_data=0;B_data=0;
    for(j=0;j<50;j++)//��ɫ��ǿ��
    {
        for(i=0;i<240;i++)
            {G_data=i/4;
			Lcd_WriteData(R_data<<11|G_data<<5|B_data);
			Clr_nWr;
			Set_nWr;}
    }

    R_data=0x1f;G_data=0x3f;B_data=0x1f;
    for(j=0;j<50;j++)
    {
        for(i=0;i<240;i++)
            {
            R_data=0x1f-(i/8);
            B_data=0x1f-(i/8);
            Lcd_WriteData(R_data<<11|G_data<<5|B_data);
			Clr_nWr;
			Set_nWr;
		}
    }
//----------------------------------
 
    R_data=0;G_data=0;B_data=0;
    for(j=0;j<60;j++)//��ɫ��ǿ��
    {
        for(i=0;i<240;i++)
            {B_data=i/8;Lcd_WriteData(R_data<<11|G_data<<5|B_data);
			Clr_nWr;
			Set_nWr;}
    } 

    B_data=0; 
    R_data=0x1f;G_data=0x3f;B_data=0x1f;

    for(j=0;j<60;j++)
    {
        for(i=0;i<240;i++)
            {
            G_data=0x3f-(i/4);
            R_data=0x1f-(i/8);
            Lcd_WriteData(R_data<<11|G_data<<5|B_data);
			Clr_nWr;
			Set_nWr;
		}
    }	  
	Lcd_WR_End();
}

/****************************************************************************
* ��    �ƣ�u16 Lcd_BGR2RGB(u16 c)
* ��    �ܣ�RRRRRGGGGGGBBBBB ��Ϊ BBBBBGGGGGGRRRRR ��ʽ
* ��ڲ�����c      BRG ��ɫֵ
* ���ڲ�����RGB ��ɫֵ
* ˵    �����ڲ���������
* ���÷�����
****************************************************************************/
u16 Lcd_BGR2RGB(u16 c)
{
  u16  r, g, b, rgb;

  b = (c>>0)  & 0x1f;
  g = (c>>5)  & 0x3f;
  r = (c>>11) & 0x1f;
  
  rgb =  (b<<11) + (g<<5) + (r<<0);

  return( rgb );
}

/****************************************************************************
* ��    �ƣ�void Lcd_WriteIndex(u16 idx)
* ��    �ܣ�д Lcd �������Ĵ�����ַ
* ��ڲ�����idx   �Ĵ�����ַ
* ���ڲ�������
* ˵    ��������ǰ����ѡ�п��������ڲ�����
* ���÷�����Lcd_WriteIndex(0x0000);
****************************************************************************/
__inline void Lcd_WriteIndex(u16 idx)
{
    Clr_Rs;
	Set_nRd;
	Lcd_WriteData(idx);
	Clr_nWr;
	Set_nWr;
	Set_Rs;
}

/****************************************************************************
* ��    �ƣ�void Lcd_WriteData(u16 dat)
* ��    �ܣ�д Lcd �Ĵ�������
* ��ڲ�����dat     �Ĵ�������
* ���ڲ�������
* ˵    �����������ָ����ַд�����ݣ�����ǰ����д�Ĵ�����ַ���ڲ�����
* ���÷�����Lcd_WriteData(0x1030)
****************************************************************************/
void Lcd_WriteData(u16 data)
{
	GPIOB->ODR=((GPIOB->ODR&0x00ff)|(data<<8));
	GPIOC->ODR=((GPIOC->ODR&0xff00)|(data>>8));
}

/************************************************
��������Lcdд��ʼ����
���ܣ�����Lcd�������� ִ��д����
��ڲ�������
����ֵ����
************************************************/
void Lcd_WR_Start(void)
{
	Clr_Cs;
	Clr_Rs;
	Set_nRd;
	Lcd_WriteData(0x0022);
	Clr_nWr;
	Set_nWr;
	Set_Rs;
}

void Lcd_WR_End(void)
{
    Set_Cs;
}


/****************************************************************************
* ��    �ƣ�u16 Lcd_ReadData(void)
* ��    �ܣ���ȡ����������
* ��ڲ�������
* ���ڲ��������ض�ȡ��������
* ˵    �����ڲ�����
* ���÷�����i=Lcd_ReadData();
****************************************************************************/
__inline u16 Lcd_ReadData(void)
{
//========================================================================
// **                                                                    **
// ** nCS       ----\__________________________________________/-------  **
// ** RS        ------\____________/-----------------------------------  **
// ** nRD       -------------------------\_____/---------------------  **
// ** nWR       --------\_______/--------------------------------------  **
// ** DB[0:15]  ---------[index]----------[data]-----------------------  **
// **                                                                    **
//========================================================================
	u16 tmp;
	GPIOB->CRH = (GPIOB->CRH & 0x00000000) | 0x44444444;
	GPIOC->CRL = (GPIOC->CRL & 0x00000000) | 0x44444444;
	tmp = (((GPIOB->IDR)>>8)|((GPIOC->IDR)<<8));
	GPIOB->CRH = (GPIOB->CRH & 0x00000000) | 0x33333333;
	GPIOC->CRL = (GPIOC->CRL & 0x00000000) | 0x33333333;
	return tmp;
}

/****************************************************************************
* ��    �ƣ�u16 Lcd_ReadRegister(u16 index)
* ��    �ܣ���ȡָ����ַ�Ĵ�����ֵ
* ��ڲ�����index    �Ĵ�����ַ
* ���ڲ������Ĵ���ֵ
* ˵    �����ڲ�����
* ���÷�����i=Lcd_ReadRegister(0x0022);
****************************************************************************/
__inline u16 Lcd_ReadRegister(u16 index)
{ 
  	Clr_Cs;
	Lcd_WriteIndex(index);
	Clr_nRd;     
	index = Lcd_ReadData(); 
	Set_nRd;      	
	Set_Cs;
	return index;
}

/****************************************************************************
* ��    �ƣ�void Lcd_WriteReg(u16 index,u16 dat)
* ��    �ܣ�дָ����ַ�Ĵ�����ֵ
* ��ڲ�����index    �Ĵ�����ַ
*         ��dat      �Ĵ���ֵ
* ���ڲ�������
* ˵    �����ڲ�����
* ���÷�����Lcd_WriteReg(0x0000,0x0001);
****************************************************************************/
__inline void Lcd_WriteReg(u16 index,u16 dat)
{
 /************************************************************************
  **                                                                    **
  ** nCS       ----\__________________________________________/-------  **
  ** RS        ------\____________/-----------------------------------  **
  ** nRD       -------------------------------------------------------  **
  ** nWR       --------\_______/--------\_____/-----------------------  **
  ** DB[0:15]  ---------[index]----------[data]-----------------------  **
  **                                                                    **
  ************************************************************************/
//   u16 temp;
    Clr_Cs;
	Clr_Rs;
	//Set_nRd;
	Lcd_WriteData(index);
//	temp=(*((volatile unsigned long *) 0x40010C0C));
//	(*((volatile unsigned long *) 0x40010C0C))=(index<<8)|(temp&0x00ff);
//	temp=(*((volatile unsigned long *) 0x4001100C));
//	(*((volatile unsigned long *) 0x4001100C))=(index>>8)|(temp&0xff00);
	Clr_nWr;
	Set_nWr;
	Set_Rs;       
	Lcd_WriteData(dat);  
//	temp=(*((volatile unsigned long *) 0x40010C0C));
//	(*((volatile unsigned long *) 0x40010C0C))=(dat<<8)|(temp&0x00ff);
//	temp=(*((volatile unsigned long *) 0x4001100C));
//	(*((volatile unsigned long *) 0x4001100C))=(dat>>8)|(temp&0xff00);     
	Clr_nWr;
	Set_nWr;
	Set_Cs;
}

/****************************************************************************
* ��    �ƣ�void Lcd_Reset()
* ��    �ܣ���λ Lcd ������
* ��ڲ�������
* ���ڲ�������
* ˵    ������λ���������ڲ�����
* ���÷�����Lcd_Reset()
****************************************************************************/
void Lcd_Reset()
{
  /***************************************
   **                                   **
   **  -------\______________/-------   **
   **         | <---Tres---> |          **
   **                                   **
   **  Tres: Min.1ms                    **
   ***************************************/
    
  	Set_Rst;;
    Lcd_Delay(50000);
  	Clr_Rst;
    Lcd_Delay(50000);
  	Set_Rst;
    Lcd_Delay(50000);
}

/****************************************************************************
* ��    �ƣ�void Lcd_BackLight(u8 status)
* ��    �ܣ�������Һ������
* ��ڲ�����status     1:���⿪  0:�����
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_BackLight(1);
****************************************************************************/
void Lcd_BackLight(u8 status)
{
  if ( status >= 1 )
  {
    Lcd_Light_ON;
  }
  else
  {
    Lcd_Light_OFF;
  }
}

/****************************************************************************
* ��    �ƣ�void Lcd_Delay(vu32 nCount)
* ��    �ܣ���ʱ
* ��ڲ�����nCount   ��ʱֵ
* ���ڲ�������
* ˵    ����
* ���÷�����Lcd_Delay(10000);
****************************************************************************/
void Lcd_Delay(vu32 nCount)
{
  for(; nCount != 0; nCount--);
}
