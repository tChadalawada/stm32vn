#include "stm32f10x.h"

/**
 * Size of the FFT output spectrum (unsymetrized). Note that the 
 * allocated buffers have twice the size because the spectrum is
 * symetrized (-fs/2 to fs/2).
 */
#define FFT_LENGTH 256

u32* compute_fft(u32* samples, u16 size);
u16 fundamental_frequency(u32* sprectrum, u16 sampling_rate);