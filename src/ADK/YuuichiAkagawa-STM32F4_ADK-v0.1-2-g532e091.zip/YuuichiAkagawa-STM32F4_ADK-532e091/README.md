STM32F4-Discovery with Android ADK
====================================

Android Open Accessory(ADK) firmware for STM32F4-Discovery

This project is an experimental yet.

Build
------
You can build with Atollic TrueSTUDIO/STM32 Lite.

Sample Android App is [here](https://github.com/YuuichiAkagawa/HelloADK)

Misc info
---------
+ UART debug out port is PA2 @230400bps

License
-------
Copyright &copy; 2012 Yuuichi Akagawa

Licensed under the [Apache License, Version 2.0][Apache]

[Apache]: http://www.apache.org/licenses/LICENSE-2.0

