/* This file is generated from prc_rename.def by genrename. */

/* This file is included only when prc_rename.h has been included. */
#ifdef TOPPERS_PRC_RENAME_H
#undef TOPPERS_PRC_RENAME_H

#undef start_r
#undef ret_int
#undef ret_exc
#undef lock_flag
#undef saved_iipm

#ifdef TOPPERS_LABEL_ASM

#undef _start_r
#undef _ret_int
#undef _ret_exc
#undef _lock_flag
#undef _saved_iipm

#endif /* TOPPERS_LABEL_ASM */


#endif /* TOPPERS_PRC_RENAME_H */
