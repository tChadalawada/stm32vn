/*
 *  @(#) $Id: prc_cfg1_out.h 930 2008-04-14 07:33:19Z ertl-hiro $
 */

/*
 *		cfg1_out.c�Υ�󥯤�ɬ�פʥ����֤����
 */

void sta_ker(void)
{
}

void hardware_init_hook(void)
{
}

void software_init_hook(void)
{
}

const SIZE		_kernel_istksz = 0;

STK_T *const	_kernel_istk = NULL;
