Code Red Technologies - RDB1768v2 Firmware Updater
==================================================

9 May 2011 (updated installer script)


This script will update an RDB1768v2 development board to the latest
firmware revision.

Usage:
	updateRDB1768v2 [timeout]
and follow the instructions displayed


The optional [timeout] parameter can be used to increase the time 
that the script will wait for the board to switch into its update 
mode. The default is 10 (seconds).


Note that if the update fails first time, replug the board and try
again.




